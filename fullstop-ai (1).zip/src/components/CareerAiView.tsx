import React, { useState } from 'react';
import { ResumeAtsAnalysis, UserProfile } from '../types';
import {
  Award,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  FileText,
  Briefcase,
  TrendingUp,
  ArrowRight,
  Copy,
  Check,
  ChevronRight,
  MessageSquare,
  Zap,
} from 'lucide-react';

interface CareerAiViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const ROLES = [
  'Senior Machine Learning Engineer',
  'Fullstack Software Engineer (React / Node)',
  'Cloud DevOps & Site Reliability Engineer (SRE)',
  'AI Product Manager',
  'Quantitative Research Analyst',
];

const SAMPLE_RESUME = `EDUCATION:
B.S. in Computer Science, State University, 2023

EXPERIENCE:
Software Engineer Intern, TechCorp (June 2023 - Present)
- Worked on backend APIs using Python and Flask.
- Helped the team migrate database queries to PostgreSQL.
- Responsible for fixing bugs and writing unit tests in pytest.
- Assisted with deploying services onto AWS EC2 instances.

PROJECTS:
- Built a personal portfolio website in React and Tailwind CSS.
- Created a sentiment analysis bot on Twitter data using Python.`;

const INITIAL_ANALYSIS: ResumeAtsAnalysis = {
  targetRole: ROLES[0],
  atsScore: 74,
  matchedKeywords: ['Python', 'PostgreSQL', 'AWS EC2', 'Flask', 'React', 'Pytest'],
  missingCriticalKeywords: [
    'Docker & Containerization',
    'Kubernetes (K8s)',
    'CI/CD Pipelines (GitHub Actions)',
    'Distributed Caching (Redis)',
    'Microservices Architecture',
    'Quantifiable Business Metrics ($ / %)',
  ],
  bulletCritiques: [
    {
      original: 'Worked on backend APIs using Python and Flask.',
      improved:
        'Architected and deployed 12 RESTful microservices in Python/Flask, decreasing p99 client latency by 32% across 450K daily requests.',
      rationale:
        'Replaced passive verb "worked" with active leadership verb "architected" and injected measurable latency and throughput metrics.',
    },
    {
      original: 'Helped the team migrate database queries to PostgreSQL.',
      improved:
        'Spearheaded relational schema refactoring and index optimization on PostgreSQL, slashing slow query execution times by 45% and eliminating connection pool timeouts.',
      rationale:
        'Replaced "helped" with "spearheaded", clarifying exact technical mechanisms (indexing, connection pooling) and operational impact.',
    },
  ],
  summaryFeedback:
    'Strong foundational computer science background. Elevate ATS match rate by integrating container orchestration (Docker/K8s) and replacing task-oriented bullets with quantified business outcomes.',
};

export const CareerAiView: React.FC<CareerAiViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [targetRole, setTargetRole] = useState(ROLES[0]);
  const [resumeText, setResumeText] = useState(SAMPLE_RESUME);
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<ResumeAtsAnalysis>(INITIAL_ANALYSIS);
  const [activeTab, setActiveTab] = useState<'ats' | 'bullets' | 'interview'>('ats');
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  // Mock interview state
  const [interviewQuestion, setInterviewQuestion] = useState(
    'Tell me about a time you had to diagnose and resolve a severe performance bottleneck in production.'
  );
  const [userInterviewAnswer, setUserInterviewAnswer] = useState('');
  const [interviewFeedback, setInterviewFeedback] = useState<{
    score: number;
    starAnalysis: string;
    suggestion: string;
  } | null>(null);
  const [isInterviewLoading, setIsInterviewLoading] = useState(false);

  const handleAnalyzeResume = async () => {
    if (!resumeText.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/career/ats-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetRole,
          resumeText,
        }),
      });
      const data = await res.json();
      if (data.success && data.analysis) {
        setAnalysis(data.analysis);
      }
    } catch (err) {
      console.error('ATS analyze error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleGradeInterviewAnswer = async () => {
    if (!userInterviewAnswer.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsInterviewLoading(true);
    try {
      const res = await fetch('/api/career/mock-interview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targetRole,
          question: interviewQuestion,
          answer: userInterviewAnswer,
        }),
      });
      const data = await res.json();
      if (data.success && data.feedback) {
        setInterviewFeedback(data.feedback);
      }
    } catch (err) {
      console.error('Interview evaluation error:', err);
    } finally {
      setIsInterviewLoading(false);
    }
  };

  const handleCopyBullet = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div id="career-ai-view" className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171424] via-[#100d1c] to-[#07060c] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <Briefcase className="w-3 h-3" />
                EXECUTIVE TALENT PROTOCOL
              </span>
              <span className="text-xs font-mono text-zinc-400">ATS AUDIT & MOCK TECHNICAL INTERVIEWS</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              Career AI // Resume ATS Optimizer & Interview Coach
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Optimize resumes against corporate Applicant Tracking Systems (ATS), rewrite passive bullets
              into high-impact quantifiable metrics, and practice role-specific technical interviews.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38] flex flex-col items-center justify-center font-sora font-black">
              <span className="text-base leading-none">{analysis.atsScore}</span>
              <span className="text-[8px] font-mono uppercase mt-0.5">ATS</span>
            </div>
            <div>
              <span className="text-[10px] font-mono text-zinc-400 block uppercase">Match Score</span>
              <span className="text-xs font-bold text-white font-sora">
                {analysis.atsScore >= 80 ? 'Highly Competitive' : 'Needs Optimization'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Target Role Selector & Mode Tabs */}
      <div className="p-4 rounded-2xl bg-[#0e0c14]/90 border border-white/10 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-zinc-400 uppercase">Target Role:</span>
          <select
            value={targetRole}
            onChange={(e) => setTargetRole(e.target.value)}
            className="px-3 py-2 rounded-xl bg-black/50 border border-white/10 text-white text-xs font-sans focus:outline-none focus:border-[#cfbcff]/50 cursor-pointer"
          >
            {ROLES.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>

        {/* View Switcher */}
        <div className="flex items-center p-1 rounded-xl bg-black/40 border border-white/10">
          <button
            onClick={() => setActiveTab('ats')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium font-sora transition-colors ${
              activeTab === 'ats'
                ? 'bg-[#cfbcff] text-[#1c0f38] font-bold shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            ATS Keyword Audit
          </button>
          <button
            onClick={() => setActiveTab('bullets')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium font-sora transition-colors ${
              activeTab === 'bullets'
                ? 'bg-[#cfbcff] text-[#1c0f38] font-bold shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Bullet Rewriter
          </button>
          <button
            onClick={() => setActiveTab('interview')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium font-sora transition-colors ${
              activeTab === 'interview'
                ? 'bg-[#cfbcff] text-[#1c0f38] font-bold shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Mock Interview
          </button>
        </div>
      </div>

      {/* Tab 1: ATS Keyword Audit & Resume Input */}
      {activeTab === 'ats' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Resume Input Area (6 cols) */}
          <div className="lg:col-span-6 space-y-3">
            <div className="p-5 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" />
                  Your Resume Text
                </span>
                <button
                  onClick={() => setResumeText(SAMPLE_RESUME)}
                  className="text-[11px] font-mono text-zinc-400 hover:text-[#cfbcff] underline"
                >
                  Load Sample
                </button>
              </div>

              <textarea
                value={resumeText}
                onChange={(e) => setResumeText(e.target.value)}
                rows={14}
                placeholder="Paste your plain text resume sections here..."
                className="w-full p-3.5 rounded-xl bg-black/50 border border-white/10 text-zinc-200 text-xs font-mono leading-relaxed focus:outline-none focus:border-[#cfbcff]/50 resize-none"
              />

              <button
                onClick={handleAnalyzeResume}
                disabled={isLoading || !resumeText.trim()}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#6750a4] text-[#1c0f38] font-bold text-xs font-sora flex items-center justify-center gap-2 hover:opacity-95 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(207,188,255,0.25)]"
              >
                {isLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 rounded-full border-2 border-[#1c0f38] border-t-transparent animate-spin" />
                    <span>Auditing ATS Compatibility...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Run ATS Diagnostic</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* ATS Results (6 cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-5">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold">
                  ATS Keyword Breakdown
                </span>
                <span className="text-xs font-mono text-zinc-400">{targetRole}</span>
              </div>

              {/* Matched Keywords */}
              <div className="space-y-2">
                <span className="text-xs font-mono uppercase text-emerald-300 font-bold flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Matched High-Relevance Keywords ({analysis.matchedKeywords.length})
                </span>
                <div className="flex flex-wrap gap-2">
                  {analysis.matchedKeywords.map((kw, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg text-xs font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/30"
                    >
                      ✓ {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Missing High Priority Keywords */}
              <div className="space-y-2">
                <span className="text-xs font-mono uppercase text-rose-300 font-bold flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5" />
                  Missing High-Priority ATS Keywords ({analysis.missingCriticalKeywords.length})
                </span>
                <div className="flex flex-wrap gap-2">
                  {analysis.missingCriticalKeywords.map((kw, i) => (
                    <span
                      key={i}
                      className="px-2.5 py-1 rounded-lg text-xs font-mono bg-rose-500/10 text-rose-300 border border-rose-500/30"
                    >
                      + {kw}
                    </span>
                  ))}
                </div>
              </div>

              {/* Strategic Advice */}
              <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
                <span className="text-xs font-mono uppercase text-amber-300 font-bold block">
                  Strategic Recommendations
                </span>
                <p className="text-xs text-zinc-300 font-sans leading-relaxed">
                  {analysis.summaryFeedback}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Bullet Rewriter */}
      {activeTab === 'bullets' && (
        <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-6">
          <div className="pb-3 border-b border-white/10">
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#cfbcff] font-bold block">
              STAR Methodology Impact Engine
            </span>
            <h3 className="text-base font-bold text-white font-sora mt-0.5">
              Quantified Bullet Point Upgrades for {targetRole}
            </h3>
          </div>

          <div className="space-y-4">
            {analysis.bulletCritiques.map((item, idx) => {
              const isCopied = copiedIdx === idx;
              return (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-3"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] font-mono uppercase text-zinc-500 block">
                      Before (Passive Duty):
                    </span>
                    <p className="text-xs text-rose-300/80 font-mono line-through">{item.original}</p>
                  </div>

                  <div className="p-3 rounded-lg bg-emerald-500/[0.06] border border-emerald-500/20 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono uppercase text-emerald-300 font-bold flex items-center gap-1.5">
                        <Zap className="w-3 h-3" />
                        After (High-Impact Metric Bullet):
                      </span>
                      <button
                        onClick={() => handleCopyBullet(item.improved, idx)}
                        className="text-emerald-300 hover:text-white flex items-center gap-1 text-[11px] font-mono transition-colors"
                      >
                        {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{isCopied ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                    <p className="text-xs sm:text-sm font-sans text-emerald-200 leading-relaxed font-medium">
                      {item.improved}
                    </p>
                  </div>

                  <p className="text-[11px] text-zinc-400 italic">
                    <strong>Why this works:</strong> {item.rationale}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 3: Mock Technical & Behavioral Interview */}
      {activeTab === 'interview' && (
        <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-6">
          <div className="pb-3 border-b border-white/10">
            <span className="text-[10px] font-mono uppercase tracking-wider text-[#cfbcff] font-bold block">
              Interview Simulator
            </span>
            <h3 className="text-base font-bold text-white font-sora mt-0.5">
              Practice Role-Specific Behavioral & System Design Questions
            </h3>
          </div>

          <div className="p-4 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 space-y-1">
            <span className="text-[10px] font-mono uppercase text-[#cfbcff] font-bold block">
              Interviewer Prompt ({targetRole})
            </span>
            <p className="text-sm font-semibold text-white font-sora">{interviewQuestion}</p>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-mono uppercase text-zinc-400 font-semibold block">
              Your Answer (Frame using STAR: Situation, Task, Action, Result):
            </label>
            <textarea
              rows={5}
              value={userInterviewAnswer}
              onChange={(e) => setUserInterviewAnswer(e.target.value)}
              placeholder="In my previous role, our database CPU spiked to 98% during peak hours..."
              className="w-full p-3.5 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none focus:border-[#cfbcff]/50"
            />
            <button
              onClick={handleGradeInterviewAnswer}
              disabled={isInterviewLoading || !userInterviewAnswer.trim()}
              className="py-2.5 px-5 rounded-xl bg-[#cfbcff] text-[#1c0f38] text-xs font-bold font-sora flex items-center gap-2 hover:opacity-95 disabled:opacity-40 transition-opacity"
            >
              {isInterviewLoading ? (
                <div className="w-3.5 h-3.5 rounded-full border-2 border-[#1c0f38] border-t-transparent animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              <span>Grade Answer with AI</span>
            </button>
          </div>

          {interviewFeedback && (
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-3 animate-fadeIn">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase text-[#cfbcff] font-bold">
                  Interviewer Score: {interviewFeedback.score}/100
                </span>
              </div>
              <div className="space-y-1 text-xs text-zinc-200">
                <strong className="text-amber-300 font-mono text-[10px] uppercase block">
                  STAR Alignment:
                </strong>
                <p>{interviewFeedback.starAnalysis}</p>
              </div>
              <div className="space-y-1 text-xs text-zinc-300 pt-2 border-t border-white/5">
                <strong className="text-emerald-300 font-mono text-[10px] uppercase block">
                  Elevate Your Answer:
                </strong>
                <p>{interviewFeedback.suggestion}</p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
