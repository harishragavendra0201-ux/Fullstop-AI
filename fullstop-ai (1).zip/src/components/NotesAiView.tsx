import React, { useState, useEffect } from 'react';
import { NoteItem, UserProfile } from '../types';
import {
  FileText,
  Sparkles,
  Copy,
  Check,
  Download,
  Trash2,
  Search,
  BookOpen,
  Tag,
  ArrowRight,
  ListOrdered,
  Lightbulb,
  Zap,
  Bookmark,
} from 'lucide-react';

interface NotesAiViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const STORAGE_KEY = 'fullstop_notes_ai_vault';

const PRESET_TOPICS = [
  'Attention Mechanism & Transformer Networks',
  'Distributed Consensus: Raft vs Paxos',
  'Quantum Decoherence & Qubit Coherence',
  'Operating Systems: Virtual Memory & Page Faults',
  'CRISPR Gene Editing & Bio-Ethics',
];

const INITIAL_NOTE: NoteItem = {
  id: 'note-sample-1',
  title: 'Attention Mechanism & Transformer Neural Networks',
  topic: 'Machine Learning',
  summary:
    'Transformers replace recurrent neural networks by processing token relationships in parallel across entire sequences using self-attention. This scales dot products between Query and Key vectors to compute dynamic weight matrices multiplied by Value vectors.',
  cornell: {
    cues: [
      'Why self-attention over RNNs?',
      'What is the Scaled Dot-Product formula?',
      'Role of Positional Encoding?',
    ],
    notes: [
      'RNNs process tokens sequentially O(N), blocking GPU parallelism. Self-attention enables simultaneous parallel computation across all sequence tokens.',
      'Attention(Q, K, V) = softmax(Q·K^T / √d_k) · V. The square root factor √d_k prevents high-dimensional dot products from exploding into regions with microscopic softmax gradients.',
      'Because pure self-attention is permutation-equivariant, sinusoidal or rotary positional embeddings (RoPE) must be added so the model comprehends token order.',
    ],
    summary:
      'Transformers achieve operational supremacy through parallel self-attention scaled by √d_k, using positional vectors to retain sequential awareness.',
  },
  keyTakeaways: [
    'Parallel processing eliminates the sequential latency bottleneck of LSTMs and RNNs',
    'Scaled dot product prevents gradient vanishing at high dimensional vector spaces',
    'Multi-head attention captures both syntactic linkages and semantic reference pronouns concurrently',
    'Quadratic memory complexity O(N²) requires specialized flash-attention or sliding window optimizations for long contexts',
  ],
  cheatSheetBullets: [
    'Formula: softmax((Q · K^T) / √d_k) · V',
    'Time & Memory Complexity: O(N² · d)',
    'Key Invariant: Attention weights across each row sum to exactly 1.0',
    'Decoder Trap: Must apply causal upper-triangular masking to prevent looking into future tokens',
  ],
  tags: ['AI', 'Transformers', 'Deep Learning', 'Cornell Notes'],
  createdAt: new Date().toISOString(),
};

export const NotesAiView: React.FC<NotesAiViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [topic, setTopic] = useState(initialPrompt || '');
  const [rawContent, setRawContent] = useState('');
  const [depth, setDepth] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeNoteTab, setActiveNoteTab] = useState<'cornell' | 'takeaways' | 'cheatsheet'>('cornell');

  const [notesVault, setNotesVault] = useState<NoteItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return [INITIAL_NOTE];
  });

  const [selectedNote, setSelectedNote] = useState<NoteItem>(notesVault[0] || INITIAL_NOTE);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notesVault));
    } catch (e) {
      console.error(e);
    }
  }, [notesVault]);

  useEffect(() => {
    if (initialPrompt && initialPrompt !== topic) {
      setTopic(initialPrompt);
    }
  }, [initialPrompt]);

  const handleGenerateNotes = async () => {
    if (!topic.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/notes/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          rawContent: rawContent.trim(),
          depth,
        }),
      });
      const data = await res.json();
      if (data.success && data.note) {
        setNotesVault((prev) => [data.note, ...prev]);
        setSelectedNote(data.note);
      }
    } catch (err) {
      console.error('Notes AI generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportMarkdown = (note: NoteItem) => {
    const md = `# ${note.title}
**Topic:** ${note.topic} | **Date:** ${new Date(note.createdAt).toLocaleDateString()}

## Executive Summary
${note.summary}

---

## Cornell Notes System
### Cues & Review Questions
${note.cornell.cues.map((c) => `- ${c}`).join('\n')}

### Detailed Notes
${note.cornell.notes.map((n) => `- ${n}`).join('\n')}

### Synthesis Summary
> ${note.cornell.summary}

---

## Key Takeaways
${note.keyTakeaways.map((t, idx) => `${idx + 1}. ${t}`).join('\n')}

## High-Yield Cheat Sheet Bullets
${note.cheatSheetBullets.map((b) => `* ${b}`).join('\n')}
`;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${note.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-notes.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDeleteNote = (id: string) => {
    const updated = notesVault.filter((n) => n.id !== id);
    setNotesVault(updated);
    if (selectedNote.id === id && updated.length > 0) {
      setSelectedNote(updated[0]);
    }
  };

  const filteredVault = notesVault.filter(
    (n) =>
      n.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.topic.toLowerCase().includes(searchTerm.toLowerCase()) ||
      n.summary.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="notes-ai-view" className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171424] via-[#0f0e1a] to-[#07060b] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#cfbcff]/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <FileText className="w-3 h-3" />
                ACADEMIC SYNTHESIS
              </span>
              <span className="text-xs font-mono text-zinc-400">CORNELL & SUMMARY ENGINE</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              Notes AI // Intelligent Lecture & Research Condenser
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Transform unstructured lectures, dense textbooks, or research papers into pristine
              Cornell notes, active recall review cues, and high-yield revision cheat sheets.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleExportMarkdown(selectedNote)}
              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-medium border border-white/10 flex items-center gap-2 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-[#cfbcff]" />
              <span>Export Markdown</span>
            </button>
            <button
              onClick={() => handleCopy(JSON.stringify(selectedNote, null, 2))}
              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-medium border border-white/10 flex items-center gap-2 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-[#cfbcff]" />}
              <span>{copied ? 'Copied' : 'Copy JSON'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Generator Input Section */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <label className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-semibold flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#cfbcff]" />
            Topic or Lecture Input
          </label>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-zinc-400">Depth:</span>
            {(['beginner', 'intermediate', 'advanced'] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDepth(d)}
                className={`px-2.5 py-1 rounded-lg text-xs font-mono uppercase transition-colors ${
                  depth === d
                    ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40'
                    : 'bg-white/5 text-zinc-400 border border-white/5 hover:text-white'
                }`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="E.g., Transformer Self-Attention, Dynamic Programming, Thermodynamics..."
            className="md:col-span-2 px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-zinc-500 text-sm focus:outline-none focus:border-[#cfbcff]/50"
          />
          <button
            onClick={handleGenerateNotes}
            disabled={isLoading || !topic.trim()}
            className="w-full py-3 px-5 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#6750a4] text-[#1c0f38] font-bold text-sm flex items-center justify-center gap-2 hover:opacity-95 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(207,188,255,0.25)]"
          >
            {isLoading ? (
              <>
                <div className="w-4 h-4 rounded-full border-2 border-[#1c0f38] border-t-transparent animate-spin" />
                <span>Synthesizing Notes...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Smart Notes</span>
              </>
            )}
          </button>
        </div>

        {/* Optional raw text toggle */}
        <details className="text-xs text-zinc-400 group">
          <summary className="cursor-pointer hover:text-zinc-200 transition-colors py-1 flex items-center gap-1.5 font-mono">
            <span>+ Paste raw lecture text or article paragraphs (Optional)</span>
          </summary>
          <div className="pt-2">
            <textarea
              rows={4}
              value={rawContent}
              onChange={(e) => setRawContent(e.target.value)}
              placeholder="Paste raw transcript, paper abstract, or chapter excerpt here for deep contextual summarization..."
              className="w-full p-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-[#cfbcff]/50 font-mono"
            />
          </div>
        </details>

        {/* Presets */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className="text-[11px] font-mono text-zinc-500 uppercase">Presets:</span>
          {PRESET_TOPICS.map((p) => (
            <button
              key={p}
              onClick={() => {
                setTopic(p);
                setRawContent('');
              }}
              className="px-2.5 py-1 rounded-full text-[11px] bg-white/[0.03] hover:bg-white/[0.08] text-zinc-300 border border-white/10 transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Main Workspace: Vault Sidebar + Active Note Sheet */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Notes Vault Library */}
        <div className="lg:col-span-4 space-y-3">
          <div className="p-4 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-semibold flex items-center gap-1.5">
                <Bookmark className="w-3.5 h-3.5" />
                Saved Notes Vault ({notesVault.length})
              </span>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-zinc-500" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search notes..."
                className="w-full pl-8 pr-3 py-1.5 rounded-lg bg-black/40 border border-white/10 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-[#cfbcff]/40"
              />
            </div>

            {/* Note list */}
            <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
              {filteredVault.map((note) => {
                const isSelected = selectedNote.id === note.id;
                return (
                  <div
                    key={note.id}
                    onClick={() => setSelectedNote(note)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer group ${
                      isSelected
                        ? 'bg-[#cfbcff]/10 border-[#cfbcff]/40 shadow-[inset_0_0_12px_rgba(207,188,255,0.08)]'
                        : 'bg-white/[0.02] border-white/5 hover:border-white/15'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="text-xs font-semibold text-white font-sora line-clamp-1 group-hover:text-[#cfbcff] transition-colors">
                        {note.title}
                      </h4>
                      {notesVault.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteNote(note.id);
                          }}
                          className="text-zinc-500 hover:text-rose-400 p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <p className="text-[11px] text-zinc-400 line-clamp-2 mt-1">{note.summary}</p>
                    <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                      <span className="text-[10px] font-mono text-zinc-500">
                        {new Date(note.createdAt).toLocaleDateString()}
                      </span>
                      <span className="text-[10px] font-mono text-[#cfbcff]/80 bg-[#cfbcff]/10 px-1.5 py-0.5 rounded">
                        {note.topic}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right: Active Cornell Note View */}
        <div className="lg:col-span-8 space-y-4">
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-6">
            {/* Note Top Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
              <div>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase bg-[#cfbcff]/10 text-[#cfbcff] border border-[#cfbcff]/20">
                  {selectedNote.topic}
                </span>
                <h3 className="text-lg sm:text-xl font-bold font-sora text-white mt-1">
                  {selectedNote.title}
                </h3>
              </div>

              {/* View Switcher Tabs */}
              <div className="flex items-center p-1 rounded-xl bg-black/40 border border-white/10">
                <button
                  onClick={() => setActiveNoteTab('cornell')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium font-sora transition-colors ${
                    activeNoteTab === 'cornell'
                      ? 'bg-[#cfbcff] text-[#1c0f38] font-bold shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Cornell Matrix
                </button>
                <button
                  onClick={() => setActiveNoteTab('takeaways')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium font-sora transition-colors ${
                    activeNoteTab === 'takeaways'
                      ? 'bg-[#cfbcff] text-[#1c0f38] font-bold shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Key Takeaways
                </button>
                <button
                  onClick={() => setActiveNoteTab('cheatsheet')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium font-sora transition-colors ${
                    activeNoteTab === 'cheatsheet'
                      ? 'bg-[#cfbcff] text-[#1c0f38] font-bold shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Cheat Sheet
                </button>
              </div>
            </div>

            {/* Executive Summary */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-[#cfbcff]/5 to-transparent border-l-2 border-[#cfbcff] bg-black/30">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#cfbcff] font-semibold block mb-1">
                Executive Synthesis
              </span>
              <p className="text-xs sm:text-sm text-zinc-200 leading-relaxed font-sans">
                {selectedNote.summary}
              </p>
            </div>

            {/* Content Display based on active tab */}
            {activeNoteTab === 'cornell' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 border border-white/10 rounded-xl overflow-hidden">
                  {/* Left Column: Cues & Review Questions (30%) */}
                  <div className="md:col-span-4 bg-black/40 p-4 border-b md:border-b-0 md:border-r border-white/10 space-y-3">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-[#cfbcff] font-bold flex items-center gap-1.5">
                      <Lightbulb className="w-3.5 h-3.5 text-amber-300" />
                      Cues & Inquiries
                    </span>
                    <div className="space-y-3">
                      {selectedNote.cornell.cues.map((cue, idx) => (
                        <div key={idx} className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5">
                          <span className="text-[10px] font-mono text-zinc-500 block mb-0.5">
                            Q{idx + 1}
                          </span>
                          <p className="text-xs font-medium text-zinc-200">{cue}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right Column: Detailed Explanations & Notes (70%) */}
                  <div className="md:col-span-8 bg-black/20 p-4 space-y-3">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-white font-bold flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5 text-[#cfbcff]" />
                      Detailed Lecture Notes
                    </span>
                    <div className="space-y-3">
                      {selectedNote.cornell.notes.map((note, idx) => (
                        <div key={idx} className="p-3 rounded-lg bg-white/[0.02] border border-white/5">
                          <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed">{note}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Bottom Row: Cornell Summary Box */}
                <div className="p-4 rounded-xl bg-black/50 border border-white/10">
                  <span className="text-[11px] font-mono uppercase tracking-wider text-emerald-300 font-bold block mb-1">
                    Bottom-Line Synthesis
                  </span>
                  <p className="text-xs sm:text-sm text-zinc-300 italic">
                    "{selectedNote.cornell.summary}"
                  </p>
                </div>
              </div>
            )}

            {activeNoteTab === 'takeaways' && (
              <div className="space-y-3">
                <span className="text-xs font-mono uppercase text-[#cfbcff] font-semibold tracking-wider block">
                  Core Intellectual Takeaways
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {selectedNote.keyTakeaways.map((takeaway, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-xl bg-black/40 border border-white/10 hover:border-[#cfbcff]/30 transition-colors"
                    >
                      <div className="w-6 h-6 rounded-lg bg-[#cfbcff]/20 text-[#cfbcff] text-xs font-mono font-bold flex items-center justify-center mb-2">
                        {idx + 1}
                      </div>
                      <p className="text-xs sm:text-sm text-zinc-200 leading-relaxed">{takeaway}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeNoteTab === 'cheatsheet' && (
              <div className="space-y-3">
                <span className="text-xs font-mono uppercase text-amber-300 font-semibold tracking-wider flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5" />
                  High-Yield Formula & Exam Trap Cheatsheet
                </span>
                <div className="space-y-2.5">
                  {selectedNote.cheatSheetBullets.map((bullet, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-amber-500/[0.04] border border-amber-500/20 flex items-start gap-3"
                    >
                      <div className="w-2 h-2 rounded-full bg-amber-400 mt-1.5 flex-shrink-0" />
                      <p className="text-xs sm:text-sm text-zinc-200 font-mono leading-relaxed">
                        {bullet}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Tags */}
            <div className="flex items-center gap-2 flex-wrap pt-2 border-t border-white/10">
              <Tag className="w-3 h-3 text-zinc-500" />
              {selectedNote.tags.map((t) => (
                <span
                  key={t}
                  className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/5 text-zinc-400 border border-white/10"
                >
                  #{t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
