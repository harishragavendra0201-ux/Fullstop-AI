import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, UserProfile } from '../types';
import {
  Send,
  Sparkles,
  Bot,
  User,
  Copy,
  Check,
  RotateCcw,
  AlertCircle,
  Zap,
  Trash2,
  Terminal,
  Maximize2,
  Minimize2,
  Expand,
} from 'lucide-react';

interface ChatViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
}

const SAMPLE_PROMPTS = [
  'Hi',
  'Explain quantum entanglement in 2 concise paragraphs',
  'Design an AI architecture for real-time edge processing',
  'Synthesize top 3 cognitive computing breakthroughs for 2026',
];

function cleanErrorMessage(raw: string): string {
  if (!raw) return 'Connection interrupted. Please tap Retry to reconnect.';
  let cleaned = raw.replace(/^Error:\s*/i, '').trim();
  try {
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed?.error?.message) {
        return parsed.error.message;
      }
    }
  } catch {
    // Ignore JSON parse error and use cleaned string
  }
  return cleaned;
}

export const ChatView: React.FC<ChatViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('fullstop_chat_history');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to parse chat history', e);
      }
    }
    return [
      {
        id: 'welcome-msg',
        role: 'assistant',
        content:
          'Hello. I am Fullstop AI, powered by the Gemini high-throughput neural architecture with automatic failover. Ask me anything from complex technical synthesis, system design, creative ideation, to quick questions.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [lastUserPrompt, setLastUserPrompt] = useState<string>('');
  const [screenMode, setScreenMode] = useState<'compact' | 'wide' | 'full'>(() => {
    const saved = localStorage.getItem('fullstop_chat_screen_mode');
    return (saved as 'compact' | 'wide' | 'full') || 'wide';
  });
  const [inputExpanded, setInputExpanded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  // Persist messages
  useEffect(() => {
    localStorage.setItem('fullstop_chat_history', JSON.stringify(messages));
  }, [messages]);

  // Persist screenMode
  useEffect(() => {
    localStorage.setItem('fullstop_chat_screen_mode', screenMode);
  }, [screenMode]);

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || input).trim();
    if (!textToSend || isLoading) return;

    // Check usage limit
    const allowed = onIncrementUsage();
    if (!allowed) {
      onOpenUpgrade();
      return;
    }

    setLastUserPrompt(textToSend);
    setErrorMessage(null);
    const userMsgId = 'user-' + Date.now();
    const newUserMessage: ChatMessage = {
      id: userMsgId,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // Filter out previous trailing error bubbles to keep chat clean
    const updatedMessages = [...messages.filter((m) => !m.error), newUserMessage];
    setMessages(updatedMessages);
    setInput('');

    setIsLoading(true);

    try {
      // Build conversation history for context (exclude errors)
      const historyContext = updatedMessages
        .filter((msg) => !msg.error)
        .slice(-8)
        .map((msg) => ({
          role: msg.role === 'assistant' ? 'model' : 'user',
          text: msg.content,
        }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: textToSend,
          history: historyContext,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || `Server responded with status ${res.status}`);
      }

      const assistantMessage: ChatMessage = {
        id: 'ai-' + Date.now(),
        role: 'assistant',
        content: data.reply || 'No response text received.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const friendlyMsg = cleanErrorMessage(err?.message || 'Connection failed.');
      setErrorMessage(friendlyMsg);

      const errorChatMsg: ChatMessage = {
        id: 'err-' + Date.now(),
        role: 'assistant',
        content: friendlyMsg,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        error: true,
      };
      setMessages((prev) => [...prev, errorChatMsg]);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 50);
    }
  };

  const handleRetryLast = () => {
    if (lastUserPrompt) {
      handleSendMessage(lastUserPrompt);
    } else {
      handleSendMessage();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearHistory = () => {
    if (confirm('Clear entire conversation history?')) {
      const reset = [
        {
          id: 'welcome-reset-' + Date.now(),
          role: 'assistant' as const,
          content: 'Session refreshed. What shall we analyze or construct next?',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ];
      setMessages(reset);
      localStorage.setItem('fullstop_chat_history', JSON.stringify(reset));
    }
  };

  return (
    <div
      id="ai-chat-view"
      className={`flex flex-col h-[calc(100vh-4.25rem)] mx-auto transition-all duration-300 ${
        screenMode === 'full'
          ? 'w-full max-w-[98%] px-2 sm:px-6'
          : screenMode === 'wide'
          ? 'w-full max-w-7xl px-4 sm:px-6'
          : 'w-full max-w-4xl px-4'
      }`}
    >
      {/* Top Bar with Clear & Engine status & Screen Size Extender */}
      <div className="flex flex-wrap items-center justify-between pb-3.5 border-b border-white/10 mb-3 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-[#cfbcff]/15 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff]">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-semibold text-white">Gemini Multi-Tier Engine</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                AUTO-FAILOVER READY
              </span>
            </div>
            <p className="text-[11px] text-zinc-400">Resilient neural server pipeline with automatic retries</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Screen Size Extender Controls */}
          <div className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-xl p-1">
            <button
              onClick={() => setScreenMode('compact')}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
                screenMode === 'compact'
                  ? 'bg-[#cfbcff]/20 text-[#cfbcff] font-bold border border-[#cfbcff]/30'
                  : 'text-zinc-400 hover:text-white'
              }`}
              title="Compact width"
            >
              Compact
            </button>
            <button
              onClick={() => setScreenMode('wide')}
              className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
                screenMode === 'wide'
                  ? 'bg-[#cfbcff]/20 text-[#cfbcff] font-bold border border-[#cfbcff]/30'
                  : 'text-zinc-400 hover:text-white'
              }`}
              title="Wide screen (Default) - Generous horizontal space"
            >
              Wide
            </button>
            <button
              onClick={() => setScreenMode('full')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-mono transition-all ${
                screenMode === 'full'
                  ? 'bg-[#cfbcff]/20 text-[#cfbcff] font-bold border border-[#cfbcff]/30'
                  : 'text-zinc-400 hover:text-white'
              }`}
              title="Full Canvas Width (Edge-to-edge max width)"
            >
              <Maximize2 className="w-3 h-3" />
              Full Width
            </button>
          </div>

          <button
            id="clear-chat-btn"
            onClick={handleClearHistory}
            className="p-2 rounded-xl text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 border border-white/10 transition-colors"
            title="Clear Chat History"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div
        id="chat-messages-container"
        className="flex-1 overflow-y-auto space-y-4 pr-1 sm:pr-2 scroll-smooth"
      >
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              id={`chat-message-${msg.id}`}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 text-xs font-semibold ${
                  isUser
                    ? 'bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38] shadow-[0_0_10px_rgba(207,188,255,0.3)]'
                    : msg.error
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-[#181423] border border-[#cfbcff]/30 text-[#cfbcff]'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              {/* Message Bubble */}
              <div
                className={`relative ${
                  screenMode === 'full'
                    ? 'max-w-[95%] sm:max-w-[90%] lg:max-w-[88%]'
                    : screenMode === 'wide'
                    ? 'max-w-[92%] sm:max-w-[86%] lg:max-w-[82%]'
                    : 'max-w-[85%] sm:max-w-[75%]'
                } rounded-2xl p-4 sm:p-5 text-sm leading-relaxed ${
                  isUser
                    ? 'bg-[#6750a4]/30 border border-[#cfbcff]/30 text-white rounded-tr-none shadow-[0_4px_20px_rgba(103,80,164,0.2)]'
                    : msg.error
                    ? 'bg-rose-950/40 border border-rose-500/40 text-rose-200 rounded-tl-none'
                    : 'glass-panel glass-card-edge bg-[#0e0c14]/90 text-zinc-200 rounded-tl-none'
                }`}
              >
                {/* Header info */}
                <div className="flex items-center justify-between gap-4 mb-1.5 pb-1 border-b border-white/5 text-[10px] font-mono text-zinc-400">
                  <span className="font-semibold text-zinc-300">
                    {isUser ? userProfile?.fullName || 'User' : 'Fullstop AI'}
                  </span>
                  <span>{msg.timestamp}</span>
                </div>

                {/* Content */}
                <div className="whitespace-pre-wrap font-sans select-text text-[13px] sm:text-sm">
                  {msg.content}
                </div>

                {/* Actions on Assistant Message */}
                {!isUser && !msg.error && (
                  <div className="mt-3 pt-2 border-t border-white/5 flex items-center justify-end gap-2">
                    <button
                      id={`copy-btn-${msg.id}`}
                      onClick={() => handleCopy(msg.content, msg.id)}
                      className="flex items-center gap-1 text-[11px] font-mono text-zinc-400 hover:text-[#cfbcff] transition-colors"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                {/* Inline Retry Action for Error Message */}
                {!isUser && msg.error && (
                  <div className="mt-3 pt-2 border-t border-rose-500/20 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[11px] font-mono text-rose-300/80">Spike in demand or connection delay</span>
                    <button
                      onClick={handleRetryLast}
                      className="flex items-center gap-1.5 text-xs font-mono font-semibold px-3 py-1.5 rounded-lg bg-rose-500/25 hover:bg-rose-500/40 text-white border border-rose-500/50 transition-colors shadow-sm"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Retry With Failover Engine</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Indicator */}
        {isLoading && (
          <div id="ai-chat-loading-indicator" className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-[#181423] border border-[#cfbcff]/30 text-[#cfbcff] flex items-center justify-center flex-shrink-0 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="glass-panel glass-card-edge bg-[#0e0c14]/90 rounded-2xl rounded-tl-none p-4 text-xs text-[#cfbcff] flex items-center gap-3">
              <div className="flex gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#cfbcff] animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 rounded-full bg-[#cfbcff] animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-[#cfbcff] animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="font-mono">Synthesizing response via Gemini Adaptive Engine...</span>
            </div>
          </div>
        )}

        {/* Error Notification banner */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-between text-xs text-rose-300">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={handleRetryLast}
              className="flex items-center gap-1.5 font-mono text-white hover:bg-rose-500/40 px-3 py-1 rounded-lg bg-rose-500/25 border border-rose-500/40 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Sample Prompt Chips */}
      <div className="py-2 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-[10px] font-mono text-zinc-500 uppercase flex-shrink-0">
          Quick queries:
        </span>
        {SAMPLE_PROMPTS.map((sample, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(sample)}
            disabled={isLoading}
            className="flex-shrink-0 text-xs text-zinc-300 hover:text-white px-3 py-1.5 rounded-full bg-white/[0.03] hover:bg-[#cfbcff]/15 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-mono"
          >
            "{sample}"
          </button>
        ))}
      </div>

      {/* Input Area */}
      <div className="relative pt-2">
        <div className="relative rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/95 p-2 shadow-2xl border border-white/10 focus-within:border-[#cfbcff]/50 transition-colors">
          <textarea
            id="chat-input-textarea"
            ref={inputRef}
            rows={inputExpanded ? 5 : 2}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Type your message for Fullstop AI... (Press Enter to send, Shift+Enter for new line)"
            disabled={isLoading}
            className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none resize-none px-3 py-2 font-sans transition-all duration-200"
          />

          <div className="flex items-center justify-between px-2 pt-1 border-t border-white/5">
            <div className="flex items-center gap-2 text-[11px] font-mono text-zinc-500">
              <Terminal className="w-3 h-3 text-[#cfbcff]" />
              <span>Enter to send</span>
              <span className="text-zinc-600">•</span>
              <span>Daily quota: {dailyLimit - dailyUsage} left</span>
              <span className="text-zinc-600">•</span>
              <button
                type="button"
                onClick={() => setInputExpanded(!inputExpanded)}
                className="text-zinc-400 hover:text-[#cfbcff] flex items-center gap-1 transition-colors font-mono text-[11px]"
                title={inputExpanded ? 'Collapse input' : 'Expand input rows'}
              >
                <Expand className="w-3 h-3" />
                <span>{inputExpanded ? 'Collapse' : 'Expand'}</span>
              </button>
            </div>

            <button
              id="chat-send-btn"
              onClick={() => handleSendMessage()}
              disabled={!input.trim() || isLoading}
              className={`py-2 px-4 rounded-xl font-sora font-semibold text-xs flex items-center gap-2 transition-all ${
                !input.trim() || isLoading
                  ? 'bg-white/5 text-zinc-500 cursor-not-allowed border border-white/5'
                  : 'bg-gradient-to-r from-[#cfbcff] via-[#b69df8] to-[#9a7dec] text-[#1c0f38] hover:shadow-[0_0_20px_rgba(207,188,255,0.4)] glow-button cursor-pointer'
              }`}
            >
              <span>Send</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
