import React, { useState, useEffect } from 'react';
import { QuizQuestionItem, QuizSession, UserProfile } from '../types';
import {
  HelpCircle,
  Sparkles,
  CheckCircle2,
  XCircle,
  Clock,
  RotateCcw,
  ChevronRight,
  ChevronLeft,
  Lightbulb,
  Award,
  Zap,
  TrendingUp,
  Brain,
} from 'lucide-react';

interface QuizGeneratorViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const PRESET_TOPICS = [
  'Data Structures & Asymptotic Complexity',
  'Modern Web Architecture & Security',
  'Deep Learning & Attention Mechanisms',
  'Operating Systems & Concurrency Locks',
  'General Scientific Breakthroughs',
];

const INITIAL_QUIZ: QuizSession = {
  id: 'quiz-init-1',
  title: 'Diagnostic Mastery: Transformer & Attention Systems',
  topic: 'Machine Learning',
  difficulty: 'intermediate',
  timeLimitSeconds: 240,
  questions: [
    {
      id: 'q-1',
      question:
        'In scaled dot-product attention, why is the matrix multiplication (Q · K^T) divided by √d_k?',
      options: [
        'To prevent large values from pushing softmax into regions with vanishingly small gradients',
        'To scale down the input dimensions so it can fit on mobile TPU microcontrollers',
        'To ensure the attention weights become strictly non-zero Gaussian distributions',
        'To invert the causal mask and enable backward autoregressive prediction',
      ],
      correctIndex: 0,
      explanation:
        'For large projection dimensions d_k, the dot products grow large in magnitude, pushing the softmax function into regions with extremely small gradients. Dividing by √d_k counters this variance expansion.',
      hint: 'Think about gradient propagation through softmax with high variance dot products.',
      difficulty: 'medium',
    },
    {
      id: 'q-2',
      question:
        'What is the fundamental theoretical flaw of pure self-attention without Positional Encodings?',
      options: [
        'It cannot compute dot products of differing lengths',
        'It is permutation-equivariant and ignores word sequence order',
        'It causes catastrophic forgetting across multiple attention heads',
        'It requires linear O(N) memory rather than quadratic O(N²)',
      ],
      correctIndex: 1,
      explanation:
        'Self-attention operates as a set-to-set operator; swapping words results in the same attention values permuted accordingly. Positional vectors must be added to provide sequential topology.',
      hint: 'What happens if you scramble the words in a sentence without order cues?',
      difficulty: 'medium',
    },
    {
      id: 'q-3',
      question:
        'Which masking technique is strictly required in decoder self-attention to maintain autoregressive integrity?',
      options: [
        'Causal upper-triangular masking to block future token visibility',
        'Dropout masking on all Query matrices',
        'Random token replacement with [MASK] tokens like BERT',
        'Zero-padding on odd indexed attention heads',
      ],
      correctIndex: 0,
      explanation:
        'In generative autoregressive generation, a token at step i must not attend to step i+1. Causal upper-triangular masking sets subsequent attention logits to -∞ before softmax.',
      hint: 'Future knowledge must be concealed during next-token prediction.',
      difficulty: 'easy',
    },
    {
      id: 'q-4',
      question:
        'What is the asymptotic memory complexity of standard full self-attention with respect to sequence length N?',
      options: ['O(N log N)', 'O(1)', 'O(N²)', 'O(N³)'],
      correctIndex: 2,
      explanation:
        'Standard self-attention computes an N x N matrix comparing every token with every other token, resulting in quadratic O(N²) memory and compute complexity.',
      hint: 'Matrix multiplication of (N x d) and (d x N).',
      difficulty: 'easy',
    },
  ],
  userAnswers: {},
  score: 0,
  completed: false,
};

export const QuizGeneratorView: React.FC<QuizGeneratorViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [topic, setTopic] = useState(initialPrompt || '');
  const [difficulty, setDifficulty] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [questionCount, setQuestionCount] = useState<number>(4);
  const [isLoading, setIsLoading] = useState(false);

  const [currentQuiz, setCurrentQuiz] = useState<QuizSession>(INITIAL_QUIZ);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showExplanation, setShowExplanation] = useState<Record<number, boolean>>({});
  const [showHint, setShowHint] = useState<Record<number, boolean>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState<number>(INITIAL_QUIZ.timeLimitSeconds);
  const [isTimerRunning, setIsTimerRunning] = useState(true);

  useEffect(() => {
    if (initialPrompt && initialPrompt !== topic) {
      setTopic(initialPrompt);
    }
  }, [initialPrompt]);

  // Countdown timer
  useEffect(() => {
    if (!isTimerRunning || isSubmitted || timeLeft <= 0) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          handleSubmitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isTimerRunning, isSubmitted, timeLeft]);

  const handleGenerateQuiz = async () => {
    if (!topic.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          difficulty,
          questionCount,
        }),
      });
      const data = await res.json();
      if (data.success && data.quiz) {
        setCurrentQuiz(data.quiz);
        setCurrentQuestionIndex(0);
        setSelectedAnswers({});
        setShowExplanation({});
        setShowHint({});
        setIsSubmitted(false);
        setTimeLeft(data.quiz.timeLimitSeconds || questionCount * 60);
        setIsTimerRunning(true);
      }
    } catch (err) {
      console.error('Quiz AI generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectOption = (questionIdx: number, optionIdx: number) => {
    if (isSubmitted) return;
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionIdx]: optionIdx,
    }));
    // Reveal explanation instantly for active learning
    setShowExplanation((prev) => ({
      ...prev,
      [questionIdx]: true,
    }));
  };

  const handleSubmitQuiz = () => {
    setIsSubmitted(true);
    setIsTimerRunning(false);

    // Calculate score
    let correctCount = 0;
    currentQuiz.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctIndex) {
        correctCount++;
      }
    });
    const calculatedScore = Math.round((correctCount / currentQuiz.questions.length) * 100);
    setCurrentQuiz((prev) => ({
      ...prev,
      score: calculatedScore,
      completed: true,
      userAnswers: selectedAnswers,
      completedAt: new Date().toISOString(),
    }));
  };

  const handleResetQuiz = () => {
    setSelectedAnswers({});
    setShowExplanation({});
    setShowHint({});
    setIsSubmitted(false);
    setTimeLeft(currentQuiz.timeLimitSeconds || 240);
    setIsTimerRunning(true);
    setCurrentQuestionIndex(0);
  };

  const currentQ = currentQuiz.questions[currentQuestionIndex] || currentQuiz.questions[0];
  const totalQuestions = currentQuiz.questions.length;
  const answeredCount = Object.keys(selectedAnswers).length;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const getGradeInfo = (score: number) => {
    if (score >= 90) return { grade: 'S-TIER', color: 'text-emerald-400', label: 'Exceptional Mastery' };
    if (score >= 75) return { grade: 'A-TIER', color: 'text-[#cfbcff]', label: 'Strong Proficiency' };
    if (score >= 60) return { grade: 'B-TIER', color: 'text-amber-400', label: 'Solid Foundation' };
    return { grade: 'REVISE', color: 'text-rose-400', label: 'Review Concepts' };
  };

  return (
    <div id="quiz-generator-view" className="max-w-6xl mx-auto space-y-6 pb-12">
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#1b152e] via-[#100d1c] to-[#08060f] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <HelpCircle className="w-3 h-3" />
                ADAPTIVE TESTING
              </span>
              <span className="text-xs font-mono text-zinc-400">INSTANT GRADING & RATIONALE</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              AI Quiz Generator // Diagnostic Challenge Engine
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Generate custom diagnostic challenges on any topic. Features timed testing, instant
              option rationale, distractor trap analysis, and performance scorecards.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-4 py-2 rounded-xl bg-black/40 border border-white/10 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-300" />
              <div className="text-right">
                <span className="text-[10px] font-mono text-zinc-400 block uppercase">Timer</span>
                <span className="text-sm font-mono font-bold text-white">
                  {formatTime(timeLeft)}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Generator Controls */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-6">
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="Enter challenge topic (e.g. Distributed Consensus, Python Generators, Microeconomics)..."
              className="w-full px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-zinc-500 text-sm focus:outline-none focus:border-[#cfbcff]/50"
            />
          </div>

          <div className="md:col-span-3 flex items-center gap-1.5">
            {(['beginner', 'intermediate', 'advanced'] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDifficulty(d)}
                className={`flex-1 py-2.5 rounded-lg text-xs font-mono uppercase transition-colors text-center ${
                  difficulty === d
                    ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40'
                    : 'bg-white/5 text-zinc-400 border border-white/5 hover:text-white'
                }`}
              >
                {d.slice(0, 3)}
              </button>
            ))}
          </div>

          <div className="md:col-span-3 flex items-center gap-2">
            <button
              onClick={handleGenerateQuiz}
              disabled={isLoading || !topic.trim()}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#6750a4] text-[#1c0f38] font-bold text-sm flex items-center justify-center gap-2 hover:opacity-95 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(207,188,255,0.25)]"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-[#1c0f38] border-t-transparent animate-spin" />
                  <span>Generating...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Quiz</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className="text-[11px] font-mono text-zinc-500 uppercase">Presets:</span>
          {PRESET_TOPICS.map((p) => (
            <button
              key={p}
              onClick={() => setTopic(p)}
              className="px-2.5 py-1 rounded-full text-[11px] bg-white/[0.03] hover:bg-white/[0.08] text-zinc-300 border border-white/10 transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Main Interactive Quiz Section */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-6">
        {/* Quiz Progress & Question Tracker */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div>
            <span className="text-xs font-mono text-[#cfbcff] uppercase tracking-wider font-semibold">
              {currentQuiz.topic} • {currentQuiz.difficulty.toUpperCase()}
            </span>
            <h3 className="text-base sm:text-lg font-bold font-sora text-white">
              {currentQuiz.title}
            </h3>
          </div>

          {/* Question Index Pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {currentQuiz.questions.map((_, idx) => {
              const isCurrent = idx === currentQuestionIndex;
              const isAnswered = selectedAnswers[idx] !== undefined;
              const isCorrect = isAnswered && selectedAnswers[idx] === currentQuiz.questions[idx].correctIndex;

              return (
                <button
                  key={idx}
                  onClick={() => setCurrentQuestionIndex(idx)}
                  className={`w-8 h-8 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center ${
                    isCurrent
                      ? 'ring-2 ring-[#cfbcff] bg-[#cfbcff] text-[#1c0f38]'
                      : isSubmitted
                      ? isCorrect
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                        : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                      : isAnswered
                      ? 'bg-white/20 text-white'
                      : 'bg-white/5 text-zinc-500 hover:text-white'
                  }`}
                >
                  {idx + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Question Box */}
        {currentQ && (
          <div className="space-y-6">
            <div className="flex items-start justify-between gap-3">
              <span className="text-xs font-mono text-zinc-400">
                Question {currentQuestionIndex + 1} of {totalQuestions}
              </span>
              {currentQ.hint && (
                <button
                  onClick={() =>
                    setShowHint((prev) => ({
                      ...prev,
                      [currentQuestionIndex]: !prev[currentQuestionIndex],
                    }))
                  }
                  className="text-xs font-mono text-amber-300 hover:text-amber-200 flex items-center gap-1"
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>{showHint[currentQuestionIndex] ? 'Hide Hint' : 'Show Hint'}</span>
                </button>
              )}
            </div>

            {showHint[currentQuestionIndex] && currentQ.hint && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs font-mono">
                💡 <strong>Hint:</strong> {currentQ.hint}
              </div>
            )}

            <h4 className="text-base sm:text-lg font-medium text-zinc-100 font-sans leading-relaxed">
              {currentQ.question}
            </h4>

            {/* Options */}
            <div className="space-y-3">
              {currentQ.options.map((option, optIdx) => {
                const isSelected = selectedAnswers[currentQuestionIndex] === optIdx;
                const isCorrectOption = optIdx === currentQ.correctIndex;
                const showFeedback = selectedAnswers[currentQuestionIndex] !== undefined || isSubmitted;

                let stateClasses = 'bg-white/[0.02] border-white/10 hover:border-white/25 hover:bg-white/[0.04] text-zinc-300';
                if (showFeedback) {
                  if (isCorrectOption) {
                    stateClasses = 'bg-emerald-500/15 border-emerald-500/50 text-emerald-200 shadow-[0_0_15px_rgba(16,185,129,0.15)]';
                  } else if (isSelected && !isCorrectOption) {
                    stateClasses = 'bg-rose-500/15 border-rose-500/50 text-rose-200';
                  } else {
                    stateClasses = 'bg-black/30 border-white/5 opacity-50 text-zinc-500';
                  }
                } else if (isSelected) {
                  stateClasses = 'bg-[#cfbcff]/15 border-[#cfbcff]/50 text-white';
                }

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(currentQuestionIndex, optIdx)}
                    className={`w-full p-4 rounded-xl border text-left flex items-start gap-3 transition-all ${stateClasses}`}
                  >
                    <div
                      className={`w-6 h-6 rounded-lg text-xs font-mono font-bold flex items-center justify-center flex-shrink-0 mt-0.5 ${
                        showFeedback && isCorrectOption
                          ? 'bg-emerald-500 text-black'
                          : showFeedback && isSelected && !isCorrectOption
                          ? 'bg-rose-500 text-white'
                          : isSelected
                          ? 'bg-[#cfbcff] text-[#1c0f38]'
                          : 'bg-white/10 text-zinc-300'
                      }`}
                    >
                      {String.fromCharCode(65 + optIdx)}
                    </div>
                    <span className="text-sm font-sans flex-1 leading-relaxed">{option}</span>
                    {showFeedback && isCorrectOption && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                    )}
                    {showFeedback && isSelected && !isCorrectOption && (
                      <XCircle className="w-5 h-5 text-rose-400 flex-shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Explanation card */}
            {(showExplanation[currentQuestionIndex] || isSubmitted) && currentQ.explanation && (
              <div className="p-4 rounded-xl bg-[#cfbcff]/5 border border-[#cfbcff]/20 space-y-1.5 animate-fadeIn">
                <span className="text-[11px] font-mono uppercase tracking-wider text-[#cfbcff] font-bold flex items-center gap-1.5">
                  <Brain className="w-3.5 h-3.5 text-[#cfbcff]" />
                  Conceptual Rationale & Trap Analysis
                </span>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-sans">
                  {currentQ.explanation}
                </p>
              </div>
            )}

            {/* Navigation Bottom Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-white/10">
              <button
                disabled={currentQuestionIndex === 0}
                onClick={() => setCurrentQuestionIndex((prev) => Math.max(0, prev - 1))}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-medium border border-white/10 disabled:opacity-30 flex items-center gap-1.5 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous</span>
              </button>

              <div className="flex items-center gap-2">
                {!isSubmitted && (
                  <button
                    onClick={handleSubmitQuiz}
                    disabled={answeredCount === 0}
                    className="px-5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold font-sora flex items-center gap-2 transition-colors disabled:opacity-40"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit Scorecard</span>
                  </button>
                )}

                {currentQuestionIndex < totalQuestions - 1 ? (
                  <button
                    onClick={() => setCurrentQuestionIndex((prev) => Math.min(totalQuestions - 1, prev + 1))}
                    className="px-4 py-2 rounded-xl bg-[#cfbcff]/20 hover:bg-[#cfbcff]/30 text-[#cfbcff] text-xs font-bold border border-[#cfbcff]/40 flex items-center gap-1.5 transition-colors"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={handleSubmitQuiz}
                    disabled={isSubmitted}
                    className="px-4 py-2 rounded-xl bg-[#cfbcff] text-[#1c0f38] text-xs font-bold flex items-center gap-1.5 transition-colors disabled:opacity-50 shadow"
                  >
                    <span>Finish Quiz</span>
                    <Award className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Scorecard Modal or Bottom Panel when submitted */}
        {isSubmitted && (
          <div className="p-6 rounded-2xl bg-gradient-to-br from-[#1c142c] to-[#0c0a12] border border-[#cfbcff]/40 space-y-4 shadow-[0_0_30px_rgba(207,188,255,0.15)] animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38] flex flex-col items-center justify-center font-sora font-black shadow-lg">
                  <span className="text-xl leading-none">{currentQuiz.score}%</span>
                  <span className="text-[10px] font-mono tracking-widest uppercase mt-0.5">SCORE</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-sm font-mono font-bold uppercase ${getGradeInfo(currentQuiz.score).color}`}>
                      {getGradeInfo(currentQuiz.score).grade}
                    </span>
                    <span className="text-xs text-zinc-400">• {getGradeInfo(currentQuiz.score).label}</span>
                  </div>
                  <h4 className="text-base font-bold text-white font-sora mt-0.5">
                    Quiz Completed: {Object.values(selectedAnswers).filter((ans, i) => ans === currentQuiz.questions[i]?.correctIndex).length} of {totalQuestions} Correct
                  </h4>
                </div>
              </div>

              <button
                onClick={handleResetQuiz}
                className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold flex items-center gap-2 border border-white/20 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5 text-[#cfbcff]" />
                <span>Retake Quiz</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
