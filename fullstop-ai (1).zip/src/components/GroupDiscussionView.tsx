import React, { useState } from 'react';
import { GDPersona, GDSpeechTurn, GDScorecard, UserProfile } from '../types';
import {
  Users,
  Sparkles,
  Send,
  Award,
  RotateCcw,
  Mic,
  MessageSquare,
  Play,
  CheckCircle,
  HelpCircle,
  TrendingUp,
} from 'lucide-react';

interface GroupDiscussionViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const DEFAULT_PERSONAS: GDPersona[] = [
  {
    id: 'p-maya',
    name: 'Maya Chen',
    role: 'Moderator',
    avatarBg: 'MC',
    perspective: 'Diplomatic, ensures balanced speaking time, frames central tradeoffs.',
  },
  {
    id: 'p-aris',
    name: 'Dr. Aris Thorne',
    role: 'Proponent',
    avatarBg: 'AT',
    perspective: 'Emphasizes empirical productivity gains, economic leverage, and macro expansion.',
  },
  {
    id: 'p-elena',
    name: 'Elena Rostova',
    role: 'Skeptic',
    avatarBg: 'ER',
    perspective: 'Points out systemic fragilities, junior mentorship voids, and security liabilities.',
  },
  {
    id: 'p-marcus',
    name: 'Marcus Vance',
    role: 'Visionary',
    avatarBg: 'MV',
    perspective: 'Re-frames the question toward autonomous swarms and entirely new job paradigms.',
  },
];

const INITIAL_TURNS: GDSpeechTurn[] = [
  {
    id: 'gd-t-0',
    speakerId: 'p-maya',
    speakerName: 'Maya Chen',
    role: 'Moderator',
    text: 'Welcome everyone to today’s discussion: "Will Autonomous AI Agents Displace Junior Engineers or 10x Them?" Let us keep our arguments focused on systemic impact, skill acquisition, and industry reality. Aris, would you like to kick off?',
    timestamp: '10:00 AM',
  },
  {
    id: 'gd-t-1',
    speakerId: 'p-aris',
    speakerName: 'Dr. Aris Thorne',
    role: 'Quantitative Proponent',
    text: 'Thank you Maya. The data is unmistakable. GitHub and Stanford studies show developers with generative copilots ship code 55% faster. Far from displacing junior engineers, AI abstracts boilerplate syntax, allowing a junior engineer with 1 year of experience to command the leverage previously reserved for senior staff.',
    timestamp: '10:01 AM',
  },
  {
    id: 'gd-t-2',
    speakerId: 'p-elena',
    speakerName: 'Elena Rostova',
    role: 'Critical Realist',
    text: 'I respectfully push back, Aris. If an agent writes 80% of the code, how does a junior engineer develop deep intuition for edge cases, memory leaks, and distributed race conditions? If junior hiring freezes because "one senior with five agents suffices," the entire apprenticeship pipeline collapses.',
    timestamp: '10:02 AM',
  },
];

export const GroupDiscussionView: React.FC<GroupDiscussionViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [topic, setTopic] = useState(
    initialPrompt || 'Will Autonomous AI Agents Displace Junior Engineers or 10x Them?'
  );
  const [turns, setTurns] = useState<GDSpeechTurn[]>(INITIAL_TURNS);
  const [userSpeech, setUserSpeech] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [scorecard, setScorecard] = useState<GDScorecard | null>(null);
  const [isScorecardOpen, setIsScorecardOpen] = useState(false);

  const handleSimulateNextAgent = async () => {
    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/gd/simulate-turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          personas: DEFAULT_PERSONAS,
          previousTurns: turns,
        }),
      });
      const data = await res.json();
      if (data.success && data.turn) {
        setTurns((prev) => [...prev, data.turn]);
      }
    } catch (err) {
      console.error('GD Turn error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUserContribute = async () => {
    if (!userSpeech.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    const newTurn: GDSpeechTurn = {
      id: `gd-user-${Date.now()}`,
      speakerId: 'user-candidate',
      speakerName: userProfile?.fullName || 'Candidate (You)',
      role: 'Candidate',
      text: userSpeech.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const updatedTurns = [...turns, newTurn];
    setTurns(updatedTurns);
    setUserSpeech('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gd/simulate-turn', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          personas: DEFAULT_PERSONAS,
          previousTurns: updatedTurns,
        }),
      });
      const data = await res.json();
      if (data.success && data.turn) {
        setTurns((prev) => [...prev, data.turn]);
      }
    } catch (err) {
      console.error('GD contribution response error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEvaluateScorecard = async () => {
    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/gd/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic,
          candidateTurns: turns.filter((t) => t.speakerId === 'user-candidate'),
          allTurns: turns,
        }),
      });
      const data = await res.json();
      if (data.success && data.scorecard) {
        setScorecard(data.scorecard);
        setIsScorecardOpen(true);
      }
    } catch (err) {
      console.error('GD evaluation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = () => {
    setTurns(INITIAL_TURNS);
    setScorecard(null);
    setIsScorecardOpen(false);
  };

  return (
    <div id="group-discussion-view" className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171424] via-[#100d1c] to-[#07060c] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <Users className="w-3 h-3" />
                MULTI-AGENT ROUNDTABLE
              </span>
              <span className="text-xs font-mono text-zinc-400">EXECUTIVE & MBA GD ARENA</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              AI Group Discussion Arena // Collaborative Debate Simulator
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Simulate rigorous corporate, university, and competitive exam group discussions with four
              distinct AI personas. Jump in with your perspective and receive an executive scorecard.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleEvaluateScorecard}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#6750a4] text-[#1c0f38] text-xs font-bold font-sora flex items-center gap-1.5 hover:opacity-95 shadow transition-all"
            >
              <Award className="w-4 h-4" />
              <span>Get GD Scorecard</span>
            </button>
            <button
              onClick={handleReset}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-colors"
              title="Reset discussion"
            >
              <RotateCcw className="w-4 h-4 text-[#cfbcff]" />
            </button>
          </div>
        </div>
      </div>

      {/* Roundtable Personas Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {DEFAULT_PERSONAS.map((p) => (
          <div
            key={p.id}
            className="p-3.5 rounded-xl bg-[#0e0c14]/90 border border-white/10 flex items-center gap-3"
          >
            <div className="w-9 h-9 rounded-xl bg-[#cfbcff]/20 text-[#cfbcff] font-sora font-bold text-xs flex items-center justify-center flex-shrink-0 border border-[#cfbcff]/30">
              {p.avatarBg}
            </div>
            <div className="min-w-0">
              <h5 className="text-xs font-bold text-white font-sora truncate">{p.name}</h5>
              <span className="text-[10px] font-mono text-zinc-400 block truncate">{p.role}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Discussion Main Flow */}
      <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
          <div>
            <span className="text-[10px] font-mono text-[#cfbcff] uppercase tracking-wider block">
              Current Agenda Topic
            </span>
            <h3 className="text-sm sm:text-base font-bold text-white font-sora">{topic}</h3>
          </div>

          <button
            onClick={handleSimulateNextAgent}
            disabled={isLoading}
            className="px-3.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono text-zinc-200 flex items-center gap-2 transition-colors self-start sm:self-auto"
          >
            <Play className="w-3.5 h-3.5 text-[#cfbcff]" />
            <span>Pass Mic / Next AI Turn</span>
          </button>
        </div>

        {/* Turns stream */}
        <div className="space-y-3.5 max-h-[480px] overflow-y-auto pr-1">
          {turns.map((turn) => {
            const isUser = turn.speakerId === 'user-candidate';
            return (
              <div
                key={turn.id}
                className={`p-4 rounded-xl border transition-all ${
                  isUser
                    ? 'bg-[#cfbcff]/15 border-[#cfbcff]/40 shadow-[inset_0_0_15px_rgba(207,188,255,0.08)]'
                    : 'bg-white/[0.02] border-white/5'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-sora text-white">{turn.speakerName}</span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/5 text-zinc-400 border border-white/10">
                      {turn.role}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500">{turn.timestamp}</span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-sans">
                  {turn.text}
                </p>
              </div>
            );
          })}
          {isLoading && (
            <div className="p-3 text-xs font-mono text-zinc-400 flex items-center gap-2">
              <div className="w-3.5 h-3.5 rounded-full border-2 border-[#cfbcff] border-t-transparent animate-spin" />
              <span>Participant is weighing arguments...</span>
            </div>
          )}
        </div>

        {/* User Speak Box */}
        <div className="pt-3 border-t border-white/10 space-y-2">
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={userSpeech}
              onChange={(e) => setUserSpeech(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleUserContribute()}
              placeholder="State your viewpoint, challenge an argument, or provide a synthesis..."
              className="flex-1 px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none focus:border-[#cfbcff]/50"
            />
            <button
              onClick={handleUserContribute}
              disabled={isLoading || !userSpeech.trim()}
              className="px-5 py-3 rounded-xl bg-[#cfbcff] text-[#1c0f38] font-bold text-xs flex items-center gap-2 hover:opacity-90 disabled:opacity-40 transition-opacity shadow"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Enter Discussion</span>
            </button>
          </div>
        </div>
      </div>

      {/* Scorecard Modal or Drawer */}
      {isScorecardOpen && scorecard && (
        <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-br from-[#1b1429] to-[#0b0912] border border-[#cfbcff]/40 space-y-6 shadow-[0_0_30px_rgba(207,188,255,0.15)] animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-[#cfbcff] text-[#1c0f38] flex flex-col items-center justify-center font-sora font-black">
                <span className="text-xl leading-none">{scorecard.overallScore}</span>
                <span className="text-[9px] font-mono tracking-widest mt-0.5">/100</span>
              </div>
              <div>
                <h3 className="text-lg font-bold font-sora text-white">
                  Executive GD Performance Scorecard
                </h3>
                <p className="text-xs text-zinc-300">
                  Evaluated across analytical reasoning, initiative, listening, and clarity.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsScorecardOpen(false)}
              className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/15 text-white text-xs font-mono self-start sm:self-auto"
            >
              Close
            </button>
          </div>

          {/* 4 Score Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: 'Communication & Articulation', val: scorecard.communicationScore },
              { label: 'Logical Coherence', val: scorecard.logicScore },
              { label: 'Leadership & Framing', val: scorecard.leadershipScore },
              { label: 'Active Listening & Rebuttal', val: scorecard.listeningScore },
            ].map((metric, i) => (
              <div key={i} className="p-3.5 rounded-xl bg-black/40 border border-white/10 text-center">
                <span className="text-[10px] font-mono text-zinc-400 block uppercase mb-1">
                  {metric.label}
                </span>
                <span className="text-lg font-bold font-mono text-[#cfbcff]">{metric.val}%</span>
              </div>
            ))}
          </div>

          {/* Qualitative Strengths and Improvements */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-emerald-500/[0.05] border border-emerald-500/20 space-y-2">
              <span className="text-xs font-mono uppercase text-emerald-300 font-bold block">
                Demonstrated Strengths
              </span>
              <ul className="text-xs text-zinc-300 space-y-1.5 list-disc pl-4">
                {scorecard.strengths.map((s, idx) => (
                  <li key={idx}>{s}</li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-amber-500/[0.05] border border-amber-500/20 space-y-2">
              <span className="text-xs font-mono uppercase text-amber-300 font-bold block">
                High-Impact Opportunities for Improvement
              </span>
              <ul className="text-xs text-zinc-300 space-y-1.5 list-disc pl-4">
                {scorecard.areasForImprovement.map((a, idx) => (
                  <li key={idx}>{a}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
