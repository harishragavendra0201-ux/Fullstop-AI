import React from 'react';

interface FullstopLogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  animated?: boolean;
  withGlow?: boolean;
  className?: string;
}

const SIZE_MAP = {
  xs: 'w-5 h-5',
  sm: 'w-7 h-7',
  md: 'w-9 h-9',
  lg: 'w-12 h-12',
  xl: 'w-16 h-16',
  '2xl': 'w-20 h-20',
};

export const FullstopLogo: React.FC<FullstopLogoProps> = ({
  size = 'md',
  animated = true,
  withGlow = true,
  className = '',
}) => {
  const sizeClass = SIZE_MAP[size] || SIZE_MAP.md;

  return (
    <div
      className={`relative inline-flex items-center justify-center flex-shrink-0 ${sizeClass} ${className}`}
      aria-label="Fullstop AI Logo"
    >
      {/* Ambient Radial Glow */}
      {withGlow && (
        <div
          className={`absolute inset-0 rounded-full bg-gradient-to-tr from-[#9a7dec]/30 via-[#cfbcff]/20 to-transparent blur-md pointer-events-none ${
            animated ? 'animate-pulse' : ''
          }`}
          style={{ animationDuration: '3s' }}
        />
      )}

      <svg
        viewBox="0 0 48 48"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full relative z-10 drop-shadow-[0_2px_10px_rgba(207,188,255,0.4)]"
      >
        <defs>
          {/* Outer Ring Gradient */}
          <linearGradient id="fullstop-grad-outer" x1="4" y1="4" x2="44" y2="44" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#cfbcff" />
            <stop offset="50%" stopColor="#9a7dec" />
            <stop offset="100%" stopColor="#4f378b" />
          </linearGradient>

          {/* Core Singularity Gradient */}
          <radialGradient id="fullstop-grad-core" cx="24" cy="24" r="14" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="35%" stopColor="#cfbcff" />
            <stop offset="70%" stopColor="#9a7dec" />
            <stop offset="100%" stopColor="#21005d" />
          </radialGradient>

          {/* Accents Gradient */}
          <linearGradient id="fullstop-grad-orbit" x1="10" y1="24" x2="38" y2="24" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#e8def8" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#9a7dec" stopOpacity="0.4" />
          </linearGradient>

          {/* Dot Glow Filter */}
          <filter id="fullstop-glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="1.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Outer Cybernetic Hex-Shield Path */}
        <path
          d="M24 4L39 12.66V35.34L24 44L9 35.34V12.66L24 4Z"
          stroke="url(#fullstop-grad-outer)"
          strokeWidth="2"
          strokeLinejoin="round"
          className="opacity-70"
        />

        {/* Dynamic Orbital Ellipse 1 */}
        <ellipse
          cx="24"
          cy="24"
          rx="17"
          ry="9"
          transform="rotate(-28 24 24)"
          stroke="url(#fullstop-grad-orbit)"
          strokeWidth="1.6"
          strokeDasharray="4 2"
          strokeLinecap="round"
          className="opacity-80"
        />

        {/* Dynamic Orbital Ellipse 2 */}
        <ellipse
          cx="24"
          cy="24"
          rx="17"
          ry="9"
          transform="rotate(32 24 24)"
          stroke="url(#fullstop-grad-outer)"
          strokeWidth="1.2"
          strokeDasharray="3 3"
          className="opacity-60"
        />

        {/* Precision Geometric Bracket Accents */}
        <path
          d="M17 9L24 5L31 9"
          stroke="#cfbcff"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="opacity-90"
        />
        <path
          d="M17 39L24 43L31 39"
          stroke="#9a7dec"
          strokeWidth="1.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="opacity-80"
        />

        {/* The Definitive Quantum Core (The "Full Stop" Singularity) */}
        <circle
          cx="24"
          cy="24"
          r="7.5"
          fill="url(#fullstop-grad-core)"
          filter="url(#fullstop-glow)"
        />

        {/* Pure Brilliant Center Apex Dot */}
        <circle
          cx="24"
          cy="24"
          r="3"
          fill="#ffffff"
          className="drop-shadow-[0_0_4px_#ffffff]"
        />

        {/* Micro Satellite Orbit Node */}
        <circle
          cx="38"
          cy="18"
          r="1.8"
          fill="#cfbcff"
          className="animate-ping opacity-75"
          style={{ animationDuration: '4s' }}
        />
        <circle cx="38" cy="18" r="1.5" fill="#ffffff" />
      </svg>
    </div>
  );
};
