import React from 'react';
import { NavigationTab, UserProfile } from '../types';
import { FullstopLogo } from './FullstopLogo';
import { Menu, Sparkles, Crown, Zap } from 'lucide-react';

interface HeaderProps {
  activeTab: NavigationTab;
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onOpenUpgrade: () => void;
  onToggleMobileMenu: () => void;
}

const TAB_TITLES: Record<NavigationTab, { title: string; subtitle: string }> = {
  dashboard: {
    title: 'Command Center',
    subtitle: 'Nexus Core OS • Cognitive Workspace',
  },
  'daily-news': {
    title: 'Daily Update News',
    subtitle: 'Global Tech Radar • Strategic AI & Breakthrough Pulse',
  },
  chat: {
    title: 'AI Chat',
    subtitle: 'Gemini Resilient Core • High Density Reasoning',
  },
  'chefly-ai': {
    title: 'AI Chefly AI',
    subtitle: 'Kitchen Helper for Mothers • Fridge Magic, Kids Lunchboxes & Stress-Free Cooking',
  },
  'study-mode': {
    title: 'AI Study Assistant',
    subtitle: 'Feynman Learning • Active Recall & Socratic Tutoring',
  },
  'notes-ai': {
    title: 'Notes AI',
    subtitle: 'Smart Cornell Notes • Automatic Summarizer & Cheatsheets',
  },
  'quiz-generator': {
    title: 'AI Quiz Generator',
    subtitle: 'Adaptive Diagnostics • Timed Testing & Rich Explanations',
  },
  'exam-prep': {
    title: 'Exam Preparation Mode',
    subtitle: 'High-Yield Formula Bank • 7-Day Revision Blueprint',
  },
  'coding-lab': {
    title: 'AI Coding Lab',
    subtitle: 'Multi-Language IDE • Execution Sandbox & Complexity Analyzer',
  },
  'english-learn': {
    title: 'English Speaking & Learn Mode',
    subtitle: 'Interactive Speech Coach • Real-Time Grammar & Scenario Roleplay',
  },
  'group-discussion': {
    title: 'AI Group Discussion Arena',
    subtitle: 'Multi-Agent Roundtables • Live Debate & Evaluation Scorecard',
  },
  'project-helper': {
    title: 'Assignment & Project Helper',
    subtitle: 'Thesis Architecture • Milestone Roadmap & Academic Citations',
  },
  'career-ai': {
    title: 'Career AI Advisor',
    subtitle: 'ATS Resume Optimizer • Mock Technical & Behavioral Interviews',
  },
  'goal-mode': {
    title: 'Goal Architecture',
    subtitle: 'Strategic Milestones • SMART Execution Engine',
  },
  'image-studio': {
    title: 'Image Studio',
    subtitle: 'Neural Canvas • Multi-Model Visual Engine',
  },
  'video-lab': {
    title: 'Video Lab',
    subtitle: 'Motion Synthesizer • 1080p Temporal Studio',
  },
  'ai-council': {
    title: 'AI Council Arena',
    subtitle: 'Consensus Protocol • Multi-Agent Deliberation',
  },
};

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  userProfile,
  dailyUsage,
  dailyLimit,
  onOpenUpgrade,
  onToggleMobileMenu,
}) => {
  const current = TAB_TITLES[activeTab] || TAB_TITLES.dashboard;
  const isPro = Boolean(userProfile?.isPro);

  return (
    <header
      id="app-header"
      className="sticky top-0 z-30 w-full h-16 bg-[#050505]/85 backdrop-blur-xl border-b border-white/10 px-4 sm:px-8 flex items-center justify-between"
    >
      {/* Left: Mobile Trigger, Logo & Title */}
      <div className="flex items-center gap-3">
        <button
          id="mobile-menu-trigger"
          onClick={onToggleMobileMenu}
          className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/5 border border-white/10 md:hidden"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="md:hidden">
          <FullstopLogo size="sm" animated={true} />
        </div>

        <div>
          <h1 className="text-base sm:text-lg font-bold font-sora text-white tracking-tight flex items-center gap-2">
            <span>{current.title}</span>
            <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-[10px] font-mono bg-white/5 text-zinc-400 border border-white/10">
              v2.4
            </span>
          </h1>
          <p className="text-[11px] text-zinc-400 font-mono hidden xs:block">
            {current.subtitle}
          </p>
        </div>
      </div>

      {/* Right: Engine Status & Quota */}
      <div className="flex items-center gap-3">
        {/* Core Engine Indicator */}
        <div className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#14111d] border border-[#cfbcff]/20 text-xs text-[#cfbcff]">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-mono text-[11px]">Gemini 3.8 Flash</span>
        </div>

        {/* Pro Pill or Upgrade Button */}
        {isPro ? (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 to-[#cfbcff]/20 border border-amber-500/30 text-amber-300 text-xs font-semibold font-sora">
            <Crown className="w-3.5 h-3.5" />
            <span>PRO</span>
          </div>
        ) : (
          <button
            id="header-upgrade-btn"
            onClick={onOpenUpgrade}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#9a7dec] text-[#1c0f38] text-xs font-semibold font-sora hover:shadow-[0_0_15px_rgba(207,188,255,0.4)] transition-all glow-button"
          >
            <Crown className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Upgrade</span>
            <span className="text-[10px] opacity-80">({dailyLimit - dailyUsage} left)</span>
          </button>
        )}
      </div>
    </header>
  );
};
