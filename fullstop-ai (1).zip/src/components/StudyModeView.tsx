import React, { useState, useEffect, useRef } from 'react';
import {
  StudySessionItem,
  Flashcard,
  QuizQuestion,
  FeynmanBreakdown,
  UserProfile,
} from '../types';
import {
  GraduationCap,
  Sparkles,
  BookOpen,
  Brain,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Clock,
  Layers,
  HelpCircle,
  Check,
  ChevronLeft,
  ChevronRight,
  Lightbulb,
  AlertCircle,
  Tag,
  Zap,
} from 'lucide-react';

interface StudyModeViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const PRESET_TOPICS = [
  'Attention Mechanism & Transformer Neural Networks',
  'Distributed Consensus: Raft vs Paxos',
  'Quantum Decoherence & Superposition',
  'Behavioral Game Theory & Nash Equilibrium',
];

const STORAGE_KEY = 'fullstop_study_sessions';

const INITIAL_FEYNMAN: FeynmanBreakdown = {
  topicTitle: 'Attention Mechanism & Transformer Neural Networks',
  simpleExplanation:
    'Imagine a researcher reading an entire encyclopedia with highlighters of different colors. Instead of reading every word one-by-one, the attention mechanism dynamically weights and links words to each other across the entire sentence simultaneously.',
  realWorldAnalogy:
    'Like a cocktail party conversation: amidst a noisy room with 50 people speaking at once, your auditory cortex zooms in on the person mentioning your name or speaking about a topic you care about, while softening background chatter.',
  deepDiveBreakdown: [
    'Query, Key, and Value Projections: Inputs are transformed into three vector matrices. Queries search for relevant Keys, and their dot-product generates the dynamic attention weight distribution.',
    'Scaled Dot-Product Formula: Attention(Q, K, V) = softmax(Q·K^T / √d_k) · V. The square root of the head dimension prevents gradient vanishing when dot products grow large.',
    'Multi-Head Parallelism: By running multiple parallel attention heads, the model simultaneously attends to syntactic relationships (e.g. subject-verb) and semantic references (e.g. pronoun resolution).',
  ],
  commonMisconceptions: [
    'Misconception: Transformers have infinite memory. Reality: Standard self-attention scales quadratically O(N²) with context length unless linear attention approximations are applied.',
    'Misconception: Transformers comprehend semantic meaning like humans. Reality: They compute high-dimensional statistical representations without experiential embodiment.',
  ],
  coreTerminology: [
    { term: 'Query (Q)', definition: 'The vector representing the token currently seeking contextual information.' },
    { term: 'Key (K)', definition: 'The vector index against which the query is compared to compute relevance score.' },
    { term: 'Value (V)', definition: 'The actual semantic information aggregated into the final representation.' },
  ],
};

const INITIAL_FLASHCARDS: Flashcard[] = [
  {
    id: 'fc-1',
    question: 'Why does the Transformer scale the dot product of Query and Key by √d_k?',
    answer: 'To prevent large magnitude values from pushing the softmax function into regions with extremely small gradients (gradient vanishing).',
    hint: 'Think about high dimensional vectors causing variance expansion.',
    rating: 'unrated',
  },
  {
    id: 'fc-2',
    question: 'What is the computational complexity of standard self-attention relative to sequence length N?',
    answer: 'Quadratic complexity: O(N²) both in time and memory, because every token attends to every other token.',
    hint: 'Matrix multiplication of (N x d) by (d x N).',
    rating: 'unrated',
  },
  {
    id: 'fc-3',
    question: 'What crucial structural information is lost in pure self-attention that requires Positional Encoding?',
    answer: 'Word order and sequential position. Self-attention is permutation-equivariant without positional vectors added to token embeddings.',
    hint: 'Bag of words symmetry.',
    rating: 'unrated',
  },
  {
    id: 'fc-4',
    question: 'What is the primary operational difference between encoder and decoder attention in autoregressive models?',
    answer: 'Decoder attention utilizes causal masking (upper triangular mask) to prevent tokens from attending to future upcoming positions.',
    hint: 'Cannot look into the future during generative generation.',
    rating: 'unrated',
  },
];

const INITIAL_QUIZ: QuizQuestion[] = [
  {
    id: 'qz-1',
    question: 'In the Attention(Q, K, V) formula, what role does the Softmax operation perform?',
    options: [
      'It normalizes Query-Key dot products into a probabilistic distribution summing to 1',
      'It compresses the context vector dimension to save GPU VRAM',
      'It acts as an activation function to introduce non-linear convolutional features',
      'It encrypts token embeddings for multi-tenant privacy',
    ],
    correctIndex: 0,
    explanation:
      'Softmax converts unbounded dot-product scores into normalized attention weights between 0 and 1 that sum to 1.0, effectively determining how much each token contributes to the output representation.',
  },
  {
    id: 'qz-2',
    question: 'Why is Multi-Head Attention strictly superior to a single large attention head?',
    options: [
      'It uses fewer floating point operations than a single head',
      'It allows the model to jointly attend to information from different representation subspaces at different positions',
      'It eliminates the need for feed-forward neural layers',
      'It prevents overfitting on small datasets',
    ],
    correctIndex: 1,
    explanation:
      'Multi-head attention projects Queries, Keys, and Values into multiple lower-dimensional subspaces, enabling the model to simultaneously capture diverse relationships (e.g. grammar, tense, semantics) rather than averaging them all together.',
  },
  {
    id: 'qz-3',
    question: 'What happens if you remove Positional Encodings from a Transformer model?',
    options: [
      'The model crashes with a tensor dimension mismatch',
      'The model treats sentences as an unordered "bag of tokens", unable to distinguish "cat ate mouse" from "mouse ate cat"',
      'Attention scores become negative numbers',
      'Inference speed slows down by 50%',
    ],
    correctIndex: 1,
    explanation:
      'Pure self-attention has no inherent concept of order or sequential position. Positional encodings (sinusoidal or learned) inject position vectors so the network knows the relative ordering of tokens.',
  },
];

export const StudyModeView: React.FC<StudyModeViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt = '',
}) => {
  const [topicInput, setTopicInput] = useState(initialPrompt);
  const [studyType, setStudyType] = useState<'feynman' | 'flashcards' | 'quiz'>('feynman');
  const [depth, setDepth] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [customNotes, setCustomNotes] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active study materials
  const [feynmanData, setFeynmanData] = useState<FeynmanBreakdown>(INITIAL_FEYNMAN);
  const [flashcards, setFlashcards] = useState<Flashcard[]>(INITIAL_FLASHCARDS);
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>(INITIAL_QUIZ);

  // Flashcard Navigation & State
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);

  // Quiz State
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);

  // Focus Flow Timer (Pomodoro: 25m / 5m)
  const [timerMode, setTimerMode] = useState<'work' | 'break'>('work');
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Ambient Focus Noise Generator (Web Audio API)
  const [isSoundPlaying, setIsSoundPlaying] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const noiseNodeRef = useRef<AudioNode | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);

  // Timer Tick
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      // Toggle session
      if (timerMode === 'work') {
        setTimerMode('break');
        setTimeLeft(5 * 60);
      } else {
        setTimerMode('work');
        setTimeLeft(25 * 60);
      }
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timeLeft, timerMode]);

  // Audio Synth Cleanup
  useEffect(() => {
    return () => {
      if (audioCtxRef.current) {
        audioCtxRef.current.close().catch(() => {});
      }
    };
  }, []);

  const toggleSound = () => {
    if (isSoundPlaying) {
      if (gainNodeRef.current && audioCtxRef.current) {
        gainNodeRef.current.gain.linearRampToValueAtTime(0, audioCtxRef.current.currentTime + 0.5);
        setTimeout(() => {
          setIsSoundPlaying(false);
        }, 500);
      }
    } else {
      try {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContextClass) return;

        const ctx = audioCtxRef.current || new AudioContextClass();
        audioCtxRef.current = ctx;

        if (ctx.state === 'suspended') {
          ctx.resume();
        }

        // Generate Brown Noise Buffer for deep focus
        const bufferSize = ctx.sampleRate * 2;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        let lastOut = 0.0;
        for (let i = 0; i < bufferSize; i++) {
          const white = Math.random() * 2 - 1;
          output[i] = (lastOut + 0.02 * white) / 1.02;
          lastOut = output[i];
          output[i] *= 3.5; // boost gain
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        // Lowpass filter for smooth deep rumble
        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(320, ctx.currentTime);

        const gainNode = ctx.createGain();
        gainNode.gain.setValueAtTime(0.01, ctx.currentTime);
        gainNode.gain.linearRampToValueAtTime(0.12, ctx.currentTime + 1.0);

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);

        whiteNoise.start(0);

        noiseNodeRef.current = whiteNoise;
        gainNodeRef.current = gainNode;
        setIsSoundPlaying(true);
      } catch (e) {
        console.warn('Audio API unavailable:', e);
      }
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSynthesize = async () => {
    if (!topicInput.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/study/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topicInput.trim(),
          studyType,
          depth,
          customNotes: customNotes.trim(),
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Failed to synthesize study session.');
      }

      const data = json.data;
      if (studyType === 'feynman') {
        setFeynmanData(data);
      } else if (studyType === 'flashcards') {
        setFlashcards(data.flashcards || []);
        setActiveCardIndex(0);
        setIsFlipped(false);
      } else if (studyType === 'quiz') {
        setQuizQuestions(data.quiz || []);
        setQuizAnswers({});
        setQuizSubmitted(false);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Error generating study materials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCardRating = (rating: 'hard' | 'medium' | 'easy') => {
    setFlashcards((prev) =>
      prev.map((c, idx) => (idx === activeCardIndex ? { ...c, rating } : c))
    );
    if (activeCardIndex < flashcards.length - 1) {
      setActiveCardIndex((prev) => prev + 1);
      setIsFlipped(false);
      setShowHint(false);
    }
  };

  const handleSelectQuizOption = (qId: string, optIdx: number) => {
    if (quizSubmitted) return;
    setQuizAnswers((prev) => ({ ...prev, [qId]: optIdx }));
  };

  const calculateQuizScore = () => {
    let score = 0;
    quizQuestions.forEach((q) => {
      if (quizAnswers[q.id] === q.correctIndex) score++;
    });
    return score;
  };

  return (
    <div id="study-mode-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Top Header Card */}
      <div className="relative rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 sm:p-8 border border-white/10 overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#8257e5]/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#8257e5] to-[#cfbcff] flex items-center justify-center text-[#1c0f38] shadow-[0_0_15px_rgba(207,188,255,0.4)]">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono uppercase bg-[#cfbcff]/10 text-[#cfbcff] border border-[#cfbcff]/30 font-semibold">
                  STUDY MODE • NEURAL ACCELERATOR
                </span>
                <h1 className="text-xl sm:text-2xl font-bold font-sora text-white">
                  Active Recall & Feynman Cognitive Synthesizer
                </h1>
              </div>
            </div>

            {/* Focus Timer & Ambient Audio Controls */}
            <div className="flex items-center gap-2 font-mono text-xs">
              {/* Pomodoro Timer */}
              <div className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 flex items-center gap-2">
                <Clock className="w-3.5 h-3.5 text-[#cfbcff]" />
                <span className="font-bold text-white tracking-wider">{formatTimer(timeLeft)}</span>
                <span className="text-[10px] text-zinc-500 uppercase">({timerMode})</span>
                <button
                  type="button"
                  onClick={() => setIsTimerRunning((prev) => !prev)}
                  className="p-1 rounded hover:bg-white/10 text-zinc-300 hover:text-white"
                  title={isTimerRunning ? 'Pause timer' : 'Start focus timer'}
                >
                  {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setIsTimerRunning(false);
                    setTimeLeft(timerMode === 'work' ? 25 * 60 : 5 * 60);
                  }}
                  className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white"
                  title="Reset timer"
                >
                  <RotateCcw className="w-3 h-3" />
                </button>
              </div>

              {/* Ambient Brown Noise Sound Synth */}
              <button
                type="button"
                onClick={toggleSound}
                className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer ${
                  isSoundPlaying
                    ? 'bg-[#cfbcff]/20 border-[#cfbcff]/40 text-[#cfbcff]'
                    : 'bg-white/5 border-white/10 text-zinc-400 hover:text-zinc-200'
                }`}
                title="Toggle ambient neural focus audio (Brown noise)"
              >
                {isSoundPlaying ? <Volume2 className="w-3.5 h-3.5 animate-pulse" /> : <VolumeX className="w-3.5 h-3.5" />}
                <span>{isSoundPlaying ? 'Focus Noise ON' : 'Ambient Focus'}</span>
              </button>
            </div>
          </div>

          <p className="text-sm text-zinc-400 max-w-2xl">
            Transform complex academic papers, coding architectures, or conceptual theories into clear
            Feynman mental models, active recall flashcard decks, or diagnostic quizzes.
          </p>

          {/* AI Study Input Panel */}
          <div className="mt-6 p-4 rounded-2xl bg-[#14111d]/90 border border-white/15 focus-within:border-[#cfbcff]/60 transition-all space-y-3">
            <div className="flex items-center gap-3 px-2">
              <Brain className="w-5 h-5 text-[#cfbcff] flex-shrink-0" />
              <input
                id="study-topic-input"
                type="text"
                value={topicInput}
                onChange={(e) => setTopicInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSynthesize();
                }}
                placeholder="Enter subject or theory (e.g. 'CAP Theorem & Distributed Databases', 'Quantum Entanglement')..."
                className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none font-sans"
              />
            </div>

            {/* Method Pills & Depth Selector */}
            <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-mono text-zinc-500 uppercase mr-1">Study Method:</span>
                <button
                  type="button"
                  onClick={() => setStudyType('feynman')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                    studyType === 'feynman'
                      ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40 shadow-sm'
                      : 'bg-white/5 text-zinc-400 border border-white/5 hover:text-white'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Feynman Technique</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStudyType('flashcards')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                    studyType === 'flashcards'
                      ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40 shadow-sm'
                      : 'bg-white/5 text-zinc-400 border border-white/5 hover:text-white'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  <span>Active Recall Cards</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStudyType('quiz')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                    studyType === 'quiz'
                      ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40 shadow-sm'
                      : 'bg-white/5 text-zinc-400 border border-white/5 hover:text-white'
                  }`}
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Diagnostic Quiz</span>
                </button>

                <select
                  value={depth}
                  onChange={(e: any) => setDepth(e.target.value)}
                  className="bg-[#09080e] text-xs font-mono text-zinc-300 px-2.5 py-1.5 rounded-lg border border-white/10 outline-none hover:border-[#cfbcff]/40 transition-colors ml-2"
                >
                  <option value="beginner">Beginner (Foundational)</option>
                  <option value="intermediate">Intermediate (Rigorous)</option>
                  <option value="advanced">Advanced (Deep Technical)</option>
                </select>
              </div>

              <button
                id="btn-synthesize-study"
                onClick={handleSynthesize}
                disabled={isLoading || !topicInput.trim()}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold font-sora text-[#1c0f38] bg-gradient-to-r from-[#cfbcff] to-[#e8def8] hover:opacity-95 disabled:opacity-50 transition-all cursor-pointer shadow-lg shadow-[#cfbcff]/20"
              >
                {isLoading ? (
                  <>
                    <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                    <span>Synthesizing Concept...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Synthesize With AI</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick Inspiration Pills */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] font-mono text-zinc-500 uppercase mr-1">Presets:</span>
              {PRESET_TOPICS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setTopicInput(preset)}
                  className="text-[11px] px-2.5 py-1 rounded-md bg-white/[0.03] hover:bg-white/[0.08] text-zinc-400 hover:text-white border border-white/5 transition-colors"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300 flex items-center justify-between">
              <span>{errorMessage}</span>
              <button
                onClick={handleSynthesize}
                className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-white font-mono"
              >
                Retry
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Study Deck Area */}
      <div>
        {/* Method 1: FEYNMAN TECHNIQUE VIEW */}
        {studyType === 'feynman' && feynmanData && (
          <div className="space-y-6">
            {/* Simple Intuitive Explanation Card */}
            <div className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 sm:p-8 border border-white/10 space-y-4">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 font-semibold">
                  FEYNMAN INTUITION
                </span>
                <span className="text-xs font-mono text-zinc-400">{depth} Level</span>
              </div>

              <h2 className="text-xl sm:text-2xl font-bold font-sora text-white">
                {feynmanData.topicTitle}
              </h2>

              <p className="text-sm sm:text-base text-zinc-200 leading-relaxed font-sans bg-[#14111d] p-5 rounded-2xl border border-white/10">
                {feynmanData.simpleExplanation}
              </p>

              {/* Real World Analogy Box */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#6750a4]/20 to-[#cfbcff]/10 border border-[#cfbcff]/30 space-y-2">
                <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#cfbcff] font-bold">
                  <Lightbulb className="w-4 h-4" />
                  <span>Real-World Physical Analogy</span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-100 leading-relaxed italic">
                  "{feynmanData.realWorldAnalogy}"
                </p>
              </div>
            </div>

            {/* Deep Dive Breakdown & Misconceptions Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Deep Dive Systematic Pillars */}
              <div className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 border border-white/10 space-y-4">
                <h3 className="text-base font-bold font-sora text-white flex items-center gap-2">
                  <Brain className="w-4 h-4 text-[#cfbcff]" />
                  <span>Core Mechanistic Principles</span>
                </h3>

                <div className="space-y-3">
                  {feynmanData.deepDiveBreakdown.map((item, idx) => (
                    <div key={idx} className="p-3.5 rounded-2xl bg-[#14111d] border border-white/10 flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-[#cfbcff] flex items-center justify-center flex-shrink-0 mt-0.5">
                        {idx + 1}
                      </span>
                      <p className="text-xs text-zinc-300 leading-relaxed">{item}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pitfalls & Misconceptions */}
              <div className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 border border-white/10 space-y-4">
                <h3 className="text-base font-bold font-sora text-white flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400" />
                  <span>Common Misconceptions & Traps</span>
                </h3>

                <div className="space-y-3">
                  {feynmanData.commonMisconceptions.map((item, idx) => (
                    <div key={idx} className="p-3.5 rounded-2xl bg-[#14111d] border border-rose-500/20 space-y-1">
                      <p className="text-xs text-zinc-300 leading-relaxed">{item}</p>
                    </div>
                  ))}

                  {/* Core Terminology Index */}
                  <div className="pt-2 border-t border-white/5 space-y-2">
                    <span className="text-[10px] font-mono uppercase text-zinc-500 tracking-wider block">
                      Core Technical Terminology:
                    </span>
                    <div className="space-y-2">
                      {feynmanData.coreTerminology.map((termItem, tIdx) => (
                        <div key={tIdx} className="text-xs text-zinc-300">
                          <span className="font-semibold text-white font-mono">{termItem.term}: </span>
                          <span className="text-zinc-400">{termItem.definition}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Method 2: ACTIVE RECALL FLASHCARDS */}
        {studyType === 'flashcards' && flashcards.length > 0 && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="flex items-center justify-between text-xs font-mono text-zinc-400">
              <span>Card {activeCardIndex + 1} of {flashcards.length}</span>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400">
                  {flashcards.filter((c) => c.rating === 'easy').length} Mastered
                </span>
                <span>•</span>
                <span className="text-amber-400">
                  {flashcards.filter((c) => c.rating === 'medium').length} Review
                </span>
                <span>•</span>
                <span className="text-rose-400">
                  {flashcards.filter((c) => c.rating === 'hard').length} Hard
                </span>
              </div>
            </div>

            {/* Interactive 3D Flashcard */}
            <div
              onClick={() => setIsFlipped((prev) => !prev)}
              className="relative min-h-[280px] sm:min-h-[320px] rounded-3xl glass-panel bg-[#14111d] border border-white/15 p-8 flex flex-col justify-between cursor-pointer hover:border-[#cfbcff]/50 transition-all shadow-2xl group select-none"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase bg-white/5 text-zinc-400 border border-white/10">
                    {isFlipped ? 'ANSWER (BACK)' : 'PROMPT (FRONT)'}
                  </span>
                  <span className="text-[11px] font-mono text-zinc-500 group-hover:text-zinc-300 transition-colors">
                    Click card to flip ↺
                  </span>
                </div>

                {!isFlipped ? (
                  <div className="space-y-4">
                    <h3 className="text-lg sm:text-xl font-bold font-sora text-white leading-relaxed">
                      {flashcards[activeCardIndex].question}
                    </h3>

                    {flashcards[activeCardIndex].hint && (
                      <div className="pt-2">
                        {showHint ? (
                          <div className="p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-zinc-300 italic">
                            💡 Hint: {flashcards[activeCardIndex].hint}
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setShowHint(true);
                            }}
                            className="text-xs font-mono text-[#cfbcff] hover:underline"
                          >
                            Need a hint?
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="text-xs font-mono text-[#cfbcff] uppercase">Authoritative Key Takeaway:</div>
                    <p className="text-sm sm:text-base text-zinc-100 leading-relaxed font-sans">
                      {flashcards[activeCardIndex].answer}
                    </p>
                  </div>
                )}
              </div>

              {/* Bottom Rating Bar (Visible when flipped) */}
              {isFlipped && (
                <div
                  onClick={(e) => e.stopPropagation()}
                  className="pt-6 border-t border-white/10 flex items-center justify-center gap-3"
                >
                  <button
                    type="button"
                    onClick={() => handleCardRating('hard')}
                    className="px-4 py-2 rounded-xl text-xs font-mono font-medium bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/30 transition-colors"
                  >
                    Hard (Review Soon)
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCardRating('medium')}
                    className="px-4 py-2 rounded-xl text-xs font-mono font-medium bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 transition-colors"
                  >
                    Medium
                  </button>
                  <button
                    type="button"
                    onClick={() => handleCardRating('easy')}
                    className="px-4 py-2 rounded-xl text-xs font-mono font-medium bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 transition-colors"
                  >
                    Easy (Mastered)
                  </button>
                </div>
              )}
            </div>

            {/* Card Switcher Controls */}
            <div className="flex items-center justify-between">
              <button
                type="button"
                disabled={activeCardIndex === 0}
                onClick={() => {
                  setActiveCardIndex((prev) => Math.max(0, prev - 1));
                  setIsFlipped(false);
                  setShowHint(false);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-zinc-300 disabled:opacity-30 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Previous Card</span>
              </button>

              <button
                type="button"
                disabled={activeCardIndex === flashcards.length - 1}
                onClick={() => {
                  setActiveCardIndex((prev) => Math.min(flashcards.length - 1, prev + 1));
                  setIsFlipped(false);
                  setShowHint(false);
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-mono text-zinc-300 disabled:opacity-30 transition-colors cursor-pointer"
              >
                <span>Next Card</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Method 3: DIAGNOSTIC QUIZ VIEW */}
        {studyType === 'quiz' && quizQuestions.length > 0 && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold font-sora text-white flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-[#cfbcff]" />
                <span>Adaptive Diagnostic Quiz</span>
              </h2>

              {quizSubmitted && (
                <div className="px-4 py-1.5 rounded-xl bg-[#cfbcff]/20 border border-[#cfbcff]/40 font-mono text-xs text-[#cfbcff] font-bold">
                  Score: {calculateQuizScore()} / {quizQuestions.length} (
                  {Math.round((calculateQuizScore() / quizQuestions.length) * 100)}%)
                </div>
              )}
            </div>

            <div className="space-y-6">
              {quizQuestions.map((q, qIndex) => {
                const selectedOpt = quizAnswers[q.id];
                const isAnswered = selectedOpt !== undefined;

                return (
                  <div
                    key={q.id}
                    className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 border border-white/10 space-y-4"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-[#cfbcff] flex items-center justify-center font-bold">
                        {qIndex + 1}
                      </span>
                      <h3 className="text-sm sm:text-base font-semibold font-sora text-white">
                        {q.question}
                      </h3>
                    </div>

                    {/* Options List */}
                    <div className="space-y-2 pl-8">
                      {q.options.map((optionText, optIdx) => {
                        const isSelected = selectedOpt === optIdx;
                        const isCorrect = q.correctIndex === optIdx;

                        let optStyles =
                          'bg-[#14111d] border-white/10 text-zinc-300 hover:border-white/20';

                        if (quizSubmitted) {
                          if (isCorrect) {
                            optStyles = 'bg-emerald-500/20 border-emerald-500 text-emerald-300';
                          } else if (isSelected && !isCorrect) {
                            optStyles = 'bg-rose-500/20 border-rose-500 text-rose-300';
                          } else {
                            optStyles = 'bg-[#14111d]/50 border-white/5 text-zinc-500';
                          }
                        } else if (isSelected) {
                          optStyles = 'bg-[#cfbcff]/20 border-[#cfbcff] text-white';
                        }

                        return (
                          <div
                            key={optIdx}
                            onClick={() => handleSelectQuizOption(q.id, optIdx)}
                            className={`p-3 rounded-2xl border text-xs sm:text-sm cursor-pointer transition-all flex items-center justify-between ${optStyles}`}
                          >
                            <span>{optionText}</span>
                            {quizSubmitted && isCorrect && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                            )}
                            {quizSubmitted && isSelected && !isCorrect && (
                              <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Explanation Reveal */}
                    {quizSubmitted && (
                      <div className="pl-8 pt-3 border-t border-white/5">
                        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-zinc-300 space-y-1">
                          <span className="font-mono text-[10px] text-[#cfbcff] uppercase font-bold block">
                            Rationale:
                          </span>
                          <p className="leading-relaxed">{q.explanation}</p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Quiz Submit & Reset Controls */}
            <div className="flex items-center justify-center gap-3 pt-4">
              {!quizSubmitted ? (
                <button
                  type="button"
                  onClick={() => setQuizSubmitted(true)}
                  disabled={Object.keys(quizAnswers).length === 0}
                  className="px-6 py-2.5 rounded-xl text-xs font-semibold font-sora text-[#1c0f38] bg-gradient-to-r from-[#cfbcff] to-[#e8def8] hover:opacity-95 disabled:opacity-40 transition-all cursor-pointer shadow-lg shadow-[#cfbcff]/20"
                >
                  Submit Answers & Grade Test
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setQuizAnswers({});
                    setQuizSubmitted(false);
                  }}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-semibold font-sora text-white bg-white/10 hover:bg-white/20 transition-all cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Retake Diagnostic Quiz</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
