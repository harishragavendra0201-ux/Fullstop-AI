import React, { useState, useEffect, useRef } from 'react';
import { GeneratedVideoItem, UserProfile } from '../types';
import {
  Video,
  Play,
  Pause,
  RotateCcw,
  Download,
  Film,
  Compass,
  Sliders,
  Sparkles,
  Zap,
  Clock,
  Tv,
  AlertTriangle,
  Lightbulb,
  Maximize2,
  Activity,
  Layers,
} from 'lucide-react';

interface VideoLabViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const MOTION_PRESETS = [
  'Orbit 360°',
  'Pan Left to Right',
  'Forward Zoom In',
  'FPV High-Speed Drone',
  'Subtle Ambient Float',
  'Dynamic Crane Descent',
];

const PROMPT_PRESETS = [
  'Deep ocean bioluminescent sea turtle gliding through purple coral reefs, 60fps',
  'Hyper-speed FPV drone dive through neon cybernetic skyscraper corridors',
  'Macro time-lapse of crystalline lotus bloom emanating electric violet light',
  'Hyperspace jump through obsidian asteroid ring with volumetric starlight',
];

const SAMPLE_VIDEOS: GeneratedVideoItem[] = [
  {
    id: 'vid-sample-1',
    prompt: 'Deep ocean bioluminescent sea turtle gliding through neon purple coral reefs with cinematic fluid camera motion',
    resolution: '1080p',
    duration: '5s',
    motion: 'Orbit 360°',
    videoUrl: 'https://res.cloudinary.com/demo/video/upload/samples/sea-turtle.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?q=80&w=800&auto=format&fit=crop',
    timestamp: 'Today',
  },
  {
    id: 'vid-sample-2',
    prompt: 'Macro time-lapse of blooming cybernetic flora with radiant particle illumination and optical flow',
    resolution: '1080p',
    duration: '3s',
    motion: 'Forward Zoom In',
    videoUrl: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1490750967868-88aa4486c946?q=80&w=800&auto=format&fit=crop',
    timestamp: 'Yesterday',
  },
  {
    id: 'vid-sample-3',
    prompt: 'High-speed dynamic tracking shot across scenic landscape with atmospheric volumetric lighting',
    resolution: '1080p',
    duration: '5s',
    motion: 'FPV High-Speed Drone',
    videoUrl: 'https://res.cloudinary.com/demo/video/upload/dog.mp4',
    thumbnail: 'https://images.unsplash.com/photo-1543466835-00a7907e9de1?q=80&w=800&auto=format&fit=crop',
    timestamp: '2 days ago',
  },
];

export const VideoLabView: React.FC<VideoLabViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt = '',
}) => {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [resolution, setResolution] = useState('1080p');
  const [duration, setDuration] = useState('5s');
  const [motion, setMotion] = useState('Orbit 360°');
  const [motionStrength, setMotionStrength] = useState(75);
  const [isRendering, setIsRendering] = useState(false);
  const [renderStage, setRenderStage] = useState('');
  const [videos, setVideos] = useState<GeneratedVideoItem[]>(SAMPLE_VIDEOS);
  const [activeVideo, setActiveVideo] = useState<GeneratedVideoItem | null>(SAMPLE_VIDEOS[0]);
  const [isPlaying, setIsPlaying] = useState(true);
  const [playerMode, setPlayerMode] = useState<'stream' | 'kinetic-canvas'>('stream');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [videoError, setVideoError] = useState(false);

  // Canvas Simulation Engine Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Procedural Kinetic Neural Canvas Engine
  useEffect(() => {
    if (playerMode !== 'kinetic-canvas' && !videoError) {
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = (canvas.width = canvas.parentElement?.clientWidth || 800);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 450);

    const handleResize = () => {
      if (!canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener('resize', handleResize);

    // Particle field initialization
    const particleCount = 120;
    const particles = Array.from({ length: particleCount }, () => ({
      x: (Math.random() - 0.5) * width * 1.5,
      y: (Math.random() - 0.5) * height * 1.5,
      z: Math.random() * 1000 + 10,
      size: Math.random() * 2.5 + 1,
      color: Math.random() > 0.3 ? '#cfbcff' : '#9a7dec',
      speed: Math.random() * 2 + 1,
      angle: Math.random() * Math.PI * 2,
    }));

    let tick = 0;

    const renderFrame = () => {
      if (!isPlaying) {
        animationFrameRef.current = requestAnimationFrame(renderFrame);
        return;
      }

      tick += (motionStrength / 50) * 0.03;
      ctx.fillStyle = '#06050a';
      ctx.fillRect(0, 0, width, height);

      const cx = width / 2;
      const cy = height / 2;

      // Draw Atmospheric Vignette & Grid Lines
      const gradient = ctx.createRadialGradient(cx, cy, 50, cx, cy, width * 0.7);
      gradient.addColorStop(0, 'rgba(154, 125, 236, 0.12)');
      gradient.addColorStop(0.5, 'rgba(28, 15, 56, 0.4)');
      gradient.addColorStop(1, '#06050a');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Render based on selected camera motion preset
      const curMotion = activeVideo?.motion || motion;

      if (curMotion === 'Orbit 360°') {
        // Orbit 3D Core with Ring Filaments
        ctx.save();
        ctx.translate(cx, cy);

        // Rotating Rings
        for (let r = 0; r < 3; r++) {
          ctx.beginPath();
          ctx.ellipse(
            0,
            0,
            140 + r * 30,
            50 + r * 15,
            tick + (r * Math.PI) / 3,
            0,
            Math.PI * 2
          );
          ctx.strokeStyle = r === 0 ? 'rgba(207, 188, 255, 0.7)' : 'rgba(154, 125, 236, 0.3)';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Orbiting Satellites
        particles.slice(0, 60).forEach((p, i) => {
          const orbitAngle = tick * p.speed + (i * Math.PI * 2) / 60;
          const radiusX = 160 + (i % 3) * 35;
          const radiusY = 70 + (i % 3) * 20;
          const px = Math.cos(orbitAngle) * radiusX;
          const py = Math.sin(orbitAngle) * radiusY;

          ctx.beginPath();
          ctx.arc(px, py, p.size * 1.2, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 10;
          ctx.shadowColor = '#cfbcff';
          ctx.fill();
        });

        // Glowing Quantum Core
        const corePulse = Math.sin(tick * 3) * 6;
        ctx.beginPath();
        ctx.arc(0, 0, 24 + corePulse, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(207, 188, 255, 0.9)';
        ctx.shadowBlur = 25;
        ctx.shadowColor = '#cfbcff';
        ctx.fill();

        ctx.restore();
      } else if (curMotion === 'FPV High-Speed Drone' || curMotion === 'Forward Zoom In') {
        // Warp Tunnel / Hyperspace Flight
        particles.forEach((p) => {
          p.z -= (motionStrength / 30) * 12;
          if (p.z <= 0) {
            p.z = 1000;
            p.x = (Math.random() - 0.5) * width * 1.5;
            p.y = (Math.random() - 0.5) * height * 1.5;
          }

          const k = 350 / p.z;
          const px = p.x * k + cx;
          const py = p.y * k + cy;

          if (px >= 0 && px <= width && py >= 0 && py <= height) {
            const pSize = Math.max(1, (1 - p.z / 1000) * 4);
            ctx.beginPath();
            ctx.arc(px, py, pSize, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.shadowBlur = 8;
            ctx.shadowColor = '#cfbcff';
            ctx.fill();

            // Trail streak
            ctx.beginPath();
            ctx.moveTo(px, py);
            ctx.lineTo(p.x * (350 / (p.z + 40)) + cx, p.y * (350 / (p.z + 40)) + cy);
            ctx.strokeStyle = 'rgba(207, 188, 255, 0.4)';
            ctx.lineWidth = pSize * 0.8;
            ctx.stroke();
          }
        });
      } else {
        // Pan Left to Right & Ambient Floating Fluid
        const waveShift = Math.sin(tick) * 60;
        particles.forEach((p, idx) => {
          p.x += Math.cos(tick + idx) * 1.5 + (curMotion === 'Pan Left to Right' ? 2.5 : 0.5);
          p.y += Math.sin(tick * 0.5 + idx) * 1.2;

          if (p.x > width / 2 + 100) p.x = -width / 2 - 100;
          if (p.y > height / 2 + 100) p.y = -height / 2 - 100;

          const px = cx + p.x + waveShift;
          const py = cy + p.y;

          ctx.beginPath();
          ctx.arc(px, py, p.size * 1.5, 0, Math.PI * 2);
          ctx.fillStyle = p.color;
          ctx.shadowBlur = 12;
          ctx.shadowColor = '#9a7dec';
          ctx.fill();
        });
      }

      // HUD Overlay Graphics
      ctx.shadowBlur = 0;
      ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
      ctx.font = '10px monospace';
      ctx.fillText(
        `FULLSTOP // NEURAL KINETIC SIMULATOR [60 FPS] • ${curMotion.toUpperCase()} • STRENGTH: ${motionStrength}%`,
        20,
        25
      );

      ctx.strokeStyle = 'rgba(207, 188, 255, 0.2)';
      ctx.strokeRect(15, 12, width - 30, height - 24);

      animationFrameRef.current = requestAnimationFrame(renderFrame);
    };

    animationFrameRef.current = requestAnimationFrame(renderFrame);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [playerMode, videoError, isPlaying, motion, motionStrength, activeVideo]);

  const handleGenerateVideo = async () => {
    if (!prompt.trim() || isRendering) return;
    setErrorMessage(null);

    const allowed = onIncrementUsage();
    if (!allowed) {
      onOpenUpgrade();
      return;
    }

    setIsRendering(true);
    setRenderStage('Analyzing temporal latent vectors...');

    try {
      setTimeout(() => setRenderStage('Synthesizing 60fps frame interpolations...'), 900);
      setTimeout(() => setRenderStage('Post-processing optical flow and color grade...'), 1800);

      const res = await fetch('/api/video-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          resolution,
          duration,
          motion,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to render video');

      const newVideo: GeneratedVideoItem = {
        id: data.id || 'vid-' + Date.now(),
        prompt: prompt.trim(),
        resolution,
        duration,
        motion,
        videoUrl: data.videoUrl,
        thumbnail: data.thumbnail,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setVideos((prev) => [newVideo, ...prev]);
      setActiveVideo(newVideo);
      setVideoError(false);
      setIsPlaying(true);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || 'Video synthesis error. Please try again.');
    } finally {
      setIsRendering(false);
      setRenderStage('');
    }
  };

  const handleTogglePlay = () => {
    if (playerMode === 'stream' && videoRef.current && !videoError) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div id="video-lab-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Studio Header & Prompt Input */}
      <div className="rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/85 p-6 sm:p-8 border border-white/10 relative overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff]">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-mono font-semibold tracking-wider text-[#cfbcff] uppercase">
                TEMPORAL SYNTHESIS // VEO-3
              </span>
              <h2 className="text-xl font-bold font-sora text-white">Motion Video Laboratory</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-zinc-400 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10">
              Model: Fullstop Temporal XL
            </span>
          </div>
        </div>

        {/* Prompt Input Area */}
        <div className="space-y-4">
          <div className="relative rounded-2xl bg-[#14111d] p-3 border border-white/15 focus-within:border-[#cfbcff]/60 transition-colors">
            <textarea
              id="video-prompt-input"
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your motion sequence in cinematic detail... (e.g. FPV drone flight diving through a rain-drenched cyberpunk metropolis with neon reflections, 60fps)"
              className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none resize-none font-sans"
            />

            <div className="flex items-center justify-between pt-2 border-t border-white/5">
              <button
                type="button"
                onClick={() =>
                  setPrompt(
                    'Hyper-speed FPV drone dive through neon cybernetic skyscraper corridors with volumetric purple particle dust'
                  )
                }
                className="text-[11px] font-mono text-zinc-400 hover:text-[#cfbcff] flex items-center gap-1 transition-colors"
              >
                <Sparkles className="w-3 h-3" />
                <span>Preset Prompt</span>
              </button>

              <span className="text-[11px] font-mono text-zinc-400">
                {prompt.length}/500 chars
              </span>
            </div>
          </div>

          {/* Quick Inspiration Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-[10px] font-mono text-zinc-500 uppercase flex items-center gap-1 flex-shrink-0">
              <Lightbulb className="w-3 h-3 text-amber-400" />
              Presets:
            </span>
            {PROMPT_PRESETS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPrompt(p)}
                className="text-[11px] font-sans px-2.5 py-1 rounded-lg bg-white/[0.03] hover:bg-[#cfbcff]/15 text-zinc-400 hover:text-[#cfbcff] border border-white/5 hover:border-[#cfbcff]/30 transition-all whitespace-nowrap flex-shrink-0"
              >
                {p.split(' ').slice(0, 4).join(' ')}...
              </button>
            ))}
          </div>

          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
              <button
                onClick={handleGenerateVideo}
                className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-medium border border-rose-500/40 transition-colors"
              >
                Retry
              </button>
            </div>
          )}

          {/* Controls: Resolution, Duration, Motion */}
          <div className="grid sm:grid-cols-3 gap-4 pt-1">
            {/* Resolution */}
            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-2 flex items-center gap-1.5">
                <Tv className="w-3.5 h-3.5 text-[#cfbcff]" />
                <span>Resolution</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['1080p', '4K Ultra'].map((res) => (
                  <button
                    key={res}
                    type="button"
                    onClick={() => setResolution(res)}
                    className={`py-2 px-3 rounded-xl text-xs font-mono transition-all ${
                      resolution === res
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/50'
                        : 'bg-white/[0.03] text-zinc-400 border border-white/10'
                    }`}
                  >
                    {res}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-2 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#cfbcff]" />
                <span>Duration</span>
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['3s', '5s', '10s'].map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDuration(d)}
                    className={`py-2 px-3 rounded-xl text-xs font-mono transition-all ${
                      duration === d
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/50'
                        : 'bg-white/[0.03] text-zinc-400 border border-white/10'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Camera Motion */}
            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-2 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-[#cfbcff]" />
                <span>Camera Motion</span>
              </label>
              <select
                value={motion}
                onChange={(e) => setMotion(e.target.value)}
                className="w-full bg-[#14111d] text-xs font-mono text-zinc-200 border border-white/10 rounded-xl px-3 py-2.5 outline-none"
              >
                {MOTION_PRESETS.map((m) => (
                  <option key={m} value={m} className="bg-[#14111d] text-white">
                    {m}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Render CTA */}
          <div className="pt-2 flex items-center justify-between gap-4">
            <div className="text-xs font-mono text-zinc-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Credit Cost: 2 Neural Credits</span>
            </div>

            <button
              id="video-generate-btn"
              onClick={handleGenerateVideo}
              disabled={!prompt.trim() || isRendering}
              className={`py-3 px-8 rounded-xl font-sora font-semibold text-sm flex items-center gap-2 transition-all ${
                !prompt.trim() || isRendering
                  ? 'bg-white/5 text-zinc-500 cursor-not-allowed border border-white/5'
                  : 'bg-gradient-to-r from-[#cfbcff] via-[#b69df8] to-[#9a7dec] text-[#1c0f38] hover:shadow-[0_0_25px_rgba(207,188,255,0.45)] glow-button cursor-pointer'
              }`}
            >
              {isRendering ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin" />
                  <span>Rendering Motion Latents...</span>
                </>
              ) : (
                <>
                  <Video className="w-4 h-4" />
                  <span>Render Video Clip</span>
                </>
              )}
            </button>
          </div>

          {/* Active Render Progress */}
          {isRendering && (
            <div className="p-4 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 text-xs text-[#cfbcff] flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-[#cfbcff] animate-ping" />
              <span className="font-mono">{renderStage}</span>
            </div>
          )}
        </div>
      </div>

      {/* Main Video Player & Recent Clips */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Active Player */}
        <div className="lg:col-span-2 rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 p-5 flex flex-col justify-between">
          <div>
            {/* Top Toolbar */}
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                <span className="text-xs font-mono text-zinc-300">
                  {activeVideo ? `${activeVideo.resolution} • ${activeVideo.duration} • ${activeVideo.motion}` : 'No Video'}
                </span>
                {videoError && (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Kinetic Fallback Active
                  </span>
                )}
              </div>

              {/* Engine Mode Toggle */}
              <div className="flex items-center gap-2">
                <div className="flex items-center rounded-xl bg-white/5 p-0.5 border border-white/10 text-[11px] font-mono">
                  <button
                    onClick={() => {
                      setPlayerMode('stream');
                      setVideoError(false);
                    }}
                    className={`px-2.5 py-1 rounded-lg transition-all ${
                      playerMode === 'stream' && !videoError
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] font-semibold'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    HD Stream
                  </button>
                  <button
                    onClick={() => setPlayerMode('kinetic-canvas')}
                    className={`px-2.5 py-1 rounded-lg transition-all ${
                      playerMode === 'kinetic-canvas' || videoError
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] font-semibold'
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    Kinetic 60FPS
                  </button>
                </div>

                {activeVideo && (
                  <a
                    href={activeVideo.videoUrl}
                    target="_blank"
                    rel="noreferrer"
                    download
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
                    title="Download Clip"
                  >
                    <Download className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>

            {/* Video / Canvas container */}
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-video flex items-center justify-center border border-white/10 shadow-inner group">
              {activeVideo ? (
                playerMode === 'stream' && !videoError ? (
                  <video
                    ref={videoRef}
                    key={activeVideo.id}
                    src={activeVideo.videoUrl}
                    poster={activeVideo.thumbnail}
                    controls
                    autoPlay
                    loop
                    playsInline
                    onError={() => {
                      console.warn('Streaming video error; activating Kinetic Neural Canvas fallback.');
                      setVideoError(true);
                      setPlayerMode('kinetic-canvas');
                    }}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <canvas
                    ref={canvasRef}
                    className="w-full h-full object-cover block"
                  />
                )
              ) : (
                <p className="text-xs text-zinc-500 font-mono">No video selected</p>
              )}

              {/* Kinetic Simulation Controls Overlay */}
              {(playerMode === 'kinetic-canvas' || videoError) && (
                <div className="absolute bottom-3 inset-x-3 bg-black/60 backdrop-blur-md rounded-xl p-2.5 border border-white/10 flex items-center justify-between gap-4 text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleTogglePlay}
                      className="p-1.5 rounded-lg bg-[#cfbcff]/20 hover:bg-[#cfbcff]/30 text-[#cfbcff] transition-colors"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </button>
                    <span className="text-zinc-300">
                      Motion: {activeVideo?.motion || motion}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-zinc-400 text-[10px]">Speed:</span>
                    <input
                      type="range"
                      min="20"
                      max="150"
                      value={motionStrength}
                      onChange={(e) => setMotionStrength(Number(e.target.value))}
                      className="w-20 accent-[#cfbcff] h-1.5 bg-white/20 rounded-lg cursor-pointer"
                    />
                    <span className="text-[#cfbcff] text-[10px] w-8">{motionStrength}%</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {activeVideo && (
            <div className="mt-4 pt-3 border-t border-white/5">
              <span className="text-[10px] font-mono uppercase text-zinc-500 block mb-1">
                Synthesized Prompt
              </span>
              <p className="text-xs text-zinc-300 font-sans leading-relaxed">
                "{activeVideo.prompt}"
              </p>
            </div>
          )}
        </div>

        {/* Video History List */}
        <div className="rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 p-5 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold font-sora text-white">Motion Sequence Queue</h3>
            <span className="text-[10px] font-mono text-zinc-400">{videos.length} clips</span>
          </div>

          <div className="space-y-3 overflow-y-auto max-h-[420px] pr-1">
            {videos.map((vid) => (
              <div
                key={vid.id}
                onClick={() => {
                  setActiveVideo(vid);
                  setVideoError(false);
                  setIsPlaying(true);
                }}
                className={`p-2.5 rounded-2xl border transition-all cursor-pointer flex items-center gap-3 ${
                  activeVideo?.id === vid.id
                    ? 'bg-[#cfbcff]/15 border-[#cfbcff]/50'
                    : 'bg-white/[0.02] border-white/5 hover:border-white/15'
                }`}
              >
                <div className="relative w-16 h-12 rounded-lg overflow-hidden bg-zinc-900 flex-shrink-0">
                  <img
                    src={vid.thumbnail}
                    alt={vid.prompt}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <Play className="w-3 h-3 text-white fill-white" />
                  </div>
                </div>

                <div className="min-w-0 flex-1">
                  <p className="text-xs text-zinc-300 font-medium truncate">
                    {vid.prompt}
                  </p>
                  <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-500 mt-1">
                    <span>{vid.duration}</span>
                    <span>•</span>
                    <span>{vid.motion}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
