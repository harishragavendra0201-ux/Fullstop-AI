import React, { useState, useEffect } from 'react';
import { ExamPrepPlan, UserProfile } from '../types';
import {
  BookOpenCheck,
  Sparkles,
  Calendar,
  CheckCircle,
  Clock,
  AlertTriangle,
  Lightbulb,
  FileCheck,
  Target,
  Zap,
  Bookmark,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface ExamPrepViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const PRESET_EXAMS = [
  'Data Structures & Algorithms Final',
  'AP Calculus BC Examination',
  'GRE Computer Science Subject Test',
  'Distributed Systems & Cloud Architecture',
  'Organic Chemistry II Midterm',
];

const INITIAL_EXAM_PLAN: ExamPrepPlan = {
  id: 'exam-plan-1',
  subject: 'Data Structures & Algorithms',
  targetExamDate: '2026-09-15',
  daysUntilExam: 7,
  highYieldFormulas: [
    {
      name: 'Master Theorem for Divide-and-Conquer',
      formula: 'T(n) = aT(n/b) + f(n) => Compare f(n) with n^(log_b a)',
      usageContext: 'Used for recurrence relations in MergeSort, Strassen Matrix, etc.',
      example: 'MergeSort: a=2, b=2, f(n)=O(n) => log_2(2)=1 => O(n log n)',
    },
    {
      name: 'Amortized Analysis (Accounting / Potential)',
      formula: 'â_i = c_i + Φ(D_i) - Φ(D_{i-1})',
      usageContext: 'Proves dynamic array resizing (doubling) takes O(1) amortized time.',
      example: 'N insertions take O(N) total cost despite occasional O(N) copy steps.',
    },
    {
      name: 'Eulerian Path Invariant',
      formula: 'Vertices with odd degrees must be either 0 or 2 for connected graphs.',
      usageContext: 'Verifies graph traversal without repeating edges in linear O(V+E).',
      example: 'Königsberg Bridges problem proof.',
    },
  ],
  highProbQuestions: [
    {
      id: 'hpq-1',
      question:
        'Explain how an LRU (Least Recently Used) cache achieves strict O(1) Get and Put operations.',
      answerOutline:
        'An LRU cache pairs a Doubly Linked List with a Hash Map. The Hash Map stores keys mapping directly to DLL Node pointers. On Get or Put, the node is disconnected in O(1) and moved to the head (Most Recently Used). When capacity exceeds limit, the tail node (Least Recently Used) is evicted in O(1) and deleted from the hash map.',
      priority: 'critical',
      expectedMarks: 10,
    },
    {
      id: 'hpq-2',
      question:
        'Prove why comparison-based sorting algorithms cannot be faster than Ω(n log n) in the worst case.',
      answerOutline:
        'A comparison sort can be modeled as a decision tree with n! possible permutations as leaves. The maximum depth corresponds to worst-case comparisons. A binary tree of depth h has at most 2^h leaves. Thus 2^h ≥ n!, which implies h ≥ log(n!). By Stirling’s approximation, log(n!) = Ω(n log n).',
      priority: 'high',
      expectedMarks: 15,
    },
  ],
  sprintSchedule: [
    {
      day: 1,
      theme: 'Foundations & Asymptotic Analysis',
      tasks: ['Review Master Theorem', 'Practice Big-O proofs', 'Amortized potential method'],
      durationHours: 3,
    },
    {
      day: 2,
      theme: 'Non-Linear Structures: Trees & Heaps',
      tasks: ['AVL / Red-Black rotations', 'Min/Max Heap sift-down in O(n)', 'Trie insertion'],
      durationHours: 3.5,
    },
    {
      day: 3,
      theme: 'Graph Algorithms & Shortest Path',
      tasks: ['Dijkstra with priority queue', 'Bellman-Ford negative cycles', 'Kruskal vs Prim MST'],
      durationHours: 4,
    },
    {
      day: 4,
      theme: 'Dynamic Programming Top-Down vs Bottom-Up',
      tasks: ['Knapsack 0/1 space optimization', 'Longest Common Subsequence', 'Matrix Chain multiplication'],
      durationHours: 4,
    },
    {
      day: 5,
      theme: 'Greedy & String Algorithms',
      tasks: ['Interval scheduling proofs', 'KMP string matching π table', 'Rabin-Karp rolling hashes'],
      durationHours: 3,
    },
    {
      day: 6,
      theme: 'Full Mock Timed Sprint',
      tasks: ['Simulate 3-hour past paper under closed-book constraints', 'Audit missed traps'],
      durationHours: 4.5,
    },
    {
      day: 7,
      theme: 'High-Yield Formula Review & Rest',
      tasks: ['Review flash formula cheatsheet', 'Sleep 8+ hours before test day'],
      durationHours: 2,
    },
  ],
  lastUpdated: new Date().toISOString(),
};

export const ExamPrepView: React.FC<ExamPrepViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [subject, setSubject] = useState(initialPrompt || '');
  const [targetExam, setTargetExam] = useState('');
  const [days, setDays] = useState(7);
  const [isLoading, setIsLoading] = useState(false);
  const [plan, setPlan] = useState<ExamPrepPlan>(INITIAL_EXAM_PLAN);
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>({});
  const [expandedQuestion, setExpandedQuestion] = useState<number | null>(0);
  const [hiddenFormulas, setHiddenFormulas] = useState<Record<number, boolean>>({});

  useEffect(() => {
    if (initialPrompt && initialPrompt !== subject) {
      setSubject(initialPrompt);
    }
  }, [initialPrompt]);

  const handleGeneratePlan = async () => {
    if (!subject.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/exam/prep', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subject: subject.trim(),
          targetExam: targetExam.trim() || 'Midterm / Final',
          days,
        }),
      });
      const data = await res.json();
      if (data.success && data.plan) {
        setPlan(data.plan);
        setCompletedTasks({});
        setExpandedQuestion(0);
      }
    } catch (err) {
      console.error('Exam Prep generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleTask = (taskId: string) => {
    setCompletedTasks((prev) => ({
      ...prev,
      [taskId]: !prev[taskId],
    }));
  };

  const totalTasks = plan.sprintSchedule.reduce((acc, curr) => acc + curr.tasks.length, 0);
  const checkedTasks = Object.values(completedTasks).filter(Boolean).length;
  const progressPercent = totalTasks > 0 ? Math.round((checkedTasks / totalTasks) * 100) : 0;

  return (
    <div id="exam-prep-view" className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171424] via-[#110e1c] to-[#07060c] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <BookOpenCheck className="w-3 h-3" />
                HIGH-YIELD SPRINT
              </span>
              <span className="text-xs font-mono text-zinc-400">EXAM READINESS BLUEPRINT</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              Exam Preparation Mode // High-Yield Sprint & Formula Vault
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Targeted revision matrices, high-probability test questions with grading keys, common traps,
              and a day-by-day sprint schedule to maximize retention.
            </p>
          </div>

          {/* Progress Widget */}
          <div className="p-4 rounded-xl bg-black/40 border border-white/10 flex items-center gap-4">
            <div className="text-right">
              <span className="text-[10px] font-mono text-zinc-400 uppercase block">Revision Sprint</span>
              <span className="text-base font-mono font-bold text-white">
                {checkedTasks}/{totalTasks} Tasks
              </span>
            </div>
            <div className="w-12 h-12 rounded-full border-2 border-white/10 flex items-center justify-center relative font-mono text-xs font-bold text-[#cfbcff]">
              <span>{progressPercent}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Generator Controls */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-5">
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Enter subject (e.g. Operating Systems, Macroeconomics, AP Chem)..."
              className="w-full px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-zinc-500 text-sm focus:outline-none focus:border-[#cfbcff]/50"
            />
          </div>

          <div className="md:col-span-4">
            <input
              type="text"
              value={targetExam}
              onChange={(e) => setTargetExam(e.target.value)}
              placeholder="Exam title (e.g. Midterm 2, Final Board, GRE CS)..."
              className="w-full px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-zinc-500 text-sm focus:outline-none focus:border-[#cfbcff]/50"
            />
          </div>

          <div className="md:col-span-3">
            <button
              onClick={handleGeneratePlan}
              disabled={isLoading || !subject.trim()}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#6750a4] text-[#1c0f38] font-bold text-sm flex items-center justify-center gap-2 hover:opacity-95 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(207,188,255,0.25)]"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-[#1c0f38] border-t-transparent animate-spin" />
                  <span>Building Sprint...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Exam Plan</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className="text-[11px] font-mono text-zinc-500 uppercase">Presets:</span>
          {PRESET_EXAMS.map((p) => (
            <button
              key={p}
              onClick={() => {
                setSubject(p);
                setTargetExam('Final Examination');
              }}
              className="px-2.5 py-1 rounded-full text-[11px] bg-white/[0.03] hover:bg-white/[0.08] text-zinc-300 border border-white/10 transition-colors"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Grid: 7-Day Sprint Roadmap & Formula Vault */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: 7-Day Sprint Roadmap */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5" />
                7-Day Revision Blueprint
              </span>
              <span className="text-xs font-mono text-zinc-400">
                {plan.subject} • {plan.targetExam}
              </span>
            </div>

            <div className="space-y-3">
              {plan.sprintSchedule.map((dayPlan) => (
                <div
                  key={dayPlan.day}
                  className="p-4 rounded-xl bg-white/[0.02] border border-white/5 hover:border-white/15 transition-all space-y-2.5"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-lg bg-[#cfbcff]/20 text-[#cfbcff] text-xs font-mono font-bold flex items-center justify-center">
                        D{dayPlan.day}
                      </span>
                      <h4 className="text-xs sm:text-sm font-semibold text-white font-sora">
                        {dayPlan.theme}
                      </h4>
                    </div>
                    <span className="text-[11px] font-mono text-zinc-400 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-amber-400" />
                      {dayPlan.durationHours} hrs
                    </span>
                  </div>

                  <div className="space-y-1.5 pl-9">
                    {dayPlan.tasks.map((task, tIdx) => {
                      const taskId = `d${dayPlan.day}-t${tIdx}`;
                      const isDone = Boolean(completedTasks[taskId]);
                      return (
                        <div
                          key={tIdx}
                          onClick={() => toggleTask(taskId)}
                          className="flex items-center gap-2.5 cursor-pointer group"
                        >
                          <div
                            className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${
                              isDone
                                ? 'bg-emerald-500 border-emerald-500 text-black'
                                : 'border-white/20 group-hover:border-[#cfbcff]'
                            }`}
                          >
                            {isDone && <CheckCircle className="w-3 h-3 text-black" />}
                          </div>
                          <span
                            className={`text-xs font-sans transition-colors ${
                              isDone ? 'line-through text-zinc-500' : 'text-zinc-300 group-hover:text-white'
                            }`}
                          >
                            {task}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Formulas & High Probability Questions */}
        <div className="lg:col-span-6 space-y-6">
          {/* Formula Bank */}
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-widest text-amber-300 font-bold flex items-center gap-2">
                <Zap className="w-3.5 h-3.5" />
                High-Yield Formula & Concept Vault
              </span>
              <span className="text-[11px] font-mono text-zinc-500">Active Recall Mode</span>
            </div>

            <div className="space-y-3">
              {plan.highYieldFormulas.map((f, idx) => {
                const isHidden = Boolean(hiddenFormulas[idx]);
                return (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <h5 className="text-xs font-semibold text-white font-sora">{f.name}</h5>
                      <button
                        onClick={() =>
                          setHiddenFormulas((prev) => ({
                            ...prev,
                            [idx]: !prev[idx],
                          }))
                        }
                        className="text-[10px] font-mono text-[#cfbcff] hover:underline"
                      >
                        {isHidden ? 'Reveal' : 'Hide for Recall'}
                      </button>
                    </div>

                    <div className="p-2.5 rounded-lg bg-amber-500/[0.06] border border-amber-500/20 font-mono text-xs text-amber-200">
                      {isHidden ? (
                        <span className="italic text-zinc-500">[Click reveal to test memory]</span>
                      ) : (
                        <span>{f.formula}</span>
                      )}
                    </div>

                    <p className="text-[11px] text-zinc-400">
                      <strong>Context:</strong> {f.usageContext}
                    </p>
                    {f.example && (
                      <p className="text-[11px] text-zinc-500 italic">
                        <strong>Example:</strong> {f.example}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* High-Probability Questions */}
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-2">
                <FileCheck className="w-3.5 h-3.5" />
                High-Probability Exam Questions
              </span>
              <span className="text-xs font-mono text-zinc-400">Model Answers & Traps</span>
            </div>

            <div className="space-y-3">
              {plan.highProbQuestions.map((q, idx) => {
                const isExpanded = expandedQuestion === idx;
                return (
                  <div
                    key={idx}
                    className="rounded-xl border border-white/10 bg-black/30 overflow-hidden"
                  >
                    <button
                      onClick={() => setExpandedQuestion(isExpanded ? null : idx)}
                      className="w-full p-4 flex items-center justify-between text-left hover:bg-white/[0.02] transition-colors"
                    >
                      <div className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded bg-white/10 text-white text-[10px] font-mono font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                          Q{idx + 1}
                        </span>
                        <div>
                          <p className="text-xs sm:text-sm font-medium text-zinc-200">{q.question}</p>
                          <span className="text-[10px] font-mono text-[#cfbcff]">
                            Target Allocation: {q.expectedMarks || 10} Marks • Priority: {q.priority}
                          </span>
                        </div>
                      </div>
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-zinc-400 flex-shrink-0 ml-2" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-zinc-400 flex-shrink-0 ml-2" />
                      )}
                    </button>

                    {isExpanded && (
                      <div className="p-4 pt-0 space-y-3 border-t border-white/5">
                        <div className="p-3 rounded-lg bg-emerald-500/[0.05] border border-emerald-500/20 text-xs text-zinc-300 font-sans leading-relaxed">
                          <strong className="text-emerald-300 block mb-1 font-mono uppercase text-[10px]">
                            Model Exam Solution:
                          </strong>
                          {q.answerOutline}
                        </div>

                        {q.pitfalls && q.pitfalls.length > 0 && (
                          <div className="p-3 rounded-lg bg-rose-500/[0.05] border border-rose-500/20 text-xs text-zinc-300 font-sans">
                            <strong className="text-rose-400 block mb-1 font-mono uppercase text-[10px] flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              Common Traps & Marks Deductions:
                            </strong>
                            <ul className="list-disc pl-4 space-y-1">
                              {q.pitfalls.map((pitfall, pIdx) => (
                                <li key={pIdx} className="text-zinc-400">
                                  {pitfall}
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
