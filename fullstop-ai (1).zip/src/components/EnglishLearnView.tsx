import React, { useState, useEffect, useRef } from 'react';
import { DialogueTurn, UserProfile } from '../types';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Sparkles,
  Send,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  Globe2,
  BookOpen,
  ArrowRight,
  Info,
  X,
} from 'lucide-react';

interface EnglishLearnViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const SCENARIOS = [
  {
    id: 'tech-interview',
    title: 'Silicon Valley Tech Interview',
    role: 'Hiring Manager (Sarah)',
    description: 'Discussing system design tradeoffs, career triumphs, and salary expectations.',
    initialAI:
      'Welcome! Thanks for joining us today. To start off, could you tell me about an engineering challenge you solved that you are particularly proud of?',
    suggestedPhrases: [
      'I spearheaded the migration to microservices, reducing latency by 40%.',
      'The primary tradeoff we balanced was eventual consistency vs read throughput.',
      'We implemented automated failover routines to handle peak concurrency gracefully.',
    ],
  },
  {
    id: 'investor-pitch',
    title: 'Seed Round Investor Pitch',
    role: 'Venture Capital Partner (David)',
    description: 'Defending your unit economics, moat, customer acquisition cost, and go-to-market plan.',
    initialAI:
      'We love your product prototype, but CAC looks elevated. How do you plan to scale organic distribution without burning through this round?',
    suggestedPhrases: [
      'Our organic viral coefficient is 1.4, driven by direct peer invitations.',
      'We maintain a 125% net retention rate with negative dollar churn in enterprise accounts.',
      'Our payback period on customer acquisition is under five months.',
    ],
  },
  {
    id: 'airport-travel',
    title: 'International Airport & Customs',
    role: 'Border Control Officer',
    description: 'Explaining your trip purpose, duration of stay, and accommodation details clearly and confidently.',
    initialAI:
      'Good morning. Passport and landing card, please. What is the primary purpose of your visit to London today?',
    suggestedPhrases: [
      'I am here for a ten-day artificial intelligence summit in central London.',
      'Here is my return flight confirmation and hotel reservation.',
      'I will be staying at the Hilton on Park Lane for the entire trip.',
    ],
  },
  {
    id: 'casual-coffee',
    title: 'Coffee Shop & Social Small Talk',
    role: 'Colleague / Friend (Alex)',
    description: 'Casual, idiomatic everyday English, chatting about hobbies, weekend plans, and current events.',
    initialAI:
      'Hey there! Glad we could finally catch a coffee break. How has your week been treating you so far?',
    suggestedPhrases: [
      'It has been a productive sprint! I am really looking forward to the weekend.',
      'I was just reading an interesting article on local weekend farmer markets.',
      'How did your team presentation go yesterday afternoon?',
    ],
  },
];

export const EnglishLearnView: React.FC<EnglishLearnViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
}) => {
  const [selectedScenario, setSelectedScenario] = useState(SCENARIOS[0]);
  const [userInput, setUserInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<DialogueTurn[]>([
    {
      id: 'turn-0',
      role: 'ai',
      text: SCENARIOS[0].initialAI,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [activeFeedback, setActiveFeedback] = useState<DialogueTurn['feedback']>({
    grammarCorrections: [
      {
        original: 'I am work on this project since two years.',
        corrected: 'I have been working on this project for two years.',
        explanation: 'Use present perfect continuous ("have been working") with "for" to express an action begun in past and continuing now.',
      },
    ],
    nativePhrasing: 'Instead of saying "I did a big work", try: "I spearheaded a high-impact initiative."',
    advancedVocabulary: [
      { word: 'Spearhead', definition: 'To lead or initiate a movement or endeavor', cefrLevel: 'C1' },
      { word: 'Tradeoff', definition: 'A balance achieved between two desirable but incompatible features', cefrLevel: 'B2' },
    ],
    pronunciationTips: ['Focus on linking words: "work-on" sounds like "wer-kon".'],
  });

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [micNotice, setMicNotice] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Speech Recognition setup
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      try {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onresult = (event: any) => {
          const transcript = event.results[0][0].transcript;
          setUserInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
          setIsRecording(false);
          setMicNotice(null);
        };

        recognition.onerror = (event: any) => {
          console.warn('Speech recognition warning:', event?.error);
          setIsRecording(false);
          if (event?.error === 'not-allowed' || event?.error === 'service-not-allowed') {
            setMicNotice('Microphone access is restricted in this window preview. You can type or use the one-tap phrases below.');
          }
        };

        recognition.onend = () => {
          setIsRecording(false);
        };

        recognitionRef.current = recognition;
      } catch (e) {
        console.warn('Speech recognition init error:', e);
      }
    }
  }, []);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const toggleRecording = () => {
    setMicNotice(null);
    if (!recognitionRef.current) {
      setMicNotice('Voice recognition is not supported in this browser. You can type directly or click any recommended phrase.');
      return;
    }

    if (isRecording) {
      try {
        recognitionRef.current.stop();
      } catch (e) {}
      setIsRecording(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (e) {
        console.warn('Recognition start exception:', e);
        setMicNotice('Microphone could not be started. You can type or click the suggested responses below.');
        setIsRecording(false);
      }
    }
  };

  const handleStopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const handleSpeakText = (text: string) => {
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        window.speechSynthesis.resume();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.95;
        utterance.lang = 'en-US';
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn('TTS error:', e);
        setIsSpeaking(false);
      }
    }
  };

  const handleSendMessage = async (explicitText?: string) => {
    const rawText = (explicitText !== undefined ? explicitText : userInput).trim();
    if (!rawText || isLoading) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    const currentText = rawText;
    setUserInput('');
    setMicNotice(null);

    const userTurn: DialogueTurn = {
      id: `turn-${Date.now()}-user`,
      role: 'user',
      text: currentText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setHistory((prev) => [...prev, userTurn]);
    setIsLoading(true);

    try {
      const res = await fetch('/api/english/converse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenario: selectedScenario.id,
          userUtterance: currentText,
          conversationHistory: history,
        }),
      });
      const data = await res.json();
      if (data.success && data.turn) {
        setHistory((prev) => [...prev, data.turn]);
        if (data.feedback) {
          setActiveFeedback(data.feedback);
        }
        // Auto-play speech for immersion
        if (data.turn.text) {
          handleSpeakText(data.turn.text);
        }
      }
    } catch (err) {
      console.error('Converse error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleScenarioChange = (s: (typeof SCENARIOS)[0]) => {
    handleStopSpeaking();
    setSelectedScenario(s);
    setMicNotice(null);
    setHistory([
      {
        id: `turn-${Date.now()}-ai`,
        role: 'ai',
        text: s.initialAI,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  return (
    <div id="english-learn-view" className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171424] via-[#100d1c] to-[#07060c] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <Globe2 className="w-3 h-3" />
                CONVERSATIONAL FLUENCY
              </span>
              <span className="text-xs font-mono text-zinc-400">VOICE & GRAMMAR INTELLIGENCE</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              English Speaking & Learn Mode // Real-Time Speech Coach
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Engage in interactive verbal roleplay with contextual AI personas. Receive instant grammar
              corrections, natural native rephrasing, CEFR vocabulary boosters, and pronunciation tips.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleScenarioChange(selectedScenario)}
              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-medium border border-white/10 flex items-center gap-2 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5 text-[#cfbcff]" />
              <span>Reset Dialogue</span>
            </button>
          </div>
        </div>
      </div>

      {/* Scenario Picker Carousel */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {SCENARIOS.map((s) => {
          const isSelected = selectedScenario.id === s.id;
          return (
            <div
              key={s.id}
              onClick={() => handleScenarioChange(s)}
              className={`p-4 rounded-xl border transition-all cursor-pointer ${
                isSelected
                  ? 'bg-[#cfbcff]/15 border-[#cfbcff]/50 shadow-[0_0_15px_rgba(207,188,255,0.1)]'
                  : 'bg-[#0e0c14]/80 border-white/5 hover:border-white/15'
              }`}
            >
              <span className="text-[10px] font-mono text-[#cfbcff] uppercase tracking-wider block mb-1">
                {s.role}
              </span>
              <h4 className="text-xs sm:text-sm font-semibold text-white font-sora">{s.title}</h4>
              <p className="text-[11px] text-zinc-400 mt-1 line-clamp-2">{s.description}</p>
            </div>
          );
        })}
      </div>

      {/* Main Two-Column View: Chat Arena + Real-Time Coach */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Dialogue Simulator (7 cols) */}
        <div className="lg:col-span-7 flex flex-col h-[600px] rounded-2xl bg-[#0c0a12]/95 border border-white/10 overflow-hidden shadow-2xl">
          {/* Top Bar */}
          <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38] font-bold text-xs flex items-center justify-center font-sora">
                AI
              </div>
              <div>
                <h4 className="text-xs font-semibold text-white font-sora">
                  {selectedScenario.role}
                </h4>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Interactive Speech Partner
                  </span>
                  {isSpeaking && (
                    <button
                      onClick={handleStopSpeaking}
                      className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[9px] font-mono flex items-center gap-1 hover:bg-rose-500/30 transition-colors"
                      title="Stop audio playback"
                    >
                      <VolumeX className="w-2.5 h-2.5" />
                      <span>Speaking (Stop)</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
            <span className="text-[10px] font-mono text-zinc-400 bg-white/5 px-2.5 py-1 rounded-full border border-white/10">
              {selectedScenario.title}
            </span>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {history.map((turn) => {
              const isAi = turn.role === 'ai';
              return (
                <div
                  key={turn.id}
                  className={`flex items-start gap-2.5 ${isAi ? '' : 'flex-row-reverse'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-mono font-bold flex-shrink-0 mt-1 ${
                      isAi
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff]'
                        : 'bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38]'
                    }`}
                  >
                    {isAi ? 'AI' : 'YOU'}
                  </div>

                  <div
                    className={`max-w-[80%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed font-sans ${
                      isAi
                        ? 'bg-white/[0.04] border border-white/10 text-zinc-200 rounded-tl-none'
                        : 'bg-[#cfbcff]/20 border border-[#cfbcff]/40 text-white rounded-tr-none'
                    }`}
                  >
                    <p>{turn.text}</p>
                    <div className="flex items-center justify-between mt-2 pt-1 border-t border-white/5 text-[10px] font-mono text-zinc-400">
                      <span>{turn.timestamp}</span>
                      <button
                        onClick={() => handleSpeakText(turn.text)}
                        className="hover:text-[#cfbcff] flex items-center gap-1 transition-colors"
                        title="Listen to pronunciation"
                      >
                        <Volume2 className="w-3 h-3" />
                        <span>{isAi ? 'Pronounce' : 'Replay'}</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
            {isLoading && (
              <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 p-2">
                <div className="w-3 h-3 rounded-full border border-[#cfbcff] border-t-transparent animate-spin" />
                <span>Coach is formulating feedback & spoken reply...</span>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Voice & Input Controls */}
          <div className="p-3 bg-black/60 border-t border-white/10 space-y-2">
            {/* Microphone Notice Banner if mic error or unavailable */}
            {micNotice && (
              <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start justify-between gap-2 text-[11px] text-amber-300">
                <div className="flex items-start gap-1.5">
                  <Info className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                  <span>{micNotice}</span>
                </div>
                <button
                  onClick={() => setMicNotice(null)}
                  className="text-amber-400 hover:text-white p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            )}

            {/* Quick-Practice Scenario Prompts */}
            {selectedScenario.suggestedPhrases && (
              <div className="space-y-1">
                <span className="text-[10px] font-mono text-zinc-400 block">
                  Quick Practice Phrases (Click to test speaking):
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-16 overflow-y-auto">
                  {selectedScenario.suggestedPhrases.map((phrase, pIdx) => (
                    <button
                      key={pIdx}
                      onClick={() => handleSendMessage(phrase)}
                      disabled={isLoading}
                      className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-[#cfbcff]/15 hover:border-[#cfbcff]/40 text-zinc-300 hover:text-white text-[11px] border border-white/10 transition-colors text-left"
                    >
                      💬 {phrase}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={toggleRecording}
                className={`p-3 rounded-xl border transition-all flex items-center justify-center ${
                  isRecording
                    ? 'bg-rose-500 text-white border-rose-400 animate-pulse'
                    : 'bg-white/5 hover:bg-white/10 text-zinc-300 border-white/10'
                }`}
                title={isRecording ? 'Click to stop speech recognition' : 'Click to speak via microphone'}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-[#cfbcff]" />}
              </button>

              <input
                type="text"
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder={
                  isRecording
                    ? 'Listening to speech in real-time...'
                    : 'Speak via mic or type your response in English...'
                }
                className="flex-1 px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none focus:border-[#cfbcff]/50"
              />

              <button
                onClick={() => handleSendMessage()}
                disabled={isLoading || !userInput.trim()}
                className="p-3 rounded-xl bg-[#cfbcff] text-[#1c0f38] font-bold hover:opacity-90 disabled:opacity-40 transition-opacity"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Real-Time Grammar & Vocabulary Coach (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-[#cfbcff]" />
                Live Linguistic Analysis
              </span>
              <span className="text-[10px] font-mono text-zinc-500 uppercase">CEFR B2-C2</span>
            </div>

            {/* Grammar Corrections */}
            <div className="space-y-2.5">
              <span className="text-xs font-mono uppercase text-rose-300 font-semibold flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                Grammar Precision Check
              </span>
              {activeFeedback?.grammarCorrections && activeFeedback.grammarCorrections.length > 0 ? (
                activeFeedback.grammarCorrections.map((g, idx) => (
                  <div key={idx} className="p-3 rounded-xl bg-rose-500/[0.06] border border-rose-500/20 space-y-1.5">
                    <div className="flex items-start gap-2">
                      <span className="text-rose-400 line-through text-xs font-sans">{g.original}</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <ArrowRight className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span className="text-emerald-300 font-semibold text-xs font-sans">{g.corrected}</span>
                    </div>
                    <p className="text-[11px] text-zinc-400 pt-1 border-t border-white/5">{g.explanation}</p>
                  </div>
                ))
              ) : (
                <div className="p-3 rounded-xl bg-emerald-500/[0.05] border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Flawless syntactic construction! No grammar defects detected.</span>
                </div>
              )}
            </div>

            {/* Native Phrasing */}
            {activeFeedback?.nativePhrasing && (
              <div className="p-4 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 space-y-1.5">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#cfbcff] font-bold flex items-center gap-1.5">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-300" />
                  Native Idiomatic Upgrade
                </span>
                <p className="text-xs sm:text-sm text-zinc-200 leading-relaxed font-sans">
                  {activeFeedback.nativePhrasing}
                </p>
              </div>
            )}

            {/* Advanced Vocabulary */}
            {activeFeedback?.advancedVocabulary && activeFeedback.advancedVocabulary.length > 0 && (
              <div className="space-y-2">
                <span className="text-xs font-mono uppercase text-amber-300 font-semibold flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-amber-400" />
                  Lexical Spotlight (High CEFR)
                </span>
                <div className="space-y-2">
                  {activeFeedback.advancedVocabulary.map((v, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-start justify-between gap-2"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white font-sora">{v.word}</span>
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-amber-400/20 text-amber-300 border border-amber-400/30">
                            {v.cefrLevel || 'C1'}
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-400 mt-0.5">{v.definition}</p>
                      </div>
                      <button
                        onClick={() => handleSpeakText(v.word)}
                        className="text-zinc-500 hover:text-white p-1"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Pronunciation & Phonetics */}
            {activeFeedback?.pronunciationTips && activeFeedback.pronunciationTips.length > 0 && (
              <div className="p-3 rounded-xl bg-blue-500/[0.06] border border-blue-500/20 space-y-1">
                <span className="text-[10px] font-mono uppercase tracking-wider text-blue-300 font-bold block">
                  Phonetic Stress & Cadence Tip
                </span>
                <ul className="text-xs text-zinc-300 space-y-1">
                  {activeFeedback.pronunciationTips.map((tip, idx) => (
                    <li key={idx}>• {tip}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
