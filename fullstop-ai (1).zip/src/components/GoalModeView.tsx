import React, { useState, useEffect } from 'react';
import { GoalItem, GoalMilestone, DailyHabit, UserProfile } from '../types';
import {
  Target,
  Sparkles,
  Plus,
  CheckCircle2,
  Circle,
  Flame,
  AlertTriangle,
  TrendingUp,
  Calendar,
  Layers,
  ChevronRight,
  RotateCcw,
  Trash2,
  Zap,
  HelpCircle,
  Check,
} from 'lucide-react';

interface GoalModeViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const DEFAULT_PRESET_GOALS = [
  'Launch an AI-powered Micro-SaaS in 30 days',
  'Master Rust & build a concurrent distributed key-value store',
  'Run a sub-2 hour half marathon in 12 weeks',
  'Read and synthesize 12 seminal books on cognitive science',
];

const STORAGE_KEY = 'fullstop_user_goals';

const INITIAL_GOAL: GoalItem = {
  id: 'goal-seed-1',
  title: 'Launch an AI-powered Micro-SaaS in 30 days',
  category: 'Engineering / SaaS',
  timeframe: '30 days',
  smartSummary:
    'Build, launch, and validate a targeted AI productivity tool within 30 days, acquiring the first 10 paying customers through laser-focused niche distribution.',
  progress: 35,
  milestones: [
    {
      id: 'm-1',
      phase: 'Phase 1: Validation & Architecture',
      title: 'Define ICP, validate pain point, and architect core pipeline',
      description: 'Interview 5 potential users and finalize server architecture',
      completed: true,
      subtasks: [
        { id: 'st-1-1', text: 'Conduct 5 direct customer discovery calls', completed: true },
        { id: 'st-1-2', text: 'Design database schema and API route contracts', completed: true },
        { id: 'st-1-3', text: 'Set up Vite + Express + Gemini SDK scaffolding', completed: true },
      ],
    },
    {
      id: 'm-2',
      phase: 'Phase 2: Core Build & Polish',
      title: 'Implement the high-leverage value loop & billing',
      description: 'Build core prompt engine, UI dashboard, and Stripe checkout',
      completed: false,
      subtasks: [
        { id: 'st-2-1', text: 'Build AI processing engine with resilient fallback', completed: true },
        { id: 'st-2-2', text: 'Implement auth session management and rate limiting', completed: false },
        { id: 'st-2-3', text: 'Integrate Stripe checkout portal & webhook handler', completed: false },
      ],
    },
    {
      id: 'm-3',
      phase: 'Phase 3: Launch & Distribution',
      title: 'Public debut, launch on Product Hunt, and acquire 10 customers',
      description: 'Execute launch campaign and iterate on initial customer telemetry',
      completed: false,
      subtasks: [
        { id: 'st-3-1', text: 'Record 60-second interactive demo reel', completed: false },
        { id: 'st-3-2', text: 'Launch on Product Hunt and relevant subreddits', completed: false },
        { id: 'st-3-3', text: 'Convert 10 users to paying pro subscribers', completed: false },
      ],
    },
  ],
  habits: [
    { id: 'h-1', title: 'Deep Work Sprint: 60 mins dedicated code', frequency: 'Daily', completedToday: true, streak: 5 },
    { id: 'h-2', title: 'Customer Outreach: Message 3 prospects', frequency: 'Daily', completedToday: false, streak: 3 },
    { id: 'h-3', title: 'Weekly Sprint Retrospective & Metric Audit', frequency: 'Weekly', completedToday: false, streak: 2 },
  ],
  risksAndContingencies: [
    {
      risk: 'Scope creep pushing launch date past 30 days',
      contingency: 'Cut non-critical nice-to-haves and lock MVP feature freeze by day 14',
    },
    {
      risk: 'Distribution bottleneck (zero initial website traffic)',
      contingency: 'Pre-build audience on X/LinkedIn by sharing daily build-in-public updates',
    },
  ],
  kpis: ['10 paying subscribers ($200+ MRR)', 'Sub-800ms median AI response latency', 'Zero fatal crash reports in launch week'],
  createdAt: new Date().toISOString(),
};

export const GoalModeView: React.FC<GoalModeViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt = '',
}) => {
  const [goals, setGoals] = useState<GoalItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error('Failed to parse saved goals', e);
      }
    }
    return [INITIAL_GOAL];
  });

  const [activeGoalId, setActiveGoalId] = useState<string>(() => goals[0]?.id || INITIAL_GOAL.id);
  const [goalInput, setGoalInput] = useState(initialPrompt);
  const [timeframe, setTimeframe] = useState('30 days');
  const [category, setCategory] = useState('Engineering / SaaS');
  const [skillLevel, setSkillLevel] = useState('Intermediate');
  const [isDeconstructing, setIsDeconstructing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Blocker Assistant
  const [blockerMilestone, setBlockerMilestone] = useState<GoalMilestone | null>(null);
  const [blockerAdvice, setBlockerAdvice] = useState<string | null>(null);
  const [isResolvingBlocker, setIsResolvingBlocker] = useState(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(goals));
  }, [goals]);

  const activeGoal = goals.find((g) => g.id === activeGoalId) || goals[0];

  // Recalculate progress based on subtasks
  const calculateProgress = (milestones: GoalMilestone[]): number => {
    let totalSubtasks = 0;
    let completedSubtasks = 0;

    milestones.forEach((m) => {
      if (m.subtasks && m.subtasks.length > 0) {
        m.subtasks.forEach((st) => {
          totalSubtasks++;
          if (st.completed) completedSubtasks++;
        });
      } else {
        totalSubtasks++;
        if (m.completed) completedSubtasks++;
      }
    });

    if (totalSubtasks === 0) return 0;
    return Math.round((completedSubtasks / totalSubtasks) * 100);
  };

  const handleDeconstruct = async () => {
    if (!goalInput.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsDeconstructing(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/goal/breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goalTitle: goalInput.trim(),
          timeframe,
          category,
          skillLevel,
        }),
      });

      const json = await res.json();
      if (!res.ok || !json.success) {
        throw new Error(json.error || 'Failed to architect goal roadmap.');
      }

      const raw = json.data;
      const newGoal: GoalItem = {
        id: 'goal-' + Date.now(),
        title: goalInput.trim(),
        category,
        timeframe,
        smartSummary: raw.smartSummary || 'Goal execution architecture prepared.',
        milestones: raw.milestones || [],
        habits: raw.habits || [],
        risksAndContingencies: raw.risksAndContingencies || [],
        kpis: raw.kpis || [],
        progress: 0,
        createdAt: new Date().toISOString(),
      };

      setGoals((prev) => [newGoal, ...prev]);
      setActiveGoalId(newGoal.id);
      setGoalInput('');
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || 'Error communicating with Goal Engine.');
    } finally {
      setIsDeconstructing(false);
    }
  };

  const handleToggleSubtask = (milestoneId: string, subtaskId: string) => {
    if (!activeGoal) return;
    const updatedMilestones = activeGoal.milestones.map((m) => {
      if (m.id !== milestoneId) return m;
      const updatedSubtasks = (m.subtasks || []).map((st) =>
        st.id === subtaskId ? { ...st, completed: !st.completed } : st
      );
      const allDone = updatedSubtasks.every((st) => st.completed);
      return { ...m, subtasks: updatedSubtasks, completed: allDone };
    });

    const newProgress = calculateProgress(updatedMilestones);
    updateCurrentGoal({ milestones: updatedMilestones, progress: newProgress });
  };

  const handleToggleMilestone = (milestoneId: string) => {
    if (!activeGoal) return;
    const updatedMilestones = activeGoal.milestones.map((m) => {
      if (m.id !== milestoneId) return m;
      const newCompleted = !m.completed;
      const updatedSubtasks = (m.subtasks || []).map((st) => ({ ...st, completed: newCompleted }));
      return { ...m, completed: newCompleted, subtasks: updatedSubtasks };
    });

    const newProgress = calculateProgress(updatedMilestones);
    updateCurrentGoal({ milestones: updatedMilestones, progress: newProgress });
  };

  const handleToggleHabit = (habitId: string) => {
    if (!activeGoal) return;
    const updatedHabits = activeGoal.habits.map((h) => {
      if (h.id !== habitId) return h;
      const wasCompleted = h.completedToday;
      return {
        ...h,
        completedToday: !wasCompleted,
        streak: wasCompleted ? Math.max(0, h.streak - 1) : h.streak + 1,
      };
    });
    updateCurrentGoal({ habits: updatedHabits });
  };

  const updateCurrentGoal = (patch: Partial<GoalItem>) => {
    if (!activeGoal) return;
    setGoals((prev) =>
      prev.map((g) => (g.id === activeGoal.id ? { ...g, ...patch } : g))
    );
  };

  const handleDeleteGoal = (id: string) => {
    if (goals.length <= 1) {
      alert('You must keep at least one goal in your workspace.');
      return;
    }
    const filtered = goals.filter((g) => g.id !== id);
    setGoals(filtered);
    if (activeGoalId === id) {
      setActiveGoalId(filtered[0]?.id || '');
    }
  };

  const handleConsultBlocker = async (milestone: GoalMilestone) => {
    setBlockerMilestone(milestone);
    setBlockerAdvice(null);
    setIsResolvingBlocker(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `I am currently blocked or seeking tactical advice on this milestone for my goal "${activeGoal?.title}":\n` +
            `Milestone: "${milestone.title}" (${milestone.phase})\n` +
            `Subtasks: ${milestone.subtasks?.map((st) => st.text).join(', ')}\n\n` +
            `Give me 3 precise, high-leverage steps to unblock this right now and complete it.`,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch unblocker advice.');
      setBlockerAdvice(data.reply);
    } catch (err: any) {
      console.error(err);
      setBlockerAdvice('Unable to generate unblock advice at this moment. ' + err.message);
    } finally {
      setIsResolvingBlocker(false);
    }
  };

  return (
    <div id="goal-mode-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Top Header Banner */}
      <div className="relative rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 sm:p-8 border border-white/10 overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#6750a4]/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] flex items-center justify-center text-[#1c0f38] shadow-[0_0_15px_rgba(207,188,255,0.4)]">
                <Target className="w-5 h-5" />
              </div>
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono uppercase bg-[#cfbcff]/10 text-[#cfbcff] border border-[#cfbcff]/30 font-semibold">
                  GOAL MODE • EXECUTION ARCHITECTURE
                </span>
                <h1 className="text-xl sm:text-2xl font-bold font-sora text-white">
                  Strategic Roadmap & Milestone Engine
                </h1>
              </div>
            </div>

            {/* Quick Metrics */}
            <div className="flex items-center gap-2 font-mono text-xs">
              <div className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[#cfbcff]" />
                <span>{goals.length} Tracked Goals</span>
              </div>
              <div className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>
                  {activeGoal?.habits.reduce((acc, h) => acc + h.streak, 0) || 0} Cumulative Streak
                </span>
              </div>
            </div>
          </div>

          <p className="text-sm text-zinc-400 max-w-2xl">
            Deconstruct high-level ambitions into deterministic phased milestones, daily consistency habits,
            and pre-mortem risk safeguards using the Gemini reasoning architecture.
          </p>

          {/* AI Goal Deconstructor Input */}
          <div className="mt-6 p-3 rounded-2xl bg-[#14111d]/90 border border-white/15 focus-within:border-[#cfbcff]/60 transition-all space-y-3">
            <div className="flex items-center gap-3 px-2">
              <Target className="w-5 h-5 text-[#cfbcff] flex-shrink-0" />
              <input
                id="goal-input-field"
                type="text"
                value={goalInput}
                onChange={(e) => setGoalInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleDeconstruct();
                }}
                placeholder="Enter any ambitious goal (e.g. 'Build and monetize an open-source AI devtool in 60 days')..."
                className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none font-sans"
              />
            </div>

            {/* Config Controls & Presets */}
            <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <select
                  value={timeframe}
                  onChange={(e) => setTimeframe(e.target.value)}
                  className="bg-[#09080e] text-xs font-mono text-zinc-300 px-2.5 py-1.5 rounded-lg border border-white/10 outline-none hover:border-[#cfbcff]/40 transition-colors"
                >
                  <option value="2 weeks">2 Weeks Sprint</option>
                  <option value="30 days">30 Days</option>
                  <option value="60 days">60 Days</option>
                  <option value="90 days (Quarter)">90 Days (Quarter)</option>
                  <option value="6 months">6 Months</option>
                  <option value="1 year">1 Year</option>
                </select>

                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="bg-[#09080e] text-xs font-mono text-zinc-300 px-2.5 py-1.5 rounded-lg border border-white/10 outline-none hover:border-[#cfbcff]/40 transition-colors"
                >
                  <option value="Engineering / SaaS">Engineering / SaaS</option>
                  <option value="Learning & Mastery">Learning & Mastery</option>
                  <option value="Health & Athletics">Health & Athletics</option>
                  <option value="Business & Wealth">Business & Wealth</option>
                  <option value="Creative & Media">Creative & Media</option>
                </select>

                <select
                  value={skillLevel}
                  onChange={(e) => setSkillLevel(e.target.value)}
                  className="bg-[#09080e] text-xs font-mono text-zinc-300 px-2.5 py-1.5 rounded-lg border border-white/10 outline-none hover:border-[#cfbcff]/40 transition-colors"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced / Expert">Advanced / Expert</option>
                </select>
              </div>

              <button
                id="btn-deconstruct-goal"
                onClick={handleDeconstruct}
                disabled={isDeconstructing || !goalInput.trim()}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold font-sora text-[#1c0f38] bg-gradient-to-r from-[#cfbcff] to-[#e8def8] hover:opacity-95 disabled:opacity-50 transition-all cursor-pointer shadow-lg shadow-[#cfbcff]/20"
              >
                {isDeconstructing ? (
                  <>
                    <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                    <span>Architecting Roadmap...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Deconstruct With AI</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick Inspiration Pills */}
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[10px] font-mono text-zinc-500 uppercase mr-1">Inspirations:</span>
              {DEFAULT_PRESET_GOALS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setGoalInput(preset)}
                  className="text-[11px] px-2.5 py-1 rounded-md bg-white/[0.03] hover:bg-white/[0.08] text-zinc-400 hover:text-white border border-white/5 transition-colors"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Error Banner */}
          {errorMessage && (
            <div className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300 flex items-center justify-between">
              <span>{errorMessage}</span>
              <button
                onClick={handleDeconstruct}
                className="px-2 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-white font-mono"
              >
                Retry
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Goal Switcher Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {goals.map((g) => {
          const isActive = g.id === activeGoal?.id;
          return (
            <div
              key={g.id}
              onClick={() => setActiveGoalId(g.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl border text-xs font-medium cursor-pointer transition-all flex-shrink-0 ${
                isActive
                  ? 'bg-[#1e192b] border-[#cfbcff]/50 text-white shadow-lg shadow-[#6750a4]/20'
                  : 'bg-[#0e0c14]/80 border-white/10 text-zinc-400 hover:text-zinc-200 hover:border-white/20'
              }`}
            >
              <div
                className={`w-2 h-2 rounded-full ${
                  g.progress === 100 ? 'bg-emerald-400' : 'bg-[#cfbcff]'
                }`}
              />
              <span className="max-w-[200px] truncate font-sora">{g.title}</span>
              <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-white/5 text-zinc-300">
                {g.progress}%
              </span>
              {goals.length > 1 && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteGoal(g.id);
                  }}
                  className="p-1 hover:text-rose-400 rounded transition-colors"
                  title="Remove goal"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Active Goal Workspace */}
      {activeGoal && (
        <div className="space-y-6">
          {/* Active Goal Overview & SMART Summary */}
          <div className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 sm:p-8 border border-white/10 space-y-6">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="px-2.5 py-0.5 rounded-md text-[10px] font-mono uppercase bg-[#6750a4]/30 text-[#cfbcff] border border-[#6750a4]/50">
                    {activeGoal.category}
                  </span>
                  <span className="text-xs font-mono text-zinc-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {activeGoal.timeframe}
                  </span>
                </div>
                <h2 className="text-2xl font-bold font-sora text-white">{activeGoal.title}</h2>
              </div>

              {/* Progress Metric Ring */}
              <div className="flex items-center gap-4 bg-white/5 p-3 rounded-2xl border border-white/10">
                <div className="text-right font-mono">
                  <div className="text-xs text-zinc-400">Total Completion</div>
                  <div className="text-xl font-bold text-white">{activeGoal.progress}%</div>
                </div>
                <div className="w-12 h-12 rounded-full border-2 border-white/10 flex items-center justify-center relative">
                  <div
                    className="absolute inset-0 rounded-full border-2 border-[#cfbcff]"
                    style={{
                      clipPath: `polygon(0 0, 100% 0, 100% 100%, 0 100%)`,
                      opacity: activeGoal.progress / 100,
                    }}
                  />
                  <span className="text-xs font-mono font-bold text-[#cfbcff]">
                    {activeGoal.progress}%
                  </span>
                </div>
              </div>
            </div>

            {/* Visual Progress Bar */}
            <div className="w-full bg-white/5 h-2.5 rounded-full overflow-hidden border border-white/10">
              <div
                className="bg-gradient-to-r from-[#6750a4] to-[#cfbcff] h-full transition-all duration-500 rounded-full"
                style={{ width: `${activeGoal.progress}%` }}
              />
            </div>

            {/* SMART Blueprint Summary */}
            <div className="p-4 rounded-2xl bg-[#14111d] border border-white/10 flex items-start gap-3">
              <Zap className="w-5 h-5 text-[#cfbcff] flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-xs font-mono font-semibold uppercase text-zinc-400 tracking-wider mb-1">
                  SMART Objective Blueprint
                </h3>
                <p className="text-xs sm:text-sm text-zinc-200 leading-relaxed">
                  {activeGoal.smartSummary}
                </p>
              </div>
            </div>
          </div>

          {/* Phased Milestones Grid */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold font-sora text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#cfbcff]" />
                <span>Phased Execution Milestones</span>
              </h3>
              <span className="text-xs font-mono text-zinc-400">
                {activeGoal.milestones.filter((m) => m.completed).length} / {activeGoal.milestones.length} Completed
              </span>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              {activeGoal.milestones.map((milestone, idx) => (
                <div
                  key={milestone.id}
                  className={`rounded-2xl glass-panel p-5 border transition-all space-y-4 flex flex-col justify-between ${
                    milestone.completed
                      ? 'bg-[#14111d]/90 border-emerald-500/30'
                      : 'bg-[#0e0c14]/90 border-white/10 hover:border-[#cfbcff]/40'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/5 text-[#cfbcff] border border-white/10">
                        {milestone.phase || `Phase ${idx + 1}`}
                      </span>
                      <button
                        type="button"
                        onClick={() => handleToggleMilestone(milestone.id)}
                        className={`p-1 rounded-lg transition-colors ${
                          milestone.completed
                            ? 'text-emerald-400 hover:text-emerald-300'
                            : 'text-zinc-500 hover:text-zinc-300'
                        }`}
                      >
                        {milestone.completed ? (
                          <CheckCircle2 className="w-5 h-5" />
                        ) : (
                          <Circle className="w-5 h-5" />
                        )}
                      </button>
                    </div>

                    <h4
                      className={`text-sm font-semibold font-sora ${
                        milestone.completed ? 'line-through text-zinc-400' : 'text-white'
                      }`}
                    >
                      {milestone.title}
                    </h4>

                    {milestone.description && (
                      <p className="text-xs text-zinc-400 leading-relaxed">
                        {milestone.description}
                      </p>
                    )}

                    {/* Subtasks Checklist */}
                    {milestone.subtasks && milestone.subtasks.length > 0 && (
                      <div className="space-y-1.5 pt-2 border-t border-white/5">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase">Subtasks:</span>
                        {milestone.subtasks.map((st) => (
                          <div
                            key={st.id}
                            onClick={() => handleToggleSubtask(milestone.id, st.id)}
                            className="flex items-start gap-2 text-xs text-zinc-300 cursor-pointer group py-0.5"
                          >
                            <div
                              className={`w-3.5 h-3.5 rounded border mt-0.5 flex items-center justify-center flex-shrink-0 transition-colors ${
                                st.completed
                                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                                  : 'border-white/20 group-hover:border-[#cfbcff]'
                              }`}
                            >
                              {st.completed && <Check className="w-2.5 h-2.5" />}
                            </div>
                            <span className={st.completed ? 'line-through text-zinc-500' : ''}>
                              {st.text}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Ask Gemini to Unblock */}
                  <div className="pt-3 border-t border-white/5">
                    <button
                      type="button"
                      onClick={() => handleConsultBlocker(milestone)}
                      className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-xl text-[11px] font-mono text-zinc-400 hover:text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all cursor-pointer"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Unblock Milestone with AI</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Daily Habits & Risk Defense Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            {/* Daily Habits & Micro-Commitments */}
            <div className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold font-sora text-white flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span>Daily Micro-Habits & Rituals</span>
                </h3>
                <span className="text-xs font-mono text-zinc-400">Consistency Loops</span>
              </div>

              <div className="space-y-2.5">
                {activeGoal.habits.map((habit) => (
                  <div
                    key={habit.id}
                    onClick={() => handleToggleHabit(habit.id)}
                    className={`p-3.5 rounded-2xl border transition-all flex items-center justify-between cursor-pointer ${
                      habit.completedToday
                        ? 'bg-amber-500/10 border-amber-500/30'
                        : 'bg-[#14111d] border-white/10 hover:border-amber-400/40'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                          habit.completedToday
                            ? 'bg-amber-400 border-amber-400 text-black'
                            : 'border-white/20'
                        }`}
                      >
                        {habit.completedToday && <Check className="w-3 h-3" />}
                      </div>
                      <div>
                        <div
                          className={`text-xs sm:text-sm font-medium ${
                            habit.completedToday ? 'text-zinc-300' : 'text-white'
                          }`}
                        >
                          {habit.title}
                        </div>
                        <div className="text-[10px] font-mono text-zinc-500">{habit.frequency}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 font-mono text-xs text-amber-300 bg-amber-500/15 px-2.5 py-1 rounded-xl border border-amber-500/20">
                      <Flame className="w-3.5 h-3.5" />
                      <span>{habit.streak}d</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Risk Contingencies & Pre-Mortem Protections */}
            <div className="rounded-3xl glass-panel bg-[#0e0c14]/90 p-6 border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold font-sora text-white flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>Pre-Mortem Contingencies</span>
                </h3>
                <span className="text-xs font-mono text-zinc-400">Failure Safeguards</span>
              </div>

              <div className="space-y-3">
                {activeGoal.risksAndContingencies.map((item, i) => (
                  <div key={i} className="p-3.5 rounded-2xl bg-[#14111d] border border-white/10 space-y-2">
                    <div className="flex items-start gap-2">
                      <span className="text-rose-400 font-mono text-xs font-bold mt-0.5">RISK:</span>
                      <p className="text-xs text-zinc-300">{item.risk}</p>
                    </div>
                    <div className="flex items-start gap-2 pt-2 border-t border-white/5">
                      <span className="text-emerald-400 font-mono text-xs font-bold mt-0.5">REMEDY:</span>
                      <p className="text-xs text-zinc-300 leading-relaxed">{item.contingency}</p>
                    </div>
                  </div>
                ))}

                {/* Key Success Metrics (KPIs) */}
                <div className="p-3 rounded-2xl bg-white/5 border border-white/10">
                  <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider block mb-1.5">
                    Target KPIs & Validation Criteria:
                  </span>
                  <ul className="space-y-1">
                    {activeGoal.kpis.map((kpi, kIdx) => (
                      <li key={kIdx} className="text-xs text-zinc-300 flex items-center gap-2">
                        <TrendingUp className="w-3 h-3 text-[#cfbcff] flex-shrink-0" />
                        <span>{kpi}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Blocker Modal / Drawer */}
      {blockerMilestone && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-xl bg-[#0e0c14] border border-[#cfbcff]/30 rounded-3xl p-6 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#cfbcff]" />
                <h3 className="text-base font-bold font-sora text-white">
                  AI Milestone Unblocker
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setBlockerMilestone(null)}
                className="text-zinc-400 hover:text-white text-sm font-mono px-2 py-1 rounded bg-white/5"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-2">
              <span className="text-[10px] font-mono uppercase text-zinc-500">Target Milestone:</span>
              <div className="text-sm font-semibold text-white">{blockerMilestone.title}</div>
            </div>

            <div className="p-4 rounded-2xl bg-[#14111d] border border-white/10 min-h-[160px] flex flex-col justify-center">
              {isResolvingBlocker ? (
                <div className="flex flex-col items-center justify-center gap-3 py-6 text-xs text-[#cfbcff] font-mono">
                  <RotateCcw className="w-5 h-5 animate-spin" />
                  <span>Synthesizing high-leverage resolution tactics...</span>
                </div>
              ) : (
                <div className="text-xs sm:text-sm text-zinc-200 whitespace-pre-wrap leading-relaxed">
                  {blockerAdvice || 'No advice generated yet.'}
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={() => setBlockerMilestone(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/20 text-white font-sora transition-colors"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
