import React, { useState } from 'react';
import { GeneratedImageItem, UserProfile } from '../types';
import {
  Sparkles,
  Wand2,
  Download,
  Copy,
  Check,
  Maximize2,
  X,
  Layers,
  Sliders,
  Image as ImageIcon,
  RefreshCw,
  Zap,
  AlertTriangle,
  Lightbulb,
} from 'lucide-react';
import neuralCoreImg from '../assets/images/fullstop_neural_core_1788793756561.jpg';
import cyberCityImg from '../assets/images/fullstop_cyber_city_1788793780388.jpg';
import zenAndroidImg from '../assets/images/fullstop_zen_android_1788793802055.jpg';

interface ImageStudioViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const STYLES = [
  { id: 'Photorealistic', name: 'Photorealistic', desc: '8K raytraced physical lighting' },
  { id: 'Cyberpunk', name: 'Cyberpunk Obsidian', desc: 'High-contrast neon violet atmospheric' },
  { id: 'Cinematic Noir', name: 'Cinematic Noir', desc: 'Moody anamorphic lens with depth' },
  { id: 'Anime Neo', name: 'Anime Neo', desc: 'Sleek cel-shaded cyberpunk animation' },
  { id: '3D Octane', name: '3D Octane Render', desc: 'Volumetric glass & iridescent shaders' },
];

const ASPECT_RATIOS = [
  { id: '1:1', label: '1:1 Square', width: 'w-10 h-10' },
  { id: '16:9', label: '16:9 Cinema', width: 'w-12 h-7' },
  { id: '9:16', label: '9:16 Story', width: 'w-6 h-11' },
  { id: '4:3', label: '4:3 Classic', width: 'w-10 h-8' },
];

const PROMPT_PRESETS = [
  'Futuristic neural quantum core with glowing violet filaments and dark obsidian casing',
  'Cyberpunk megalopolis street bathed in rain reflections and neon signage at midnight',
  'Iridescent humanoid AI meditating floating above a calm obsidian reflection pool',
  'Hyper-detailed cybernetic falcon perched on a glass skyscraper ledge, 8k render',
];

const SAMPLE_GALLERY: GeneratedImageItem[] = [
  {
    id: 'sample-1',
    prompt: 'Futuristic neural core with glowing neon purple circuits, dark obsidian aesthetic, volumetric lighting, high tech AI supercomputer',
    style: 'Cyberpunk',
    aspectRatio: '16:9',
    imageUrl: neuralCoreImg,
    timestamp: '10:42 AM',
  },
  {
    id: 'sample-2',
    prompt: 'Cinematic futuristic cyberpunk city skyline at twilight with flying aerocars, glowing violet and cyan neon signage',
    style: 'Photorealistic',
    aspectRatio: '16:9',
    imageUrl: cyberCityImg,
    timestamp: '11:15 AM',
  },
  {
    id: 'sample-3',
    prompt: 'Sleek cybernetic humanoid android in calm meditation pose, iridescent obsidian chrome materials, subtle purple glow',
    style: '3D Octane',
    aspectRatio: '1:1',
    imageUrl: zenAndroidImg,
    timestamp: '11:40 AM',
  },
];

export const ImageStudioView: React.FC<ImageStudioViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt = '',
}) => {
  const [prompt, setPrompt] = useState(initialPrompt);
  const [selectedStyle, setSelectedStyle] = useState('Cyberpunk');
  const [selectedRatio, setSelectedRatio] = useState('16:9');
  const [selectedModel, setSelectedModel] = useState('Fullstop Vision XL');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState<string>('');
  const [gallery, setGallery] = useState<GeneratedImageItem[]>(SAMPLE_GALLERY);
  const [previewItem, setPreviewItem] = useState<GeneratedImageItem | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim() || isGenerating) return;
    setErrorMessage(null);

    const allowed = onIncrementUsage();
    if (!allowed) {
      onOpenUpgrade();
      return;
    }

    setIsGenerating(true);
    setGenerationStep('Engaging neural latent model...');

    try {
      setTimeout(() => setGenerationStep('Synthesizing diffuse composition & raytracing...'), 800);

      const res = await fetch('/api/image-generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style: selectedStyle,
          aspectRatio: selectedRatio,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to synthesize image');

      const newItem: GeneratedImageItem = {
        id: data.id || 'img-' + Date.now(),
        prompt: prompt.trim(),
        enhancedPrompt: data.enhancedPrompt,
        style: selectedStyle,
        aspectRatio: selectedRatio,
        imageUrl: data.imageUrl,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setGallery((prev) => [newItem, ...prev]);
    } catch (err: any) {
      console.error(err);
      setErrorMessage(err?.message || 'Generation error. Please try again.');
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
    }
  };

  const handleCopyPrompt = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownload = async (item: GeneratedImageItem) => {
    setDownloadingId(item.id);
    try {
      const response = await fetch(item.imageUrl);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `fullstop-ai-${item.id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (e) {
      // Fallback direct link
      const link = document.createElement('a');
      link.href = item.imageUrl;
      link.target = '_blank';
      link.download = `fullstop-ai-${item.id}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } finally {
      setDownloadingId(null);
    }
  };

  return (
    <div id="image-studio-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Studio Header & Prompt Panel */}
      <div className="rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/85 p-6 sm:p-8 border border-white/10 relative overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff]">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-mono font-semibold tracking-wider text-[#cfbcff] uppercase">
                NEURAL CANVAS // GEN-3
              </span>
              <h2 className="text-xl font-bold font-sora text-white">Visual Synthesis Studio</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="bg-[#14111d] text-xs font-mono text-zinc-300 border border-white/10 rounded-xl px-3 py-1.5 outline-none"
            >
              <option value="Fullstop Vision XL">Fullstop Vision XL (Ultra)</option>
              <option value="Flux Neo 2.0">Flux Neo 2.0 (Fast)</option>
              <option value="Gemini Multimodal Canvas">Gemini Multimodal Canvas</option>
            </select>
          </div>
        </div>

        {/* Prompt Input Box */}
        <div className="space-y-4">
          <div className="relative rounded-2xl bg-[#14111d] p-3 border border-white/15 focus-within:border-[#cfbcff]/60 transition-colors">
            <textarea
              id="image-prompt-input"
              rows={3}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe your scene in detail... (e.g. A hyper-realistic cyberpunk research laboratory bathed in deep purple volumetric lasers, cinematic reflections)"
              className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none resize-none font-sans"
            />

            <div className="flex items-center justify-between pt-2 border-t border-white/5">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setPrompt(
                      'Cinematic futuristic obsidian metropolis at twilight, bioluminescent purple skyscrapers, anamorphic light flares, 8k resolution raytracing'
                    )
                  }
                  className="text-[11px] font-mono text-zinc-400 hover:text-[#cfbcff] flex items-center gap-1 transition-colors"
                >
                  <Wand2 className="w-3 h-3" />
                  <span>Insert Preset</span>
                </button>
              </div>

              <div className="text-[11px] font-mono text-zinc-400">
                <span>{prompt.length}/500 chars</span>
              </div>
            </div>
          </div>

          {/* Prompt Inspiration Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <span className="text-[10px] font-mono text-zinc-500 uppercase flex items-center gap-1 flex-shrink-0">
              <Lightbulb className="w-3 h-3 text-amber-400" />
              Ideas:
            </span>
            {PROMPT_PRESETS.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPrompt(preset)}
                className="text-[11px] font-sans px-2.5 py-1 rounded-lg bg-white/[0.03] hover:bg-[#cfbcff]/15 text-zinc-400 hover:text-[#cfbcff] border border-white/5 hover:border-[#cfbcff]/30 transition-all whitespace-nowrap flex-shrink-0"
              >
                {preset.split(' ').slice(0, 4).join(' ')}...
              </button>
            ))}
          </div>

          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-400 flex-shrink-0" />
                <span>{errorMessage}</span>
              </div>
              <button
                onClick={handleGenerate}
                className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-medium border border-rose-500/40 transition-colors"
              >
                Retry
              </button>
            </div>
          )}

          {/* Controls: Styles & Aspect Ratios */}
          <div className="grid sm:grid-cols-2 gap-4 pt-1">
            {/* Style Selector */}
            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-2">
                Visual Aesthetic Style
              </label>
              <div className="flex flex-wrap gap-2">
                {STYLES.map((style) => (
                  <button
                    key={style.id}
                    onClick={() => setSelectedStyle(style.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                      selectedStyle === style.id
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/50 shadow-[0_0_12px_rgba(207,188,255,0.15)]'
                        : 'bg-white/[0.03] text-zinc-400 hover:text-white border border-white/10 hover:border-white/20'
                    }`}
                  >
                    {style.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio */}
            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-2">
                Aspect Ratio
              </label>
              <div className="flex flex-wrap gap-2">
                {ASPECT_RATIOS.map((ratio) => (
                  <button
                    key={ratio.id}
                    onClick={() => setSelectedRatio(ratio.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-mono transition-all flex items-center gap-1.5 ${
                      selectedRatio === ratio.id
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/50 shadow-[0_0_12px_rgba(207,188,255,0.15)]'
                        : 'bg-white/[0.03] text-zinc-400 hover:text-white border border-white/10'
                    }`}
                  >
                    <span>{ratio.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Generate Button */}
          <div className="pt-2 flex items-center justify-between gap-4">
            <div className="text-xs font-mono text-zinc-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Cost: 1 Neural Credit ({dailyLimit - dailyUsage} remaining)</span>
            </div>

            <button
              id="image-generate-btn"
              onClick={handleGenerate}
              disabled={!prompt.trim() || isGenerating}
              className={`py-3 px-8 rounded-xl font-sora font-semibold text-sm flex items-center gap-2 transition-all ${
                !prompt.trim() || isGenerating
                  ? 'bg-white/5 text-zinc-500 cursor-not-allowed border border-white/5'
                  : 'bg-gradient-to-r from-[#cfbcff] via-[#b69df8] to-[#9a7dec] text-[#1c0f38] hover:shadow-[0_0_25px_rgba(207,188,255,0.45)] glow-button cursor-pointer'
              }`}
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Artwork</span>
                </>
              )}
            </button>
          </div>

          {/* Live Generation Progress Banner */}
          {isGenerating && (
            <div className="p-4 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 text-xs text-[#cfbcff] flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-[#cfbcff] animate-ping" />
              <span className="font-mono">{generationStep}</span>
            </div>
          )}
        </div>
      </div>

      {/* Generated Creations Gallery */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-[#cfbcff]" />
            <h3 className="text-lg font-bold font-sora text-white">Neural Creations & Gallery</h3>
          </div>
          <span className="text-xs font-mono text-zinc-400">{gallery.length} renders</span>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {gallery.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 overflow-hidden group hover:border-[#cfbcff]/40 transition-all duration-300 flex flex-col"
            >
              {/* Image Preview Container */}
              <div className="relative aspect-video bg-black/40 overflow-hidden cursor-pointer" onClick={() => setPreviewItem(item)}>
                <img
                  src={item.imageUrl}
                  alt={item.prompt}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-3">
                  <span className="text-[10px] font-mono text-white px-2 py-0.5 rounded bg-black/60 border border-white/20">
                    {item.style} • {item.aspectRatio}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setPreviewItem(item);
                      }}
                      className="p-1.5 rounded-lg bg-black/60 text-white hover:bg-white/20 transition-colors"
                      title="Enlarge"
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownload(item);
                      }}
                      className="p-1.5 rounded-lg bg-black/60 text-white hover:bg-white/20 transition-colors"
                      title="Download"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Card Meta & Prompt */}
              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed font-sans">
                  "{item.prompt}"
                </p>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-zinc-400">
                  <span>{item.timestamp}</span>
                  <button
                    onClick={() => handleCopyPrompt(item.prompt, item.id)}
                    className="flex items-center gap-1 hover:text-[#cfbcff] transition-colors"
                  >
                    {copiedId === item.id ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span className="text-emerald-400">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Prompt</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal */}
      {previewItem && (
        <div
          onClick={() => setPreviewItem(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/90 backdrop-blur-xl"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl w-full max-h-[90vh] glass-panel bg-[#0e0c14] border border-white/15 rounded-3xl overflow-hidden shadow-2xl flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-[#cfbcff] uppercase">
                  {previewItem.style} • {previewItem.aspectRatio}
                </span>
              </div>
              <button
                onClick={() => setPreviewItem(null)}
                className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 bg-black flex items-center justify-center p-4 overflow-hidden">
              <img
                src={previewItem.imageUrl}
                alt={previewItem.prompt}
                referrerPolicy="no-referrer"
                className="max-h-[65vh] w-auto object-contain rounded-xl"
              />
            </div>

            <div className="p-5 border-t border-white/10 bg-[#0e0c14] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <p className="text-xs text-zinc-300 font-sans leading-relaxed">
                  "{previewItem.prompt}"
                </p>
                {previewItem.enhancedPrompt && (
                  <p className="text-[11px] text-[#cfbcff] font-mono">
                    Enhanced: {previewItem.enhancedPrompt}
                  </p>
                )}
              </div>
              <button
                onClick={() => handleDownload(previewItem)}
                className="py-2 px-4 rounded-xl bg-[#cfbcff]/20 hover:bg-[#cfbcff]/30 text-[#cfbcff] border border-[#cfbcff]/40 text-xs font-sora font-semibold flex items-center gap-1.5 transition-colors flex-shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>Download Artwork</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
