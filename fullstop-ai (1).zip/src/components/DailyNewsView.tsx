import React, { useState } from 'react';
import { DailyNewsItem, DailyNewsBriefing, NewsCategory, NavigationTab } from '../types';
import { SAMPLE_DAILY_NEWS, INITIAL_DAILY_BRIEFING } from '../data/dailyNewsData';
import {
  Newspaper,
  Sparkles,
  Search,
  Bookmark,
  BookmarkCheck,
  ArrowUpRight,
  TrendingUp,
  Cpu,
  Clock,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  RotateCcw,
  Zap,
  Bot,
  MessageSquare,
  Flame,
  CheckCircle2,
  Share2,
} from 'lucide-react';

interface DailyNewsViewProps {
  onSelectTab: (tab: NavigationTab) => void;
  onLaunchPrompt: (tab: NavigationTab, prompt: string) => void;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
}

const CATEGORIES: NewsCategory[] = [
  'All',
  'Artificial Intelligence',
  'Robotics & Automation',
  'Quantum & Silicon',
  'Breakthroughs',
  'Tech Policy & Ethics',
];

export const DailyNewsView: React.FC<DailyNewsViewProps> = ({
  onSelectTab,
  onLaunchPrompt,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
}) => {
  const [newsList, setNewsList] = useState<DailyNewsItem[]>(SAMPLE_DAILY_NEWS);
  const [briefing, setBriefing] = useState<DailyNewsBriefing>(INITIAL_DAILY_BRIEFING);
  const [selectedCategory, setSelectedCategory] = useState<NewsCategory>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkedOnly, setBookmarkedOnly] = useState(false);
  const [expandedStoryId, setExpandedStoryId] = useState<string | null>('news-1');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [briefingNotice, setBriefingNotice] = useState<string | null>(null);

  // Toggle bookmark for an item
  const handleToggleBookmark = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setNewsList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, bookmarked: !item.bookmarked } : item))
    );
  };

  // Ask AI about this story in Chat
  const handleAskAI = (story: DailyNewsItem, e: React.MouseEvent) => {
    e.stopPropagation();
    const prompt = `Please provide an in-depth strategic analysis and technological implications of this news report:\n\nTitle: "${story.title}"\nSource: ${story.source}\nSummary: ${story.summary}\nKey points:\n${story.keyPoints.map((p) => `- ${p}`).join('\n')}\n\nWhat are the 3 major commercial and engineering consequences over the next 18 months?`;
    onLaunchPrompt('chat', prompt);
  };

  // Generate / Refresh Live AI Briefing using server Gemini endpoint
  const handleRefreshBriefing = async () => {
    if (isRefreshing) return;
    const allowed = onIncrementUsage();
    if (!allowed) {
      onOpenUpgrade();
      return;
    }

    setIsRefreshing(true);
    setBriefingNotice(null);

    try {
      const res = await fetch('/api/news/daily', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ category: selectedCategory }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.briefing) {
          setBriefing(data.briefing);
        }
        if (data.stories && Array.isArray(data.stories) && data.stories.length > 0) {
          setNewsList(data.stories);
        }
        setBriefingNotice('Intelligence briefing successfully updated with Gemini live synthesis.');
      } else {
        // Fallback update timestamp
        setBriefing((prev) => ({
          ...prev,
          date: new Date().toLocaleDateString('en-US', {
            weekday: 'long',
            month: 'long',
            day: 'numeric',
            year: 'numeric',
          }) + ' (Live Updated)',
        }));
        setBriefingNotice('Briefing synchronized with latest intelligence pulse.');
      }
    } catch (err) {
      console.warn('News refresh network notice, using local cache:', err);
      setBriefingNotice('Intelligence cache refreshed with current local cycle.');
    } finally {
      setIsRefreshing(false);
      setTimeout(() => setBriefingNotice(null), 4000);
    }
  };

  // Filtered stories
  const filteredStories = newsList.filter((story) => {
    const matchesCategory = selectedCategory === 'All' || story.category === selectedCategory;
    const matchesSearch =
      story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      story.source.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesBookmark = !bookmarkedOnly || story.bookmarked;
    return matchesCategory && matchesSearch && matchesBookmark;
  });

  return (
    <div id="daily-news-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Studio Header */}
      <div className="rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/85 p-6 sm:p-8 border border-white/10 relative overflow-hidden shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff] shadow-[0_0_20px_rgba(207,188,255,0.25)]">
              <Newspaper className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono font-semibold tracking-wider text-[#cfbcff] uppercase">
                  DAILY INTELLIGENCE PULSE // NEXUS NEWS
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>
              <h1 className="text-xl sm:text-2xl font-bold font-sora text-white">
                Daily Update News & Strategic Tech Radar
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <span className="text-xs font-mono text-zinc-400 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 hidden sm:inline-block">
              {briefing.date}
            </span>

            <button
              id="refresh-briefing-btn"
              onClick={handleRefreshBriefing}
              disabled={isRefreshing}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-sora font-semibold text-[#1c0f38] bg-gradient-to-r from-[#cfbcff] to-[#9a7dec] hover:shadow-[0_0_20px_rgba(207,188,255,0.35)] transition-all cursor-pointer disabled:opacity-60"
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'Synthesizing...' : 'Synthesize Live Briefing'}</span>
            </button>
          </div>
        </div>

        {/* Live Status Notice */}
        {briefingNotice && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>{briefingNotice}</span>
          </div>
        )}

        {/* AI Daily Executive Summary Card */}
        <div className="relative rounded-2xl bg-gradient-to-br from-[#19132b]/90 via-[#120e20] to-[#09080e] p-5 sm:p-6 border border-[#cfbcff]/20 overflow-hidden shadow-xl">
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#6750a4]/15 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-mono uppercase font-bold text-[#cfbcff] tracking-wider">
                  TODAY'S AI EXECUTIVE BRIEFING
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-mono">
                <span className="text-zinc-400">Market Stance:</span>
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[11px] font-semibold">
                  {briefing.sentiment}
                </span>
              </div>
            </div>

            <div>
              <h3 className="text-base sm:text-lg font-bold font-sora text-white mb-2 leading-snug">
                "{briefing.headline}"
              </h3>
              <p className="text-xs sm:text-sm text-zinc-300 font-sans leading-relaxed">
                {briefing.executiveSummary}
              </p>
            </div>

            {/* Key Trends Pills */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-mono uppercase tracking-widest text-zinc-500 block">
                Primary Vector Shifts Today
              </span>
              <div className="grid sm:grid-cols-3 gap-2">
                {briefing.keyTrends.map((trend, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-white/[0.03] border border-white/5 text-[11px] text-zinc-300 font-sans flex items-start gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-[#cfbcff] mt-1.5 flex-shrink-0" />
                    <span>{trend}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl font-mono text-xs whitespace-nowrap transition-all ${
                  selectedCategory === cat
                    ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/50 font-semibold'
                    : 'bg-white/[0.03] text-zinc-400 hover:text-white border border-white/5 hover:border-white/20'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Search & Bookmarks */}
          <div className="flex items-center gap-2">
            <div className="relative rounded-xl bg-[#14111d] px-3 py-1.5 border border-white/10 focus-within:border-[#cfbcff]/50 flex items-center gap-2 min-w-[220px]">
              <Search className="w-3.5 h-3.5 text-zinc-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search daily headlines..."
                className="w-full bg-transparent text-xs text-white placeholder-zinc-500 outline-none font-sans"
              />
            </div>

            <button
              onClick={() => setBookmarkedOnly(!bookmarkedOnly)}
              className={`p-2 rounded-xl border text-xs font-mono flex items-center gap-1.5 transition-all ${
                bookmarkedOnly
                  ? 'bg-[#cfbcff]/20 text-[#cfbcff] border-[#cfbcff]/50'
                  : 'bg-white/[0.03] text-zinc-400 hover:text-white border-white/10'
              }`}
              title="Filter Bookmarked"
            >
              <Bookmark className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Saved</span>
            </button>
          </div>
        </div>
      </div>

      {/* Daily News Feed */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-xs font-mono text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Showing {filteredStories.length} updates for today</span>
          </span>
          <span className="text-[11px] font-mono text-zinc-500">Curated from 40+ Research Labs</span>
        </div>

        {filteredStories.length === 0 ? (
          <div className="rounded-2xl glass-panel bg-[#0e0c14]/70 border border-white/10 p-12 text-center">
            <Newspaper className="w-8 h-8 text-zinc-500 mx-auto mb-3" />
            <p className="text-zinc-400 text-sm font-sans mb-2">No news found matching your filter.</p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
                setBookmarkedOnly(false);
              }}
              className="text-xs text-[#cfbcff] hover:underline font-mono"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredStories.map((story) => {
              const isExpanded = expandedStoryId === story.id;
              return (
                <div
                  key={story.id}
                  id={`daily-news-item-${story.id}`}
                  onClick={() => setExpandedStoryId(isExpanded ? null : story.id)}
                  className={`rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 border transition-all cursor-pointer overflow-hidden p-5 sm:p-6 ${
                    isExpanded
                      ? 'border-[#cfbcff]/40 shadow-[0_0_25px_rgba(207,188,255,0.12)]'
                      : 'border-white/10 hover:border-white/20'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row gap-5">
                    {/* Optional Image Preview */}
                    {story.imageUrl && (
                      <div className="relative w-full sm:w-44 h-32 rounded-xl overflow-hidden bg-zinc-900 flex-shrink-0 border border-white/10">
                        <img
                          src={story.imageUrl}
                          alt={story.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[10px] font-mono text-white border border-white/10">
                          {story.category}
                        </div>
                      </div>
                    )}

                    {/* Main Story Content */}
                    <div className="flex-1 min-w-0 space-y-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-[11px] font-mono text-[#cfbcff] bg-[#cfbcff]/10 px-2 py-0.5 rounded border border-[#cfbcff]/20">
                            {story.source}
                          </span>
                          <span className="text-[10px] font-mono text-zinc-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {story.publishedAt}
                          </span>
                          <span className="text-[10px] font-mono text-zinc-500">•</span>
                          <span className="text-[10px] font-mono text-zinc-500">{story.readTime}</span>
                        </div>

                        <div className="flex items-center gap-2 flex-shrink-0">
                          {story.impactScore && (
                            <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                              Impact: {story.impactScore}/100
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={(e) => handleToggleBookmark(story.id, e)}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              story.bookmarked
                                ? 'bg-[#cfbcff]/20 text-[#cfbcff] border-[#cfbcff]/40'
                                : 'text-zinc-500 hover:text-white border-white/10'
                            }`}
                            title="Save for Later"
                          >
                            {story.bookmarked ? (
                              <BookmarkCheck className="w-4 h-4" />
                            ) : (
                              <Bookmark className="w-4 h-4" />
                            )}
                          </button>
                        </div>
                      </div>

                      <h2 className="text-base sm:text-lg font-bold font-sora text-white leading-snug hover:text-[#cfbcff] transition-colors">
                        {story.title}
                      </h2>

                      <p className="text-xs sm:text-sm text-zinc-300 font-sans leading-relaxed">
                        {story.summary}
                      </p>

                      {/* Expandable Key Points and AI Takeaway */}
                      {isExpanded && (
                        <div className="mt-4 pt-4 border-t border-white/10 space-y-4 animate-in fade-in duration-200">
                          {/* Key Points */}
                          <div className="space-y-1.5">
                            <span className="text-[10px] font-mono uppercase tracking-widest text-[#cfbcff] block">
                              Key Fact Breakdown
                            </span>
                            <ul className="space-y-1.5 pl-1">
                              {story.keyPoints.map((pt, i) => (
                                <li key={i} className="text-xs text-zinc-300 flex items-start gap-2">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                                  <span>{pt}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                          {/* AI Strategic Takeaway */}
                          {story.aiTakeaway && (
                            <div className="p-3.5 rounded-xl bg-gradient-to-r from-[#6750a4]/20 to-transparent border border-[#cfbcff]/20">
                              <div className="flex items-center gap-1.5 mb-1 text-[11px] font-mono text-[#cfbcff] font-semibold uppercase">
                                <Bot className="w-3.5 h-3.5" />
                                <span>Nexus Strategic Takeaway</span>
                              </div>
                              <p className="text-xs text-zinc-200 leading-relaxed font-sans">
                                {story.aiTakeaway}
                              </p>
                            </div>
                          )}

                          {/* Action Buttons */}
                          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                            <button
                              type="button"
                              onClick={(e) => handleAskAI(story, e)}
                              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/30 text-xs font-sora font-semibold flex items-center gap-1.5 transition-all"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>Ask Fullstop AI About This Report</span>
                            </button>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                const prompt = `Pose a critical debate question to the AI Council regarding this technology breakthrough:\n"${story.title}"\nKey context: ${story.summary}\nHow does it impact developers and market competition?`;
                                onLaunchPrompt('ai-council', prompt);
                              }}
                              className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 border border-white/10 text-xs font-sora flex items-center gap-1.5 transition-all"
                            >
                              <span>Debate in AI Council</span>
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Expand / Collapse Indicator */}
                      <div className="flex items-center justify-between pt-1 text-[11px] font-mono text-zinc-500">
                        <span>{isExpanded ? 'Click to minimize' : 'Click to view key takeaways & AI analysis'}</span>
                        <div className="flex items-center gap-1 text-[#cfbcff]">
                          <span>{isExpanded ? 'Collapse' : 'Expand Details'}</span>
                          {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
