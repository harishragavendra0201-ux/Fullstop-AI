import React, { useState } from 'react';
import { CouncilResult, UserProfile } from '../types';
import {
  Users2,
  Database,
  Lightbulb,
  ShieldAlert,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  RotateCcw,
  Zap,
  Layers,
  Award,
  Terminal,
  AlertCircle,
} from 'lucide-react';

interface AICouncilViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

function cleanErrorMessage(raw: string): string {
  if (!raw) return 'Council session encountered high network traffic. Please try again.';
  let cleaned = raw.replace(/^Error:\s*/i, '').trim();
  try {
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed?.error?.message) {
        return parsed.error.message;
      }
    }
  } catch {
    // Ignore JSON parsing issues
  }
  return cleaned;
}

const SAMPLE_DILEMMAS = [
  'How should an AI software company build technical defensibility in 2026 against commoditized LLMs?',
  'Should a high-growth tech startup mandate strict in-office attendance or adopt asynchronous sovereign workflows?',
  'Evaluate adopting local edge AI inference vs. centralized cloud clusters for enterprise privacy.',
];

export const AICouncilView: React.FC<AICouncilViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt = '',
}) => {
  const [question, setQuestion] = useState(initialPrompt);
  const [isDeliberating, setIsDeliberating] = useState(false);
  const [activeStage, setActiveStage] = useState<string>('');
  const [councilError, setCouncilError] = useState<string | null>(null);
  const [result, setResult] = useState<CouncilResult | null>(() => {
    return {
      researcher: {
        title: 'Researcher AI',
        subtitle: 'Fact & Data Synth',
        analysis:
          'Analysis of 45 enterprise deployments reveals that fine-tuned SLMs (Small Language Models) running locally reduce cloud compute overhead by 68% while preserving strict on-prem compliance.',
        tags: ['Empirical Telemetry', 'Sub-10ms Latency', 'Cost Reductions'],
      },
      creative: {
        title: 'Creative AI',
        subtitle: 'Alt Solutions',
        analysis:
          'Invert the model: Deploy federated learning swarms across user devices. Turn idle user GPU hardware into a decentralized neural compute mesh with tokenized incentives.',
        bulletPoints: [
          'Zero centralized cloud infrastructure costs',
          'Autonomous peer-to-peer verification protocols',
          'Viral developer ecosystem growth',
        ],
      },
      critic: {
        title: 'Critic AI',
        subtitle: 'Weakness ID',
        analysis:
          'Decentralized nodes introduce severe malicious poisoned weights risks and inconsistent uptime. Furthermore, hardware heterogeneity will cause catastrophic tail latency.',
        vulnerability: 'Critical security attack vector: Sybil model weight poisoning.',
      },
      consensus: {
        title: 'Final Fullstop Answer',
        summary:
          'A hybrid tiered paradigm: Centralize high-security model orchestrations on private cloud clusters while dispatching lightweight edge adapters with cryptographic zero-knowledge verification.',
        directives: [
          {
            phase: 'Phase 1 (Immediate)',
            action: 'Audit existing latency bottlenecks and benchmark on-prem inference engines.',
          },
          {
            phase: 'Phase 2 (Growth)',
            action: 'Implement zero-trust cryptographic attestations for edge inference nodes.',
          },
          {
            phase: 'Phase 3 (Maturity)',
            action: 'Deploy autonomous fallback routing to guarantee enterprise SLA consistency.',
          },
        ],
      },
    };
  });

  const handleConveneCouncil = async (overrideQuestion?: string) => {
    const q = (overrideQuestion || question).trim();
    if (!q || isDeliberating) return;

    const allowed = onIncrementUsage();
    if (!allowed) {
      onOpenUpgrade();
      return;
    }

    setIsDeliberating(true);
    setCouncilError(null);
    setActiveStage('Convening Council members & establishing reasoning telemetry...');

    try {
      setTimeout(() => setActiveStage('Synthesizing Researcher AI empirical datasets...'), 1000);
      setTimeout(() => setActiveStage('Generating Creative AI lateral solutions...'), 2200);
      setTimeout(() => setActiveStage('Critic AI stress-testing vulnerability vectors...'), 3500);

      const res = await fetch('/api/council', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: q }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Council failed to reach deliberation.');

      if (data.data) {
        setResult(data.data);
      }
    } catch (err: any) {
      console.error(err);
      const friendly = cleanErrorMessage(err?.message || 'Council failed to convene.');
      setCouncilError(friendly);
    } finally {
      setIsDeliberating(false);
      setActiveStage('');
    }
  };

  return (
    <div id="ai-council-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Council Arena Header */}
      <div className="rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/85 p-6 sm:p-8 border border-white/10 relative overflow-hidden shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff]">
              <Users2 className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-mono font-semibold tracking-wider text-[#cfbcff] uppercase">
                CONSENSUS PROTOCOL // MULTI-AGENT ARENA
              </span>
              <h2 className="text-xl font-bold font-sora text-white">Fullstop AI Council</h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-full text-[11px] font-mono bg-white/5 border border-white/10 text-zinc-300">
              Quorum: 3 Specialized Personas
            </span>
          </div>
        </div>

        {/* Input Question Area */}
        <div className="space-y-4">
          <div className="relative rounded-2xl bg-[#14111d] p-3 border border-white/15 focus-within:border-[#cfbcff]/60 transition-colors">
            <textarea
              id="council-question-input"
              rows={3}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Present a strategic dilemma, technical decision, or business thesis for multi-agent council deliberation..."
              className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none resize-none font-sans"
            />

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5 text-[11px] font-mono text-zinc-400">
              <span className="text-zinc-500">Sample dilemmas:</span>
              <div className="flex items-center gap-1.5 flex-wrap">
                {SAMPLE_DILEMMAS.map((sample, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setQuestion(sample);
                      handleConveneCouncil(sample);
                    }}
                    className="hover:text-[#cfbcff] transition-colors truncate max-w-xs text-left"
                  >
                    "{sample.slice(0, 32)}..."
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Convene Button */}
          <div className="pt-1 flex items-center justify-between gap-4">
            <div className="text-xs font-mono text-zinc-400 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>Cost: 1 Neural Credit ({dailyLimit - dailyUsage} remaining)</span>
            </div>

            <button
              id="convene-council-btn"
              onClick={() => handleConveneCouncil()}
              disabled={!question.trim() || isDeliberating}
              className={`py-3 px-8 rounded-xl font-sora font-semibold text-sm flex items-center gap-2 transition-all ${
                !question.trim() || isDeliberating
                  ? 'bg-white/5 text-zinc-500 cursor-not-allowed border border-white/5'
                  : 'bg-gradient-to-r from-[#cfbcff] via-[#b69df8] to-[#9a7dec] text-[#1c0f38] hover:shadow-[0_0_25px_rgba(207,188,255,0.45)] glow-button cursor-pointer'
              }`}
            >
              {isDeliberating ? (
                <>
                  <RotateCcw className="w-4 h-4 animate-spin" />
                  <span>Deliberating Perspectives...</span>
                </>
              ) : (
                <>
                  <Users2 className="w-4 h-4" />
                  <span>Convene AI Council</span>
                </>
              )}
            </button>
          </div>

          {/* Error Banner */}
          {councilError && (
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 flex flex-wrap items-center justify-between gap-3 text-xs text-rose-300">
              <div className="flex items-center gap-2.5">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                <span>{councilError}</span>
              </div>
              <button
                type="button"
                onClick={() => handleConveneCouncil()}
                className="flex items-center gap-1.5 font-mono text-xs px-3 py-1.5 rounded-xl bg-rose-500/25 hover:bg-rose-500/40 text-white border border-rose-500/50 transition-colors shadow-sm cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry Deliberation</span>
              </button>
            </div>
          )}

          {/* Live Deliberation Stage */}
          {isDeliberating && (
            <div className="p-4 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 text-xs text-[#cfbcff] flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-[#cfbcff] animate-ping" />
              <span className="font-mono">{activeStage}</span>
            </div>
          )}
        </div>
      </div>

      {/* Council Members Deliberation Grid */}
      {result && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold font-sora text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#cfbcff]" />
              <span>Multi-Agent Perspectives</span>
            </h3>
            <span className="text-xs font-mono text-zinc-400">DELIBERATION LOG</span>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* 1. Researcher AI */}
            <div className="rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 p-6 flex flex-col justify-between hover:border-cyan-400/40 transition-all">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                    <Database className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold font-sora text-white">{result.researcher.title}</h4>
                    <span className="text-[10px] font-mono text-cyan-300 uppercase">
                      {result.researcher.subtitle}
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-sans mb-4">
                  {result.researcher.analysis}
                </p>
              </div>

              {result.researcher.tags && (
                <div className="pt-3 border-t border-white/5 flex flex-wrap gap-1.5">
                  {result.researcher.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-500/20"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* 2. Creative AI */}
            <div className="rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 p-6 flex flex-col justify-between hover:border-[#cfbcff]/40 transition-all">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff]">
                    <Lightbulb className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold font-sora text-white">{result.creative.title}</h4>
                    <span className="text-[10px] font-mono text-[#cfbcff] uppercase">
                      {result.creative.subtitle}
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-sans mb-4">
                  {result.creative.analysis}
                </p>

                {result.creative.bulletPoints && (
                  <ul className="space-y-1.5 mb-4">
                    {result.creative.bulletPoints.map((bp, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs text-zinc-300">
                        <span className="text-[#cfbcff] mt-0.5">•</span>
                        <span>{bp}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>

              <div className="pt-3 border-t border-white/5">
                <span className="text-[10px] font-mono text-[#cfbcff]">Model: Lateral Synthesis</span>
              </div>
            </div>

            {/* 3. Critic AI */}
            <div className="rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 p-6 flex flex-col justify-between hover:border-rose-500/40 transition-all">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/30 flex items-center justify-center text-rose-400">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold font-sora text-white">{result.critic.title}</h4>
                    <span className="text-[10px] font-mono text-rose-300 uppercase">
                      {result.critic.subtitle}
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed font-sans mb-4">
                  {result.critic.analysis}
                </p>

                {result.critic.vulnerability && (
                  <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-200 mb-2">
                    <span className="font-semibold block mb-0.5">Vulnerability Flagged:</span>
                    <span className="text-[11px]">{result.critic.vulnerability}</span>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-white/5">
                <span className="text-[10px] font-mono text-rose-400">Model: Stress-Test Protocol</span>
              </div>
            </div>
          </div>

          {/* Consensus Reached / Executive Synthesis */}
          <div className="rounded-3xl glass-panel glass-card-edge bg-gradient-to-b from-[#181326] to-[#0e0c14] border border-[#cfbcff]/30 p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-[#6750a4]/20 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] flex items-center justify-center text-[#1c0f38] shadow-[0_0_15px_rgba(207,188,255,0.4)]">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-semibold text-[#cfbcff] uppercase tracking-wider">
                    CONSENSUS REACHED
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    UNANIMOUS VERDICT
                  </span>
                </div>
                <h3 className="text-xl font-bold font-sora text-white">
                  {result.consensus.title}
                </h3>
              </div>
            </div>

            <p className="text-sm text-zinc-200 leading-relaxed font-sans mb-6 max-w-4xl">
              {result.consensus.summary}
            </p>

            <div className="space-y-3">
              <span className="text-xs font-mono uppercase text-zinc-400 tracking-wider">
                Execution Directives & Milestones:
              </span>
              <div className="grid md:grid-cols-3 gap-3">
                {result.consensus.directives.map((dir, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-white/[0.03] border border-white/5 space-y-1.5"
                  >
                    <div className="flex items-center gap-2 text-xs font-mono text-[#cfbcff]">
                      <CheckCircle2 className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span className="font-semibold">{dir.phase}</span>
                    </div>
                    <p className="text-xs text-zinc-300 leading-relaxed">{dir.action}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
