import React from 'react';
import { FullstopLogo } from './FullstopLogo';
import { Sparkles, Check, X, Zap, Crown, Shield, RefreshCw } from 'lucide-react';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgradeToPro: () => void;
  onResetDailyLimit: () => void;
  dailyUsage: number;
  dailyLimit: number;
  isPro: boolean;
}

export const UpgradeModal: React.FC<UpgradeModalProps> = ({
  isOpen,
  onClose,
  onUpgradeToPro,
  onResetDailyLimit,
  dailyUsage,
  dailyLimit,
  isPro,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="upgrade-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto"
    >
      <div
        id="upgrade-card"
        className="relative w-full max-w-xl rounded-2xl glass-panel glass-card-edge bg-[#0e0c13]/95 p-6 sm:p-8 shadow-2xl border border-white/10 text-white my-8"
      >
        {/* Glow ambient highlight */}
        <div className="absolute -top-24 -left-24 w-60 h-60 bg-[#6750a4]/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-60 h-60 bg-[#cfbcff]/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="close-upgrade-modal-btn"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/5 transition-colors border border-transparent hover:border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <FullstopLogo size="lg" animated={true} />
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono tracking-widest text-[#cfbcff] uppercase font-semibold">
                TIER UPGRADE // FULLSTOP PRO
              </span>
              {isPro && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  ACTIVE
                </span>
              )}
            </div>
            <h2 className="text-2xl font-bold font-sora tracking-tight text-white">
              {dailyUsage >= dailyLimit && !isPro ? 'Daily Free Limit Reached' : 'Elevate to Fullstop Pro'}
            </h2>
          </div>
        </div>

        {/* Quota Status Notice */}
        <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Zap className="w-4 h-4 text-amber-400" />
            <div>
              <p className="text-xs text-zinc-300 font-medium">
                Today's Neural Usage: <span className="text-white font-mono">{dailyUsage} / {dailyLimit} requests</span>
              </p>
              <p className="text-[11px] text-zinc-400">
                {isPro
                  ? 'Your account has Unlimited Pro clearance.'
                  : dailyUsage >= dailyLimit
                  ? 'You have used all 20 free chat requests today.'
                  : `${dailyLimit - dailyUsage} free requests remaining today.`}
              </p>
            </div>
          </div>
          <button
            id="btn-reset-free-quota"
            onClick={onResetDailyLimit}
            title="Reset today's counter to 0 for demo/testing"
            className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-[#cfbcff] bg-white/5 hover:bg-white/10 px-2.5 py-1.5 rounded-lg border border-white/10 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset Limit</span>
          </button>
        </div>

        {/* Comparison or Perks */}
        <div className="space-y-3 mb-6">
          <div className="text-xs font-mono uppercase tracking-wider text-zinc-400">Included in Fullstop Pro:</div>

          <div className="grid sm:grid-cols-2 gap-2.5">
            {[
              { title: 'Unlimited AI Chat Queries', desc: 'No daily caps or throttling with Gemini 3.8 Flash' },
              { title: 'AI Council Deliberation', desc: 'Researcher, Creative, and Critic multi-agent synthesis' },
              { title: 'Image Studio Neural Canvas', desc: 'High-res generation with custom aspect ratios & styles' },
              { title: 'Video Lab Motion Rendering', desc: '1080p temporal generation with camera orbit controls' },
              { title: 'Sub-Second Latency', desc: 'Dedicated queue prioritization across all pipelines' },
              { title: 'Full Conversation History', desc: 'Export and revisit extensive reasoning sessions' },
            ].map((item, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-start gap-2.5"
              >
                <div className="mt-0.5 w-4 h-4 rounded-full bg-[#cfbcff]/20 text-[#cfbcff] flex items-center justify-center flex-shrink-0">
                  <Check className="w-2.5 h-2.5" />
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white">{item.title}</h4>
                  <p className="text-[11px] text-zinc-400 leading-tight mt-0.5">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Pricing & CTA */}
        <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-bold font-sora text-white">$29</span>
              <span className="text-xs text-zinc-400 font-mono">/ month</span>
            </div>
            <p className="text-[11px] text-zinc-400">Cancel or pause subscription at any time</p>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            {isPro ? (
              <button
                disabled
                className="w-full sm:w-auto py-3 px-6 rounded-xl font-sora font-semibold text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center gap-2 cursor-default"
              >
                <Crown className="w-4 h-4" />
                <span>Pro Membership Active</span>
              </button>
            ) : (
              <button
                id="btn-activate-pro-pass"
                onClick={() => {
                  onUpgradeToPro();
                  onClose();
                }}
                className="w-full sm:w-auto py-3 px-6 rounded-xl font-sora font-semibold text-xs bg-gradient-to-r from-[#cfbcff] via-[#b69df8] to-[#9a7dec] text-[#1c0f38] hover:shadow-[0_0_25px_rgba(207,188,255,0.45)] transition-all flex items-center justify-center gap-2 glow-button"
              >
                <Sparkles className="w-4 h-4" />
                <span>Activate Pro Membership</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
