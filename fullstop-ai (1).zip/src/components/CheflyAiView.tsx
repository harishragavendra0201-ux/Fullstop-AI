import React, { useState, useEffect, useRef } from 'react';
import { CheflyMode, CheflyRecipe, CheflyChatMessage, UserProfile } from '../types';
import {
  Utensils,
  Sparkles,
  Clock,
  Flame,
  ChefHat,
  Heart,
  Baby,
  RefreshCw,
  ShoppingBag,
  CheckCircle2,
  AlertCircle,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Send,
  MessageSquare,
  Copy,
  Check,
  Calendar,
  Layers,
  Sparkle,
  Bookmark,
  Share2,
  Soup,
  Apple,
  Salad,
  Carrot,
  Globe,
  Languages,
} from 'lucide-react';

export interface LanguageOption {
  code: string;
  name: string;
  flag: string;
  speechCode: string;
}

export const CHEFLY_LANGUAGES: LanguageOption[] = [
  { code: 'Auto-Detect', name: 'Auto-Detect (All Languages)', flag: '🌐', speechCode: 'en-US' },
  { code: 'English', name: 'English', flag: '🇬🇧', speechCode: 'en-US' },
  { code: 'Hindi', name: 'हिन्दी (Hindi)', flag: '🇮🇳', speechCode: 'hi-IN' },
  { code: 'Tamil', name: 'தமிழ் (Tamil)', flag: '🇮🇳', speechCode: 'ta-IN' },
  { code: 'Telugu', name: 'తెలుగు (Telugu)', flag: '🇮🇳', speechCode: 'te-IN' },
  { code: 'Spanish', name: 'Español (Spanish)', flag: '🇪🇸', speechCode: 'es-ES' },
  { code: 'French', name: 'Français (French)', flag: '🇫🇷', speechCode: 'fr-FR' },
  { code: 'Arabic', name: 'العربية (Arabic)', flag: '🇸🇦', speechCode: 'ar-SA' },
  { code: 'Bengali', name: 'বাংলা (Bengali)', flag: '🇮🇳', speechCode: 'bn-IN' },
  { code: 'Marathi', name: 'मराठी (Marathi)', flag: '🇮🇳', speechCode: 'mr-IN' },
  { code: 'Gujarati', name: 'ગુજરાતી (Gujarati)', flag: '🇮🇳', speechCode: 'gu-IN' },
  { code: 'Kannada', name: 'ಕನ್ನಡ (Kannada)', flag: '🇮🇳', speechCode: 'kn-IN' },
  { code: 'Malayalam', name: 'മലയാളം (Malayalam)', flag: '🇮🇳', speechCode: 'ml-IN' },
  { code: 'Punjabi', name: 'ਪੰਜਾਬੀ (Punjabi)', flag: '🇮🇳', speechCode: 'pa-IN' },
  { code: 'German', name: 'Deutsch (German)', flag: '🇩🇪', speechCode: 'de-DE' },
  { code: 'Italian', name: 'Italiano (Italian)', flag: '🇮🇹', speechCode: 'it-IT' },
  { code: 'Portuguese', name: 'Português (Portuguese)', flag: '🇵🇹', speechCode: 'pt-PT' },
  { code: 'Russian', name: 'Русский (Russian)', flag: '🇷🇺', speechCode: 'ru-RU' },
  { code: 'Japanese', name: '日本語 (Japanese)', flag: '🇯🇵', speechCode: 'ja-JP' },
  { code: 'Korean', name: '한국어 (Korean)', flag: '🇰🇷', speechCode: 'ko-KR' },
  { code: 'Chinese', name: '中文 (Chinese)', flag: '🇨🇳', speechCode: 'zh-CN' },
  { code: 'Turkish', name: 'Türkçe (Turkish)', flag: '🇹🇷', speechCode: 'tr-TR' },
  { code: 'Indonesian', name: 'Bahasa Indonesia', flag: '🇮🇩', speechCode: 'id-ID' },
];

interface CheflyAiViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const COMMON_PANTRY_CHIPS = [
  'Eggs',
  'Tomatoes',
  'Potatoes',
  'Onions',
  'Baby Spinach',
  'Leftover Rice',
  'Cheese',
  'Paneer / Tofu',
  'Chicken Breast',
  'Pasta',
  'Bread',
  'Lentils / Dal',
  'Yogurt / Curd',
  'Carrots',
  'Sweet Corn',
  'Bell Peppers',
];

const QUICK_KITCHEN_QUESTIONS = [
  'How do I fix a curry or soup that turned out too salty?',
  'What can I substitute for eggs in kid pancakes?',
  'Best hidden-veggie snacks for a fussy 3-year-old toddler?',
  'How to make soft, flaky rotis/chapatis that stay fresh in lunchboxes?',
  'Is it safe to freeze cooked lentils and rice for later?',
  'Quick 10-minute dinner when the kids are starving right now?',
];

export const CheflyAiView: React.FC<CheflyAiViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [activeMode, setActiveMode] = useState<CheflyMode>('fridge-magic');
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([
    'Eggs',
    'Baby Spinach',
    'Tomatoes',
    'Leftover Rice',
  ]);
  const [customIngredientInput, setCustomIngredientInput] = useState('');
  const [mealType, setMealType] = useState('Quick Dinner');
  const [familySize, setFamilySize] = useState('Family of 4 (2 adults, 2 kids)');
  const [dietary, setDietary] = useState('Kid-Friendly & Healthy');
  const [kidFriendly, setKidFriendly] = useState(true);
  const [timeLimit, setTimeLimit] = useState(25);
  const [customNotes, setCustomNotes] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<string>(() => {
    return localStorage.getItem('chefly_language') || 'Auto-Detect';
  });
  const [customLanguage, setCustomLanguage] = useState('');
  const [showCustomLanguageInput, setShowCustomLanguageInput] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [currentRecipe, setCurrentRecipe] = useState<CheflyRecipe | null>(null);
  const [checkedIngredients, setCheckedIngredients] = useState<Record<string, boolean>>({});
  const [checkedSteps, setCheckedSteps] = useState<Record<number, boolean>>({});
  const [checkedGroceries, setCheckedGroceries] = useState<Record<string, boolean>>({});
  const [copiedRecipe, setCopiedRecipe] = useState(false);

  // Active Timer state
  const [activeTimerSeconds, setActiveTimerSeconds] = useState<number | null>(null);
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerLabel, setTimerLabel] = useState<string>('Kitchen Timer');

  // Text-To-Speech state
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Kitchen Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<CheflyChatMessage[]>([
    {
      id: 'c-welcome',
      role: 'assistant',
      text: "Namaste & Hello Mama! I'm **AI Chefly AI**, your devoted kitchen helper. Whether you're staring into a half-empty fridge, planning tomorrow's school lunchbox, or need to rescue a salty soup in 2 minutes, I'm right here by your side. What are we cooking today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [isChatLoading, setIsChatLoading] = useState(false);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Timer Tick
  useEffect(() => {
    let interval: any = null;
    if (timerRunning && activeTimerSeconds !== null && activeTimerSeconds > 0) {
      interval = setInterval(() => {
        setActiveTimerSeconds((prev) => (prev !== null && prev > 0 ? prev - 1 : 0));
      }, 1000);
    } else if (activeTimerSeconds === 0 && timerRunning) {
      setTimerRunning(false);
      // Play soft audio alert if possible
      try {
        if ('speechSynthesis' in window) {
          const alertUtterance = new SpeechSynthesisUtterance(`${timerLabel} is done! Time to check the stove, Mama.`);
          window.speechSynthesis.speak(alertUtterance);
        }
      } catch (e) {}
    }
    return () => clearInterval(interval);
  }, [timerRunning, activeTimerSeconds, timerLabel]);

  // Initial prompt handling
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      handleGenerate(initialPrompt);
    } else {
      // Auto-load a signature mom recipe
      handleGenerate();
    }
  }, []);

  useEffect(() => {
    chatScrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  // Persist language preference
  useEffect(() => {
    localStorage.setItem('chefly_language', selectedLanguage);
  }, [selectedLanguage]);

  const toggleIngredientChip = (chip: string) => {
    setSelectedIngredients((prev) =>
      prev.includes(chip) ? prev.filter((c) => c !== chip) : [...prev, chip]
    );
  };

  const handleAddCustomIngredient = () => {
    const trimmed = customIngredientInput.trim();
    if (trimmed && !selectedIngredients.includes(trimmed)) {
      setSelectedIngredients((prev) => [...prev, trimmed]);
      setCustomIngredientInput('');
    }
  };

  const handleGenerate = async (overrideIngredients?: string) => {
    if (isLoading) return;
    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    setCheckedSteps({});
    setCheckedIngredients({});
    setCheckedGroceries({});

    const ingredientsString =
      overrideIngredients || selectedIngredients.join(', ') || 'Common family pantry items';

    const activeLanguage =
      selectedLanguage === 'custom'
        ? customLanguage.trim() || 'Any Language'
        : selectedLanguage;

    try {
      const res = await fetch('/api/chefly/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: activeMode,
          ingredients: ingredientsString,
          mealType,
          familySize,
          dietary,
          kidFriendly,
          timeLimitMinutes: timeLimit,
          customNotes,
          language: activeLanguage,
        }),
      });

      const data = await res.json();
      if (data.success && data.recipe) {
        setCurrentRecipe(data.recipe);
      } else {
        // Resilient fallback recipe if server or AI encounters temporary quota limits
        setCurrentRecipe({
          title: "Golden Skillet Comfort Frittata & Toast Stars",
          tagline: "A nourishing, 15-minute skillet miracle that turns simple eggs and veggies into a fluffy feast your family will adore!",
          prepTime: "5 mins",
          cookTime: "12 mins",
          totalTime: "17 mins",
          difficulty: "Easy",
          servings: familySize,
          estimatedCalories: "290 kcal per serving",
          healthBenefits: [
            "Complete bioavailable protein from eggs for growing kids",
            "Hidden greens boost natural iron and vitamins",
            "Sustained energy without sugar crashes"
          ],
          ingredients: [
            { name: "Eggs", amount: "4-6 large", isPantryCommon: true, substitute: "Silken tofu" },
            { name: "Fresh or Frozen Greens (Spinach/Peas)", amount: "1.5 cups", isPantryCommon: true, substitute: "Grated zucchini" },
            { name: "Cheese (Cheddar or Mozzarella)", amount: "1/2 cup shredded", isPantryCommon: true, substitute: "Nutritional yeast" },
            { name: "Olive Oil or Butter", amount: "1 tablespoon", isPantryCommon: true },
            { name: "Bread or Tortillas", amount: "4 slices / wraps", isPantryCommon: true }
          ],
          steps: [
            {
              step: 1,
              title: "Whisk the Golden Base",
              instruction: "Crack eggs into a bowl with a pinch of salt and black pepper. Whisk vigorously for 60 seconds until light and frothy.",
              timerMinutes: 2,
              momTip: "Let your child whisk the eggs—they'll feel like the head chef!"
            },
            {
              step: 2,
              title: "Quick Pan Sizzle",
              instruction: "Heat butter or oil in an 8-10 inch skillet over medium heat. Toss in greens and sauté for 90 seconds until wilted.",
              timerMinutes: 2,
              momTip: "Chop greens finely so picky eaters won't even notice them."
            },
            {
              step: 3,
              title: "Simmer and Set",
              instruction: "Pour the whisked eggs over the greens. Sprinkle shredded cheese on top, turn heat to low, and cover with a lid for 6-8 minutes.",
              timerMinutes: 7,
              momTip: "Covering the pan traps gentle steam, cooking the frittata evenly without browning the bottom."
            },
            {
              step: 4,
              title: "Plate and Cut Fun Shapes",
              instruction: "Slide frittata onto a board. Cut into bite-sized triangles or cookie-cutter star shapes. Serve with warm toast points!",
              timerMinutes: 2,
              momTip: "Serve with ketchup smiles or sweet fruit slices on the side."
            }
          ],
          momHacks: [
            "Wipe down your skillet with a paper towel while warm—clean-up takes 30 seconds!",
            "Pre-shred cheese in bulk on Sundays and keep in a ziplock bag for instant dinners.",
            "Cut sandwiches and frittatas with festive cookie cutters to instantly beat dinnertime resistance."
          ],
          kidFriendlyTwist: "Call them 'Golden Sunshine Clouds' and let the kids dip toast stars into warm tomato soup!",
          leftoverStorage: "Cools beautifully; wrap individual slices in parchment for tomorrow's lunchbox!",
          groceryAisleList: {
            produce: ["Baby spinach or greens", "Fresh garlic (optional)"],
            dairyOrPantry: ["Eggs", "Shredded cheese", "Bread loaf", "Butter"],
            spices: ["Black pepper", "Sea salt"]
          }
        });
      }
    } catch (err) {
      console.error('Chefly generation error:', err);
      // Ensure the mom never sees an empty screen
      setCurrentRecipe({
        title: "Golden Skillet Comfort Frittata & Toast Stars",
        tagline: "A nourishing, 15-minute skillet miracle that turns simple eggs and veggies into a fluffy feast your family will adore!",
        prepTime: "5 mins",
        cookTime: "12 mins",
        totalTime: "17 mins",
        difficulty: "Easy",
        servings: familySize,
        estimatedCalories: "290 kcal per serving",
        healthBenefits: [
          "Complete bioavailable protein from eggs for growing kids",
          "Hidden greens boost natural iron and vitamins",
          "Sustained energy without sugar crashes"
        ],
        ingredients: [
          { name: "Eggs", amount: "4-6 large", isPantryCommon: true, substitute: "Silken tofu" },
          { name: "Fresh or Frozen Greens (Spinach/Peas)", amount: "1.5 cups", isPantryCommon: true, substitute: "Grated zucchini" },
          { name: "Cheese (Cheddar or Mozzarella)", amount: "1/2 cup shredded", isPantryCommon: true, substitute: "Nutritional yeast" },
          { name: "Olive Oil or Butter", amount: "1 tablespoon", isPantryCommon: true },
          { name: "Bread or Tortillas", amount: "4 slices / wraps", isPantryCommon: true }
        ],
        steps: [
          {
            step: 1,
            title: "Whisk the Golden Base",
            instruction: "Crack eggs into a bowl with a pinch of salt and black pepper. Whisk vigorously for 60 seconds until light and frothy.",
            timerMinutes: 2,
            momTip: "Let your child whisk the eggs—they'll feel like the head chef!"
          },
          {
            step: 2,
            title: "Quick Pan Sizzle",
            instruction: "Heat butter or oil in an 8-10 inch skillet over medium heat. Toss in greens and sauté for 90 seconds until wilted.",
            timerMinutes: 2,
            momTip: "Chop greens finely so picky eaters won't even notice them."
          },
          {
            step: 3,
            title: "Simmer and Set",
            instruction: "Pour the whisked eggs over the greens. Sprinkle shredded cheese on top, turn heat to low, and cover with a lid for 6-8 minutes.",
            timerMinutes: 7,
            momTip: "Covering the pan traps gentle steam, cooking the frittata evenly without browning the bottom."
          },
          {
            step: 4,
            title: "Plate and Cut Fun Shapes",
            instruction: "Slide frittata onto a board. Cut into bite-sized triangles or cookie-cutter star shapes. Serve with warm toast points!",
            timerMinutes: 2,
            momTip: "Serve with ketchup smiles or sweet fruit slices on the side."
          }
        ],
        momHacks: [
          "Wipe down your skillet with a paper towel while warm—clean-up takes 30 seconds!",
          "Pre-shred cheese in bulk on Sundays and keep in a ziplock bag for instant dinners.",
          "Cut sandwiches and frittatas with festive cookie cutters to instantly beat dinnertime resistance."
        ],
        kidFriendlyTwist: "Call them 'Golden Sunshine Clouds' and let the kids dip toast stars into warm tomato soup!",
        leftoverStorage: "Cools beautifully; wrap individual slices in parchment for tomorrow's lunchbox!",
        groceryAisleList: {
          produce: ["Baby spinach or greens"],
          dairyOrPantry: ["Eggs", "Shredded cheese", "Bread loaf", "Butter"],
          spices: ["Black pepper", "Sea salt"]
        }
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleStartStepTimer = (minutes: number, stepTitle: string) => {
    setActiveTimerSeconds(minutes * 60);
    setTimerLabel(stepTitle || 'Step Timer');
    setTimerRunning(true);
  };

  const handleSpeakRecipe = () => {
    if (!('speechSynthesis' in window) || !currentRecipe) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    try {
      window.speechSynthesis.cancel();
      window.speechSynthesis.resume();

      const textToRead = `${currentRecipe.title}. ${currentRecipe.tagline}. Estimated cooking time: ${currentRecipe.totalTime}. Step 1: ${currentRecipe.steps[0]?.instruction || ''}`;
      const utterance = new SpeechSynthesisUtterance(textToRead);
      utterance.rate = 0.92;
      const matchedLang = CHEFLY_LANGUAGES.find((l) => l.code === selectedLanguage);
      utterance.lang = matchedLang ? matchedLang.speechCode : 'en-US';

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.warn('Speech synthesis error:', e);
      setIsSpeaking(false);
    }
  };

  const handleCopyRecipe = () => {
    if (!currentRecipe) return;
    const text = `🍽️ ${currentRecipe.title}\n${currentRecipe.tagline}\n⏱️ Prep: ${currentRecipe.prepTime} | Cook: ${currentRecipe.cookTime} | Servings: ${currentRecipe.servings}\n\n🛒 INGREDIENTS:\n${currentRecipe.ingredients.map((i) => `• ${i.amount} ${i.name}${i.substitute ? ` (or ${i.substitute})` : ''}`).join('\n')}\n\n👩‍🍳 INSTRUCTIONS:\n${currentRecipe.steps.map((s) => `${s.step}. ${s.title}: ${s.instruction}`).join('\n\n')}\n\n💡 MOM HACKS:\n${currentRecipe.momHacks.map((h) => `• ${h}`).join('\n')}\n\n👶 KID-FRIENDLY TWIST: ${currentRecipe.kidFriendlyTwist}`;

    navigator.clipboard.writeText(text);
    setCopiedRecipe(true);
    setTimeout(() => setCopiedRecipe(false), 2500);
  };

  const handleSendChatMessage = async (presetQuestion?: string) => {
    const query = (presetQuestion || chatInput).trim();
    if (!query || isChatLoading) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    const userMsg: CheflyChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setChatInput('');
    setIsChatLoading(true);

    const activeLanguage =
      selectedLanguage === 'custom'
        ? customLanguage.trim() || 'Any Language'
        : selectedLanguage;

    try {
      const res = await fetch('/api/chefly/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: chatMessages,
          language: activeLanguage,
        }),
      });

      const data = await res.json();
      if (data.success && data.reply) {
        const aiMsg: CheflyChatMessage = {
          id: `a-${Date.now()}`,
          role: 'assistant',
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setChatMessages((prev) => [...prev, aiMsg]);
      } else {
        const aiMsg: CheflyChatMessage = {
          id: `a-${Date.now()}`,
          role: 'assistant',
          text: `**I'm right here with you, Mama!** ❤️\n\nHere is a quick kitchen hero solution for "${query}":\n• **Speedy Solution:** If you're running short on time or ingredients, a simple omelet, warm grain bowl with butter & greens, or quesadilla takes under 10 minutes.\n• **Mom Hack:** Keep grated cheese and chopped greens frozen in small sandwich bags so you never have to chop on exhausting weeknights.\n• **Reassurance:** Whatever you put on the table tonight, your love is the main ingredient. You are doing fantastic!`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setChatMessages((prev) => [...prev, aiMsg]);
      }
    } catch (err) {
      console.error('Chefly chat error:', err);
      const aiMsg: CheflyChatMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        text: `**I'm right here with you, Mama!** ❤️\n\nQuick tip: When dinner feels overwhelming, simple meals like scrambled eggs on toast or noodle soup are wholesome, soothing, and loved by kids. What ingredients do you have on hand right now?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setChatMessages((prev) => [...prev, aiMsg]);
    } finally {
      setIsChatLoading(false);
    }
  };

  const formatTimerDisplay = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div id="chefly-ai-view" className="max-w-7xl mx-auto space-y-6 pb-16 px-2 sm:px-4">
      {/* Hero Branding Banner */}
      <div className="relative rounded-3xl p-6 sm:p-8 bg-gradient-to-br from-[#1a1222] via-[#120e1a] to-[#0d0914] border border-[#ffb4a2]/30 shadow-2xl overflow-hidden">
        <div className="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-[#ffb4a2]/10 blur-3xl pointer-events-none" />
        <div className="absolute -left-16 -bottom-16 w-80 h-80 rounded-full bg-[#cfbcff]/10 blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#ffb4a2] to-[#cfbcff] text-[#2c131a] flex items-center justify-center font-bold shadow-lg shadow-[#ffb4a2]/20">
                <ChefHat className="w-5 h-5 text-[#2c131a]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-extrabold text-white font-sora tracking-tight">
                    AI Chefly AI
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-[#ffb4a2]/20 text-[#ffb4a2] border border-[#ffb4a2]/40">
                    Mothers Kitchen Helper
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-zinc-400">
                  Loving family cooking mentor • Fridge ingredient transformation • Kids lunchbox wins • Stress-free 20-minute dinners
                </p>
              </div>
            </div>

            {/* Mode Pills */}
            <div className="flex flex-wrap gap-2 pt-2">
              {[
                { id: 'fridge-magic', label: '🧺 Fridge Magic', desc: 'Cook with what you have' },
                { id: 'quick-meals', label: '⚡ 15-Min Quick Dinners', desc: 'One-pot lifesavers' },
                { id: 'kids-lunchbox', label: '🍱 Kids & Lunchbox', desc: 'Zero mess & picky-eater approved' },
                { id: 'leftover-revamp', label: '♻️ Leftover Revamp', desc: 'Turn yesterday into gourmet' },
                { id: 'meal-planner', label: '📅 Weekly Meal Plan', desc: '5-day balanced family calendar' },
                { id: 'chefly-chat', label: '👩‍🍳 Ask Chefly SOS', desc: 'Instant cooking advice & fixes' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    setActiveMode(m.id as CheflyMode);
                    if (m.id !== 'chefly-chat') {
                      handleGenerate();
                    }
                  }}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all flex items-center gap-1.5 border ${
                    activeMode === m.id
                      ? 'bg-gradient-to-r from-[#ffb4a2]/25 to-[#cfbcff]/20 text-[#ffb4a2] border-[#ffb4a2]/60 shadow-lg shadow-[#ffb4a2]/10 font-semibold'
                      : 'bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white border-white/5'
                  }`}
                >
                  <span>{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Stats or Active Timer Preview */}
          <div className="flex flex-row md:flex-col items-center md:items-end gap-3 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 border-white/10 pt-4 md:pt-0">
            {activeTimerSeconds !== null ? (
              <div className="p-3.5 rounded-2xl bg-black/60 border border-[#ffb4a2]/40 flex items-center gap-3">
                <div className="text-right">
                  <div className="text-[10px] font-mono text-zinc-400 truncate max-w-[120px]">
                    {timerLabel}
                  </div>
                  <div className="text-xl font-mono font-black text-[#ffb4a2]">
                    {formatTimerDisplay(activeTimerSeconds)}
                  </div>
                </div>
                <button
                  onClick={() => setTimerRunning(!timerRunning)}
                  className="p-2.5 rounded-xl bg-[#ffb4a2] text-[#2c131a] hover:opacity-90 font-bold"
                  title={timerRunning ? 'Pause Timer' : 'Resume Timer'}
                >
                  {timerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => {
                    setActiveTimerSeconds(null);
                    setTimerRunning(false);
                  }}
                  className="p-2 text-zinc-500 hover:text-zinc-300"
                  title="Dismiss Timer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="px-4 py-2 rounded-2xl bg-white/5 border border-white/10 text-right">
                <div className="text-[10px] font-mono text-zinc-400">Daily Family Quota</div>
                <div className="text-xs font-mono font-bold text-[#ffb4a2]">
                  {dailyUsage} / {dailyLimit} Recipes Generated
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Multilingual Mode Ribbon */}
        <div className="mt-5 pt-4 border-t border-white/10 space-y-2.5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-[#ffb4a2]/20 flex items-center justify-center">
                <Globe className="w-4 h-4 text-[#ffb4a2]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-white">
                    Language / भाषा / மொழி / తెలుగు / Idioma / Langue
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    Knows All Languages
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  Chefly speaks, understands, and translates recipes into any Indian or international language
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="relative">
                <select
                  value={selectedLanguage}
                  onChange={(e) => {
                    setSelectedLanguage(e.target.value);
                    if (e.target.value === 'custom') {
                      setShowCustomLanguageInput(true);
                    } else {
                      setShowCustomLanguageInput(false);
                    }
                  }}
                  className="pl-3 pr-8 py-1.5 rounded-xl bg-black/60 border border-[#ffb4a2]/40 text-[#ffb4a2] text-xs font-mono font-bold focus:outline-none cursor-pointer"
                >
                  {CHEFLY_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code} className="bg-[#1a1222] text-white">
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                  <option value="custom" className="bg-[#1a1222] text-white">
                    ✍️ Other Language / Dialect...
                  </option>
                </select>
              </div>

              {currentRecipe && (
                <button
                  onClick={() => handleGenerate()}
                  disabled={isLoading}
                  className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#ffb4a2]/20 to-[#cfbcff]/20 hover:from-[#ffb4a2]/30 hover:to-[#cfbcff]/30 text-[#ffb4a2] border border-[#ffb4a2]/40 text-xs font-mono font-semibold flex items-center gap-1.5 transition-all shadow-sm"
                  title="Generate or translate recipe into the selected language"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>Translate Recipe</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Popular Languages Bar */}
          <div className="flex flex-wrap items-center gap-1.5 overflow-x-auto pb-1">
            <span className="text-[10px] font-mono text-zinc-400 mr-1 flex-shrink-0">
              Quick Select:
            </span>
            {CHEFLY_LANGUAGES.slice(0, 10).map((lang) => {
              const isSelected = selectedLanguage === lang.code;
              return (
                <button
                  key={lang.code}
                  onClick={() => {
                    setSelectedLanguage(lang.code);
                    setShowCustomLanguageInput(false);
                  }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono transition-all flex items-center gap-1.5 border flex-shrink-0 ${
                    isSelected
                      ? 'bg-[#ffb4a2] text-[#2c131a] font-bold border-[#ffb4a2] shadow-sm'
                      : 'bg-white/5 hover:bg-white/10 text-zinc-300 border-white/10'
                  }`}
                >
                  <span>{lang.flag}</span>
                  <span>{lang.code === 'Auto-Detect' ? 'Auto-Detect' : lang.name.split(' ')[0]}</span>
                </button>
              );
            })}
          </div>

          {showCustomLanguageInput && (
            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                value={customLanguage}
                onChange={(e) => setCustomLanguage(e.target.value)}
                placeholder="Type any language or dialect (e.g. Swahili, Tagalog, Gujarati, Punjabi, Malayalam)..."
                className="flex-1 px-3 py-2 rounded-xl bg-black/60 border border-[#ffb4a2]/50 text-white text-xs placeholder:text-zinc-500 focus:outline-none"
              />
              <button
                onClick={() => handleGenerate()}
                disabled={isLoading}
                className="px-3 py-2 rounded-xl bg-[#ffb4a2] text-[#2c131a] font-bold text-xs hover:opacity-90 flex-shrink-0"
              >
                Apply & Cook
              </button>
            </div>
          )}
        </div>
      </div>

      {activeMode === 'chefly-chat' ? (
        /* SOS Mother Kitchen Chat Mode */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Preset Questions */}
          <div className="lg:col-span-4 space-y-4">
            <div className="p-5 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-3">
              <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-[#ffb4a2] flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-[#ffb4a2]" />
                Kitchen SOS & Mom FAQs
              </h3>
              <p className="text-xs text-zinc-400">
                Tap any common cooking emergency or query to receive instant loving guidance:
              </p>
              <div className="space-y-2 pt-1">
                {QUICK_KITCHEN_QUESTIONS.map((q, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendChatMessage(q)}
                    disabled={isChatLoading}
                    className="w-full text-left p-2.5 rounded-xl bg-white/5 hover:bg-[#ffb4a2]/15 hover:border-[#ffb4a2]/40 text-zinc-300 hover:text-white text-xs border border-white/10 transition-colors flex items-start gap-2"
                  >
                    <span className="text-[#ffb4a2] font-bold mt-0.5">•</span>
                    <span>{q}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Chat Stream */}
          <div className="lg:col-span-8 flex flex-col h-[580px] rounded-2xl bg-[#0c0a12]/95 border border-white/10 overflow-hidden shadow-2xl">
            <div className="p-4 bg-black/40 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#ffb4a2] to-[#cfbcff] text-[#2c131a] font-bold text-xs flex items-center justify-center">
                  👩‍🍳
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white font-sora">
                    AI Chefly AI Assistant
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Kitchen Expert Online
                    </span>
                    <span className="text-zinc-600">•</span>
                    <span className="text-[10px] font-mono text-[#ffb4a2] flex items-center gap-1">
                      <Globe className="w-2.5 h-2.5" />
                      {selectedLanguage === 'Auto-Detect' ? 'Multilingual (All Languages)' : selectedLanguage}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex-1 p-4 overflow-y-auto space-y-4">
              {chatMessages.map((msg) => {
                const isAssistant = msg.role === 'assistant';
                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-3 ${isAssistant ? '' : 'flex-row-reverse'}`}
                  >
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-mono font-bold flex-shrink-0 mt-1 ${
                        isAssistant
                          ? 'bg-[#ffb4a2]/20 text-[#ffb4a2]'
                          : 'bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38]'
                      }`}
                    >
                      {isAssistant ? 'CH' : 'MOM'}
                    </div>

                    <div
                      className={`max-w-[85%] p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        isAssistant
                          ? 'bg-white/[0.04] border border-white/10 text-zinc-200 rounded-tl-none space-y-2'
                          : 'bg-[#ffb4a2]/20 border border-[#ffb4a2]/40 text-white rounded-tr-none'
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{msg.text}</div>
                      <div className="text-[10px] font-mono text-zinc-500 pt-1 border-t border-white/5">
                        {msg.timestamp}
                      </div>
                    </div>
                  </div>
                );
              })}
              {isChatLoading && (
                <div className="flex items-center gap-2 text-xs font-mono text-zinc-400 p-2">
                  <div className="w-3 h-3 rounded-full border border-[#ffb4a2] border-t-transparent animate-spin" />
                  <span>AI Chefly is crafting practical culinary advice...</span>
                </div>
              )}
              <div ref={chatScrollRef} />
            </div>

            <div className="p-3 bg-black/60 border-t border-white/10 flex items-center gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                placeholder={`Ask Chefly in any language (English, हिन्दी, தமிழ், Español, Français, etc.)...`}
                className="flex-1 px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs sm:text-sm placeholder:text-zinc-500 focus:outline-none focus:border-[#ffb4a2]/50"
              />
              <button
                onClick={() => handleSendChatMessage()}
                disabled={isChatLoading || !chatInput.trim()}
                className="p-3 rounded-xl bg-[#ffb4a2] text-[#2c131a] font-bold hover:opacity-90 disabled:opacity-40 transition-opacity"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Recipe Generation and Interactive Kitchen Dashboard */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Pantry & Family Preferences Controls (4 cols) */}
          <div className="lg:col-span-4 space-y-5">
            {/* Pantry / Ingredients Picker */}
            <div className="p-5 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono uppercase tracking-widest text-[#ffb4a2] font-bold flex items-center gap-1.5">
                  <Carrot className="w-4 h-4 text-[#ffb4a2]" />
                  What's in your Fridge / Kitchen?
                </span>
                <span className="text-[10px] font-mono text-zinc-400">
                  {selectedIngredients.length} selected
                </span>
              </div>

              {/* Quick Chip Selection */}
              <div className="flex flex-wrap gap-1.5 max-h-44 overflow-y-auto pr-1">
                {COMMON_PANTRY_CHIPS.map((chip) => {
                  const isSelected = selectedIngredients.includes(chip);
                  return (
                    <button
                      key={chip}
                      onClick={() => toggleIngredientChip(chip)}
                      className={`px-2.5 py-1 rounded-lg text-xs transition-all border ${
                        isSelected
                          ? 'bg-[#ffb4a2]/25 text-[#ffb4a2] border-[#ffb4a2]/60 font-medium'
                          : 'bg-white/5 hover:bg-white/10 text-zinc-400 border-white/5'
                      }`}
                    >
                      {isSelected ? '✓ ' : '+ '}
                      {chip}
                    </button>
                  );
                })}
              </div>

              {/* Custom Item Input */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  value={customIngredientInput}
                  onChange={(e) => setCustomIngredientInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddCustomIngredient()}
                  placeholder="Add custom ingredient (e.g. Avocado, Paneer)..."
                  className="flex-1 px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs placeholder:text-zinc-500 focus:outline-none focus:border-[#ffb4a2]/50"
                />
                <button
                  onClick={handleAddCustomIngredient}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Family & Cooking Settings */}
            <div className="p-5 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-4 shadow-xl">
              <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-1.5">
                <Heart className="w-4 h-4 text-[#cfbcff]" />
                Family & Kids Customization
              </span>

              <div className="space-y-3">
                <div>
                  <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                    Meal Type:
                  </label>
                  <select
                    value={mealType}
                    onChange={(e) => setMealType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-[#ffb4a2]/50"
                  >
                    <option value="Quick Weeknight Dinner">Quick Weeknight Dinner (One-Pot)</option>
                    <option value="Kids School Lunchbox">Kids School Lunchbox (Zero Spill)</option>
                    <option value="Nutritious Morning Breakfast">Energizing Morning Breakfast</option>
                    <option value="Healthy Afternoon Snack">Healthy Afternoon Snack</option>
                    <option value="Sunday Comfort Family Feast">Sunday Comfort Family Feast</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-mono text-zinc-400 block mb-1">
                    Family Size & Portions:
                  </label>
                  <select
                    value={familySize}
                    onChange={(e) => setFamilySize(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-[#ffb4a2]/50"
                  >
                    <option value="Family of 4 (2 adults, 2 kids)">Family of 4 (2 adults, 2 kids)</option>
                    <option value="Family of 3 (2 adults, 1 child)">Family of 3 (2 adults, 1 child)</option>
                    <option value="Mom & Toddler (2 portions)">Mom & Toddler (2 portions)</option>
                    <option value="Big Family (5 to 6 persons)">Big Family (5 to 6 persons)</option>
                  </select>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/5 border border-white/5">
                  <div className="flex items-center gap-2">
                    <Baby className="w-4 h-4 text-[#ffb4a2]" />
                    <div>
                      <div className="text-xs font-semibold text-white">Kid-Friendly Mode</div>
                      <div className="text-[10px] text-zinc-400">Gentle spices & hidden vegetable tricks</div>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={kidFriendly}
                    onChange={(e) => setKidFriendly(e.target.checked)}
                    className="w-4 h-4 rounded text-[#ffb4a2] focus:ring-0 accent-[#ffb4a2]"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[11px] font-mono text-zinc-400 mb-1">
                    <span>Cooking Time Limit:</span>
                    <span className="text-[#ffb4a2] font-bold">{timeLimit} mins max</span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={60}
                    step={5}
                    value={timeLimit}
                    onChange={(e) => setTimeLimit(Number(e.target.value))}
                    className="w-full accent-[#ffb4a2] cursor-pointer"
                  />
                </div>

                {/* Multilingual Selector in Card */}
                <div className="pt-1 border-t border-white/5">
                  <label className="text-[11px] font-mono text-zinc-400 block mb-1 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-white">
                      <Globe className="w-3.5 h-3.5 text-[#ffb4a2]" />
                      Recipe Language:
                    </span>
                    <span className="text-[10px] text-[#ffb4a2] font-mono">All Languages Mode</span>
                  </label>
                  <select
                    value={selectedLanguage}
                    onChange={(e) => {
                      setSelectedLanguage(e.target.value);
                      if (e.target.value === 'custom') {
                        setShowCustomLanguageInput(true);
                      } else {
                        setShowCustomLanguageInput(false);
                      }
                    }}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white text-xs focus:outline-none focus:border-[#ffb4a2]/50"
                  >
                    {CHEFLY_LANGUAGES.map((lang) => (
                      <option key={lang.code} value={lang.code} className="bg-[#120e1a] text-white">
                        {lang.flag} {lang.name}
                      </option>
                    ))}
                    <option value="custom" className="bg-[#120e1a] text-white">
                      ✍️ Other Language / Dialect...
                    </option>
                  </select>
                </div>
              </div>

              <button
                onClick={() => handleGenerate()}
                disabled={isLoading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#ffb4a2] to-[#cfbcff] text-[#2c131a] font-bold text-xs sm:text-sm font-sora shadow-lg shadow-[#ffb4a2]/20 hover:opacity-95 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 rounded-full border-2 border-[#2c131a] border-t-transparent animate-spin" />
                    <span>AI Chefly is Cooking...</span>
                  </>
                ) : (
                  <>
                    <ChefHat className="w-4 h-4" />
                    <span>Create Magical Recipe</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Generated Recipe Card & Interactive Step Engine (8 cols) */}
          <div className="lg:col-span-8 space-y-6">
            {currentRecipe ? (
              <div className="p-6 sm:p-8 rounded-3xl bg-[#0c0a12]/95 border border-white/10 shadow-2xl space-y-6">
                {/* Title & Top Action Bar */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[10px] font-mono uppercase tracking-widest text-[#ffb4a2] font-bold flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3" />
                        Mom-Approved Recipe Recommendation
                      </span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1">
                        <Globe className="w-2.5 h-2.5" />
                        {selectedLanguage === 'Auto-Detect' ? 'Multilingual' : selectedLanguage}
                      </span>
                    </div>
                    <h2 className="text-xl sm:text-2xl font-bold text-white font-sora">
                      {currentRecipe.title}
                    </h2>
                    <p className="text-xs sm:text-sm text-zinc-300 italic">
                      "{currentRecipe.tagline}"
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSpeakRecipe}
                      className={`px-3 py-2 rounded-xl border text-xs font-mono flex items-center gap-1.5 transition-colors ${
                        isSpeaking
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                          : 'bg-white/5 hover:bg-white/10 text-zinc-300 border-white/10'
                      }`}
                      title="Listen hands-free while cooking"
                    >
                      {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-[#ffb4a2]" />}
                      <span>{isSpeaking ? 'Stop Audio' : 'Hands-Free Voice'}</span>
                    </button>

                    <button
                      onClick={handleCopyRecipe}
                      className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-300 border border-white/10 transition-colors"
                      title="Copy Recipe"
                    >
                      {copiedRecipe ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Recipe Metrics Badges */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-[10px] font-mono text-zinc-400 flex items-center justify-center gap-1">
                      <Clock className="w-3 h-3 text-[#ffb4a2]" /> Total Time
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                      {currentRecipe.totalTime}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-[10px] font-mono text-zinc-400 flex items-center justify-center gap-1">
                      <Flame className="w-3 h-3 text-amber-400" /> Calories
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                      {currentRecipe.estimatedCalories}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-[10px] font-mono text-zinc-400 flex items-center justify-center gap-1">
                      <ChefHat className="w-3 h-3 text-[#cfbcff]" /> Difficulty
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                      {currentRecipe.difficulty}
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-white/5 border border-white/5 text-center">
                    <div className="text-[10px] font-mono text-zinc-400 flex items-center justify-center gap-1">
                      <Heart className="w-3 h-3 text-rose-400" /> Servings
                    </div>
                    <div className="text-xs sm:text-sm font-bold text-white mt-0.5">
                      {currentRecipe.servings}
                    </div>
                  </div>
                </div>

                {/* Health & Kids Nutrition Highlights */}
                {currentRecipe.healthBenefits && (
                  <div className="flex flex-wrap items-center gap-2 p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
                    <span className="text-[11px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                      🌱 Health & Kids Benefits:
                    </span>
                    {currentRecipe.healthBenefits.map((b, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-medium"
                      >
                        ✓ {b}
                      </span>
                    ))}
                  </div>
                )}

                {/* Ingredients & Substitutions Checklist */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-mono uppercase tracking-widest text-[#ffb4a2] font-bold flex items-center gap-2">
                      <Utensils className="w-4 h-4" />
                      Ingredients & Smart Substitutions
                    </h3>
                    <span className="text-[10px] font-mono text-zinc-500">
                      Tap checkbox when measured
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {currentRecipe.ingredients.map((ing, iIdx) => {
                      const isChecked = Boolean(checkedIngredients[ing.name]);
                      return (
                        <div
                          key={iIdx}
                          onClick={() =>
                            setCheckedIngredients((prev) => ({
                              ...prev,
                              [ing.name]: !isChecked,
                            }))
                          }
                          className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-2.5 ${
                            isChecked
                              ? 'bg-white/[0.02] border-white/5 opacity-50 line-through'
                              : 'bg-white/5 border-white/10 hover:border-[#ffb4a2]/40'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            readOnly
                            className="mt-1 w-3.5 h-3.5 rounded text-[#ffb4a2] accent-[#ffb4a2]"
                          />
                          <div className="text-xs">
                            <span className="font-semibold text-white">{ing.amount} </span>
                            <span className="text-zinc-300">{ing.name}</span>
                            {ing.substitute && (
                              <div className="text-[10px] text-amber-300/80 font-mono mt-0.5">
                                ↺ Sub: {ing.substitute}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Step-By-Step Cooking Engine */}
                <div className="space-y-4 pt-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      Step-By-Step Cooking Instructions
                    </h3>
                    <span className="text-[10px] font-mono text-zinc-500">
                      Check steps as you cook
                    </span>
                  </div>

                  <div className="space-y-3">
                    {currentRecipe.steps.map((stepItem) => {
                      const isStepDone = Boolean(checkedSteps[stepItem.step]);
                      return (
                        <div
                          key={stepItem.step}
                          className={`p-4 rounded-2xl border transition-all ${
                            isStepDone
                              ? 'bg-white/[0.02] border-white/5 opacity-60'
                              : 'bg-white/[0.04] border-white/10 hover:border-white/20'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3">
                              <button
                                onClick={() =>
                                  setCheckedSteps((prev) => ({
                                    ...prev,
                                    [stepItem.step]: !isStepDone,
                                  }))
                                }
                                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono transition-colors flex-shrink-0 mt-0.5 ${
                                  isStepDone
                                    ? 'bg-emerald-500 text-white'
                                    : 'bg-[#ffb4a2]/20 text-[#ffb4a2] border border-[#ffb4a2]/40'
                                }`}
                              >
                                {isStepDone ? '✓' : stepItem.step}
                              </button>
                              <div>
                                <h4 className="text-xs font-bold text-white font-sora">
                                  {stepItem.title}
                                </h4>
                                <p className="text-xs text-zinc-300 mt-1 leading-relaxed">
                                  {stepItem.instruction}
                                </p>
                                {stepItem.momTip && (
                                  <div className="text-[11px] text-[#ffb4a2] font-mono mt-1.5 flex items-center gap-1.5">
                                    <span>💡 Mom Shortcut:</span>
                                    <span className="text-zinc-300 font-sans">{stepItem.momTip}</span>
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Step Timer Trigger */}
                            {stepItem.timerMinutes && (
                              <button
                                onClick={() =>
                                  handleStartStepTimer(stepItem.timerMinutes!, stepItem.title)
                                }
                                className="px-2.5 py-1 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-[10px] font-mono flex items-center gap-1 flex-shrink-0"
                                title="Click to start kitchen timer"
                              >
                                <Clock className="w-3 h-3" />
                                <span>{stepItem.timerMinutes}m Timer</span>
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Mom Hacks & Kid-Friendly Presentation Twist */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 rounded-2xl bg-[#ffb4a2]/10 border border-[#ffb4a2]/30 space-y-2">
                    <span className="text-xs font-mono font-bold text-[#ffb4a2] flex items-center gap-1.5">
                      👩‍🍳 Chefly Mom Hacks
                    </span>
                    <ul className="space-y-1.5 text-xs text-zinc-300">
                      {currentRecipe.momHacks.map((hack, hIdx) => (
                        <li key={hIdx} className="flex items-start gap-1.5">
                          <span className="text-[#ffb4a2] font-bold">•</span>
                          <span>{hack}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 rounded-2xl bg-[#cfbcff]/10 border border-[#cfbcff]/30 space-y-2">
                    <span className="text-xs font-mono font-bold text-[#cfbcff] flex items-center gap-1.5">
                      👶 Kid-Friendly Presentation
                    </span>
                    <p className="text-xs text-zinc-300 leading-relaxed">
                      {currentRecipe.kidFriendlyTwist}
                    </p>
                    <div className="text-[10px] font-mono text-zinc-400 pt-2 border-t border-white/5">
                      📦 Storage: {currentRecipe.leftoverStorage}
                    </div>
                  </div>
                </div>

                {/* Organized Grocery Shopping Checklist */}
                {currentRecipe.groceryAisleList && (
                  <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase tracking-wider text-zinc-300 font-bold flex items-center gap-1.5">
                        <ShoppingBag className="w-3.5 h-3.5 text-[#ffb4a2]" />
                        Organized Supermarket Checklist
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-[10px] font-mono text-[#ffb4a2] block mb-1">
                          Produce & Greens:
                        </span>
                        <div className="space-y-1 text-zinc-300">
                          {currentRecipe.groceryAisleList.produce?.map((item, idx) => (
                            <label key={idx} className="flex items-center gap-1.5 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={Boolean(checkedGroceries[item])}
                                onChange={() =>
                                  setCheckedGroceries((prev) => ({ ...prev, [item]: !prev[item] }))
                                }
                                className="w-3 h-3 rounded accent-[#ffb4a2]"
                              />
                              <span className={checkedGroceries[item] ? 'line-through opacity-50' : ''}>
                                {item}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-[10px] font-mono text-[#cfbcff] block mb-1">
                          Dairy & Pantry:
                        </span>
                        <div className="space-y-1 text-zinc-300">
                          {currentRecipe.groceryAisleList.dairyOrPantry?.map((item, idx) => (
                            <label key={idx} className="flex items-center gap-1.5 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={Boolean(checkedGroceries[item])}
                                onChange={() =>
                                  setCheckedGroceries((prev) => ({ ...prev, [item]: !prev[item] }))
                                }
                                className="w-3 h-3 rounded accent-[#ffb4a2]"
                              />
                              <span className={checkedGroceries[item] ? 'line-through opacity-50' : ''}>
                                {item}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-black/40 border border-white/5">
                        <span className="text-[10px] font-mono text-amber-300 block mb-1">
                          Spices & Seasonings:
                        </span>
                        <div className="space-y-1 text-zinc-300">
                          {currentRecipe.groceryAisleList.spices?.map((item, idx) => (
                            <label key={idx} className="flex items-center gap-1.5 cursor-pointer">
                              <input
                                type="checkbox"
                                checked={Boolean(checkedGroceries[item])}
                                onChange={() =>
                                  setCheckedGroceries((prev) => ({ ...prev, [item]: !prev[item] }))
                                }
                                className="w-3 h-3 rounded accent-[#ffb4a2]"
                              />
                              <span className={checkedGroceries[item] ? 'line-through opacity-50' : ''}>
                                {item}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-12 rounded-3xl bg-[#0c0a12]/95 border border-white/10 text-center space-y-4">
                <ChefHat className="w-12 h-12 text-[#ffb4a2] mx-auto opacity-70 animate-bounce" />
                <h3 className="text-lg font-bold text-white font-sora">
                  Ready to assist you in the kitchen, Mama!
                </h3>
                <p className="text-xs text-zinc-400 max-w-md mx-auto">
                  Pick your fridge ingredients on the left and click "Create Magical Recipe" to receive an instant, family-friendly culinary masterpiece.
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
