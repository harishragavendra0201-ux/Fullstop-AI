import React, { useState } from 'react';
import { ProjectHelperPlan, UserProfile } from '../types';
import {
  FolderGit2,
  Sparkles,
  CheckCircle,
  Copy,
  Check,
  Calendar,
  BookOpen,
  Award,
  Layers,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

interface ProjectHelperViewProps {
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onIncrementUsage: () => boolean;
  onOpenUpgrade: () => void;
  initialPrompt?: string;
}

const PRESET_PROJECTS = [
  {
    title: 'Autonomous Multi-Agent Drone Fleet for Wildfire Mapping',
    domain: 'Computer Vision & Robotics',
  },
  {
    title: 'Predictive Health Risk Modeling via Graph Neural Networks',
    domain: 'Bioinformatics & Machine Learning',
  },
  {
    title: 'Zero-Knowledge Cryptographic Voting Protocol',
    domain: 'Distributed Systems & Cybersecurity',
  },
];

const INITIAL_PROJECT_PLAN: ProjectHelperPlan = {
  id: 'proj-plan-1',
  projectTitle: 'Autonomous Multi-Agent Drone Fleet for Wildfire Mapping',
  fieldOfStudy: 'Robotics & AI',
  academicLevel: 'undergrad',
  thesisStatement:
    'By decentralizing visual feature clustering across distributed edge quadcopters using lightweight consensus protocols, multi-agent aerial swarms can map dynamic wildfire perimeter vectors with 40% lower communication bandwidth than centralized telemetry.',
  problemStatement:
    'Current aerial wildfire monitoring relies on single high-altitude sensors or satellite sweeps with 6–12 hour latency cycles, failing to provide instantaneous tactical telemetry to ground firefighting teams in dense smoke canopy.',
  methodologyOverview:
    'A three-phase experimental pipeline combining high-fidelity ROS 2 / Gazebo drone physics simulations with quantized YOLOv8-edge vision models and gossip-based swarm spatial maps.',
  milestones: [
    {
      id: 'm-1',
      phase: 'Phase 1',
      title: 'Literature Synthesis & Simulation Framework',
      deliverables: [
        'Survey of distributed SLAM and aerial thermal segmentation papers',
        'Setup ROS 2 Humble simulation with synthetic smoke particulate models',
      ],
      estimatedDays: 21,
    },
    {
      id: 'm-2',
      phase: 'Phase 2',
      title: 'Swarm Consensus & Edge Detection Integration',
      deliverables: [
        'Edge gossip communication protocol running over simulated WiFi mesh',
        'Thermal flame-boundary polygon extraction algorithm',
      ],
      estimatedDays: 28,
    },
    {
      id: 'm-3',
      phase: 'Phase 3',
      title: 'Validation, Benchmark Experiments & Thesis Defense',
      deliverables: [
        'Comparative ablation study against centralized telemetry baselines',
        'Complete final engineering thesis paper and defense slide deck',
      ],
      estimatedDays: 21,
    },
  ],
  recommendedCitations: [
    {
      title: 'Decentralized Visual SLAM for Collaborative Aerial Swarms',
      authors: 'Schmuck, P., & Chli, M.',
      year: 2021,
      formatAPA: 'Schmuck, P., & Chli, M. (2021). Decentralized visual SLAM for collaborative aerial swarms. IEEE Transactions on Robotics, 37(6), 2090-2104.',
      formatIEEE: 'P. Schmuck and M. Chli, "Decentralized Visual SLAM for Collaborative Aerial Swarms," IEEE Trans. Robot., vol. 37, no. 6, pp. 2090-2104, Dec. 2021.',
    },
    {
      title: 'A Review on Wildfire Detection Using Unmanned Aerial Systems and Deep Learning',
      authors: 'Barmpoutis, P., Papaioannou, P., Dimitropoulos, K., & Grammalidis, N.',
      year: 2020,
      formatAPA: 'Barmpoutis, P., Papaioannou, P., Dimitropoulos, K., & Grammalidis, N. (2020). A review on wildfire detection using unmanned aerial systems. Sensors, 20(22), 6442.',
      formatIEEE: 'P. Barmpoutis et al., "A Review on Wildfire Detection Using Unmanned Aerial Systems," Sensors, vol. 20, no. 22, p. 6442, 2020.',
    },
  ],
  rubricAdvice: [
    'Methodology Rigor: Clearly delineate your independent vs dependent variables. Do not just report accuracy; include latency and energy footprint metrics.',
    'Ablation Studies: Include an ablation table demonstrating the exact contribution of each swarm component.',
    'Reproducibility: Provide a clean GitHub repository with Dockerfile and scripted test runner.',
  ],
};

export const ProjectHelperView: React.FC<ProjectHelperViewProps> = ({
  userProfile,
  dailyUsage,
  dailyLimit,
  onIncrementUsage,
  onOpenUpgrade,
  initialPrompt,
}) => {
  const [projectTitle, setProjectTitle] = useState(initialPrompt || '');
  const [domain, setDomain] = useState('');
  const [academicLevel, setAcademicLevel] = useState<'highschool' | 'undergrad' | 'graduate' | 'industry'>('undergrad');
  const [isLoading, setIsLoading] = useState(false);
  const [plan, setPlan] = useState<ProjectHelperPlan>(INITIAL_PROJECT_PLAN);
  const [citationFormat, setCitationFormat] = useState<'APA' | 'IEEE'>('IEEE');
  const [copiedCitationIdx, setCopiedCitationIdx] = useState<number | null>(null);

  const handleGeneratePlan = async () => {
    if (!projectTitle.trim()) return;

    if (!onIncrementUsage()) {
      onOpenUpgrade();
      return;
    }

    setIsLoading(true);
    try {
      const res = await fetch('/api/project/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectTitle: projectTitle.trim(),
          domain: domain.trim() || 'Applied Engineering',
          academicLevel,
        }),
      });
      const data = await res.json();
      if (data.success && data.plan) {
        setPlan(data.plan);
      }
    } catch (err) {
      console.error('Project Plan generation error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCitation = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedCitationIdx(idx);
    setTimeout(() => setCopiedCitationIdx(null), 2000);
  };

  return (
    <div id="project-helper-view" className="max-w-7xl mx-auto space-y-6 pb-12">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#171424] via-[#100d1c] to-[#07060c] border border-white/10 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-[#cfbcff]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono tracking-widest uppercase bg-[#cfbcff]/15 text-[#cfbcff] border border-[#cfbcff]/30 flex items-center gap-1.5">
                <FolderGit2 className="w-3 h-3" />
                ACADEMIC THESIS & CAPSTONE ARCHITECT
              </span>
              <span className="text-xs font-mono text-zinc-400">RESEARCH PAPERS & MILESTONES</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-sora text-white tracking-tight">
              Assignment & Project Helper // Thesis & Roadmap Generator
            </h2>
            <p className="text-sm text-zinc-300 mt-1 max-w-2xl">
              Deconstruct ambitious engineering capstones and academic assignments into defensible thesis
              propositions, milestone roadmaps, verified citations, and maximum-grade rubric strategies.
            </p>
          </div>
        </div>
      </div>

      {/* Generator Controls */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#0e0c14]/90 border border-white/10 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
          <div className="md:col-span-6">
            <input
              type="text"
              value={projectTitle}
              onChange={(e) => setProjectTitle(e.target.value)}
              placeholder="Enter assignment or project title (e.g. Distributed Key-Value Store, CRISPR Ethics)..."
              className="w-full px-4 py-3 rounded-xl bg-black/50 border border-white/10 text-white placeholder:text-zinc-500 text-sm focus:outline-none focus:border-[#cfbcff]/50"
            />
          </div>

          <div className="md:col-span-3">
            <select
              value={academicLevel}
              onChange={(e) => setAcademicLevel(e.target.value as any)}
              className="w-full px-3 py-3 rounded-xl bg-black/50 border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-[#cfbcff]/50 cursor-pointer"
            >
              <option value="highschool">High School / AP Capstone</option>
              <option value="undergrad">Undergraduate Thesis / Major Project</option>
              <option value="graduate">Master's / PhD Dissertation</option>
              <option value="industry">Industry Engineering Spec</option>
            </select>
          </div>

          <div className="md:col-span-3">
            <button
              onClick={handleGeneratePlan}
              disabled={isLoading || !projectTitle.trim()}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#cfbcff] to-[#6750a4] text-[#1c0f38] font-bold text-sm flex items-center justify-center gap-2 hover:opacity-95 transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(207,188,255,0.25)]"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 rounded-full border-2 border-[#1c0f38] border-t-transparent animate-spin" />
                  <span>Synthesizing Architecture...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Generate Blueprint</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Presets */}
        <div className="flex items-center gap-2 flex-wrap pt-1">
          <span className="text-[11px] font-mono text-zinc-500 uppercase">Presets:</span>
          {PRESET_PROJECTS.map((p) => (
            <button
              key={p.title}
              onClick={() => {
                setProjectTitle(p.title);
                setDomain(p.domain);
              }}
              className="px-2.5 py-1 rounded-full text-[11px] bg-white/[0.03] hover:bg-white/[0.08] text-zinc-300 border border-white/10 transition-colors"
            >
              {p.title}
            </button>
          ))}
        </div>
      </div>

      {/* Main Architecture Display */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Thesis & Milestones (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-5">
            <div className="pb-3 border-b border-white/10">
              <span className="text-[10px] font-mono text-[#cfbcff] uppercase tracking-wider block">
                {plan.fieldOfStudy} • {plan.academicLevel.toUpperCase()}
              </span>
              <h3 className="text-lg font-bold font-sora text-white mt-0.5">{plan.projectTitle}</h3>
            </div>

            {/* Thesis Statement Card */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-[#cfbcff]/10 to-transparent border-l-2 border-[#cfbcff] bg-black/40 space-y-1">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#cfbcff] font-bold block">
                Defensible Thesis Proposition
              </span>
              <p className="text-xs sm:text-sm text-zinc-200 leading-relaxed font-sans italic">
                "{plan.thesisStatement}"
              </p>
            </div>

            {/* Problem Statement & Research Gap */}
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-1.5">
              <span className="text-[10px] font-mono uppercase text-amber-300 font-bold block">
                Problem Statement & Research Void
              </span>
              <p className="text-xs text-zinc-300 leading-relaxed font-sans">{plan.problemStatement}</p>
            </div>

            {/* Milestone Roadmap */}
            <div className="space-y-3">
              <span className="text-xs font-mono uppercase text-[#cfbcff] font-bold tracking-wider flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" />
                Phase-by-Phase Milestone Architecture
              </span>
              <div className="space-y-3">
                {plan.milestones.map((m, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-white/[0.02] border border-white/5 space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs sm:text-sm font-bold text-white font-sora">
                        {m.phase}: {m.title}
                      </h4>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/5 text-zinc-400 border border-white/10">
                        ~{m.estimatedDays} Days
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs">
                      <strong className="text-zinc-400 text-[10px] font-mono uppercase block">
                        Deliverables:
                      </strong>
                      {m.deliverables.map((d, dIdx) => (
                        <div key={dIdx} className="flex items-center gap-2 text-zinc-300">
                          <CheckCircle className="w-3.5 h-3.5 text-[#cfbcff] flex-shrink-0" />
                          <span>{d}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Citations & Rubric Mastery (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Citations Machine */}
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-widest text-[#cfbcff] font-bold flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" />
                Verified Academic Citations
              </span>
              <div className="flex items-center gap-1">
                {(['IEEE', 'APA'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    onClick={() => setCitationFormat(fmt)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                      citationFormat === fmt
                        ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40 font-bold'
                        : 'text-zinc-500 hover:text-white'
                    }`}
                  >
                    {fmt}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              {plan.recommendedCitations.map((c, idx) => {
                const citationText = citationFormat === 'IEEE' ? c.formatIEEE : c.formatAPA;
                const isCopied = copiedCitationIdx === idx;
                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl bg-black/40 border border-white/10 space-y-2 group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-semibold text-white font-sora line-clamp-1">
                        {c.title}
                      </span>
                      <button
                        onClick={() => handleCopyCitation(citationText, idx)}
                        className="text-zinc-400 hover:text-[#cfbcff] p-1 flex-shrink-0 transition-colors"
                        title="Copy citation"
                      >
                        {isCopied ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                    <p className="text-[11px] font-mono text-zinc-400 leading-relaxed bg-black/60 p-2 rounded-lg border border-white/5">
                      {citationText}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Rubric Evaluator Advice */}
          <div className="p-6 rounded-2xl bg-[#0c0a12]/95 border border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-widest text-emerald-300 font-bold flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5" />
                Grading Rubric Optimization
              </span>
              <span className="text-[10px] font-mono text-zinc-500">Target: Grade A+</span>
            </div>

            <div className="space-y-2.5">
              {plan.rubricAdvice.map((advice, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-xl bg-emerald-500/[0.04] border border-emerald-500/20 text-xs text-zinc-300 font-sans leading-relaxed flex items-start gap-2.5"
                >
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                  <p>{advice}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
