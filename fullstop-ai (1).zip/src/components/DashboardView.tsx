import React, { useState, useEffect } from 'react';
import { NavigationTab, UserProfile } from '../types';
import { FullstopLogo } from './FullstopLogo';
import { getGreetingInfo, TimeOfDay } from '../utils/greeting';
import { SAMPLE_DAILY_NEWS, INITIAL_DAILY_BRIEFING } from '../data/dailyNewsData';
import {
  MessageSquare,
  Sparkles,
  Video,
  Users2,
  Target,
  GraduationCap,
  ArrowUpRight,
  Zap,
  Crown,
  Search,
  Bot,
  Layers,
  Cpu,
  TrendingUp,
  Sunrise,
  Sun,
  Sunset,
  Moon,
  Newspaper,
  Clock,
  Flame,
  CheckCircle2,
  FileText,
  HelpCircle,
  BookOpenCheck,
  Terminal,
  Mic,
  Users,
  FolderGit2,
  Briefcase,
  ChefHat,
} from 'lucide-react';

interface DashboardViewProps {
  userProfile: UserProfile | null;
  onSelectTab: (tab: NavigationTab) => void;
  dailyUsage: number;
  dailyLimit: number;
  onOpenUpgrade: () => void;
  onLaunchPrompt: (tab: NavigationTab, prompt: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  userProfile,
  onSelectTab,
  dailyUsage,
  dailyLimit,
  onOpenUpgrade,
  onLaunchPrompt,
}) => {
  const [quickPrompt, setQuickPrompt] = useState('');
  const [overrideHour, setOverrideHour] = useState<number | undefined>(undefined);
  const [currentTime, setCurrentTime] = useState(() => new Date());

  // Real-time ticking clock for dynamic greeting
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const greeting = getGreetingInfo(overrideHour);
  const isPro = Boolean(userProfile?.isPro);
  const firstName = userProfile?.fullName ? userProfile.fullName.split(' ')[0] : 'Creator';

  const handleQuickSubmit = (targetTab: NavigationTab) => {
    if (!quickPrompt.trim()) {
      onSelectTab(targetTab);
      return;
    }
    onLaunchPrompt(targetTab, quickPrompt.trim());
    setQuickPrompt('');
  };

  const renderGreetingIcon = () => {
    switch (greeting.iconName) {
      case 'Sunrise':
        return <Sunrise className="w-5 h-5 text-amber-300" />;
      case 'Sun':
        return <Sun className="w-5 h-5 text-amber-400" />;
      case 'Sunset':
        return <Sunset className="w-5 h-5 text-rose-300" />;
      case 'Moon':
        return <Moon className="w-5 h-5 text-[#cfbcff]" />;
    }
  };

  const workspaceCards = [
    {
      id: 'daily-news' as NavigationTab,
      title: 'Daily Update News',
      category: 'GLOBAL TECH RADAR',
      description: 'Daily intelligence pulse covering breakthrough AI models, photonic chips, and robotics shifts.',
      icon: Newspaper,
      accent: 'from-[#cfbcff]/35 to-[#8257e5]/25',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Today’s Pulse',
    },
    {
      id: 'chat' as NavigationTab,
      title: 'AI Chat',
      category: 'COGNITIVE ENGINE',
      description: 'Interact with Gemini for multi-turn high-density reasoning, coding, and problem solving.',
      icon: MessageSquare,
      accent: 'from-[#6750a4]/40 to-[#cfbcff]/20',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Gemini Resilient',
    },
    {
      id: 'goal-mode' as NavigationTab,
      title: 'Goal Mode',
      category: 'EXECUTION ARCHITECTURE',
      description: 'Deconstruct ambitious targets into SMART phased roadmaps, consistency rituals, and risk defense.',
      icon: Target,
      accent: 'from-[#cfbcff]/30 to-[#6750a4]/30',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Milestone Engine',
    },
    {
      id: 'study-mode' as NavigationTab,
      title: 'AI Study Assistant',
      category: 'NEURAL ACCELERATOR',
      description: 'Feynman intuitive breakdowns, active recall flashcard decks, focus audio synth, and quizzes.',
      icon: GraduationCap,
      accent: 'from-[#8257e5]/40 to-[#c48df6]/20',
      borderAccent: 'hover:border-[#c48df6]/50',
      badge: 'Feynman & Recall',
    },
    {
      id: 'notes-ai' as NavigationTab,
      title: 'Notes AI',
      category: 'ACADEMIC SYNTHESIS',
      description: 'Transform raw lectures or transcripts into Cornell notes, review cues, and revision cheat sheets.',
      icon: FileText,
      accent: 'from-[#cfbcff]/30 to-[#8257e5]/25',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Cornell Notes',
    },
    {
      id: 'quiz-generator' as NavigationTab,
      title: 'AI Quiz Generator',
      category: 'ADAPTIVE TESTING',
      description: 'Diagnostic challenge generator with timers, instant option rationale, trap audits, and scorecards.',
      icon: HelpCircle,
      accent: 'from-[#6750a4]/35 to-[#cfbcff]/20',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Interactive Testing',
    },
    {
      id: 'exam-prep' as NavigationTab,
      title: 'Exam Prep Mode',
      category: 'HIGH-YIELD SPRINT',
      description: 'High-probability test questions with model answers, formula banks, and 7-day revision plans.',
      icon: BookOpenCheck,
      accent: 'from-[#8257e5]/35 to-[#c48df6]/20',
      borderAccent: 'hover:border-[#c48df6]/50',
      badge: '7-Day Sprint',
    },
    {
      id: 'coding-lab' as NavigationTab,
      title: 'AI Coding Lab',
      category: 'EXECUTION SANDBOX',
      description: 'Multi-language code editor with real-time sandbox execution, Big-O profiling, and AI bug fixer.',
      icon: Terminal,
      accent: 'from-[#6750a4]/40 to-[#cfbcff]/20',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Neural IDE',
    },
    {
      id: 'english-learn' as NavigationTab,
      title: 'English Speaking & Learn',
      category: 'SPEECH INTELLIGENCE',
      description: 'Real-time conversational voice coach with instant grammar checks, native upgrades, and roleplays.',
      icon: Mic,
      accent: 'from-[#cfbcff]/30 to-[#8257e5]/25',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'Voice Coach',
    },
    {
      id: 'group-discussion' as NavigationTab,
      title: 'AI Group Discussion Arena',
      category: 'ROUNDTABLE DELIBERATION',
      description: 'Multi-agent MBA & corporate GD arena with Maya, Aris, Elena, Marcus, and candidate scorecards.',
      icon: Users,
      accent: 'from-[#b69df8]/30 to-[#6750a4]/30',
      borderAccent: 'hover:border-[#b69df8]/50',
      badge: 'GD Arena',
    },
    {
      id: 'project-helper' as NavigationTab,
      title: 'Project & Thesis Helper',
      category: 'RESEARCH ARCHITECT',
      description: 'Defensible thesis propositions, phased milestone roadmaps, APA/IEEE citations, and rubric advice.',
      icon: FolderGit2,
      accent: 'from-[#8257e5]/35 to-[#c48df6]/20',
      borderAccent: 'hover:border-[#c48df6]/50',
      badge: 'Capstone Helper',
    },
    {
      id: 'career-ai' as NavigationTab,
      title: 'Career AI Advisor',
      category: 'ATS & INTERVIEWS',
      description: 'Applicant Tracking System resume audit, bullet point rewriters, and role-specific mock interviews.',
      icon: Briefcase,
      accent: 'from-[#cfbcff]/30 to-[#6750a4]/30',
      borderAccent: 'hover:border-[#cfbcff]/50',
      badge: 'ATS & Mock',
    },
    {
      id: 'chefly-ai' as NavigationTab,
      title: 'AI Chefly AI',
      category: 'KITCHEN HELPER FOR MOTHERS',
      description: 'Loving culinary mentor for mothers: instant fridge magic, 15-min weeknight dinners, fussy-eater hacks, and kids lunchbox wins.',
      icon: ChefHat,
      accent: 'from-[#ffb4a2]/35 to-[#cfbcff]/20',
      borderAccent: 'hover:border-[#ffb4a2]/50',
      badge: 'Mothers Helper',
    },
    {
      id: 'image-studio' as NavigationTab,
      title: 'Image Studio',
      category: 'NEURAL CANVAS',
      description: 'Generate high-fidelity photorealistic and futuristic imagery with custom aspect ratios & styles.',
      icon: Sparkles,
      accent: 'from-[#8257e5]/40 to-[#c48df6]/20',
      borderAccent: 'hover:border-[#c48df6]/50',
      badge: 'Gen-3 Visuals',
    },
    {
      id: 'video-lab' as NavigationTab,
      title: 'Video Lab',
      category: 'MOTION SYNTHESIZER',
      description: 'Render 1080p temporal generative cinematic video clips with dynamic camera motion controls.',
      icon: Video,
      accent: 'from-[#4a3294]/40 to-[#9d72e7]/20',
      borderAccent: 'hover:border-[#9d72e7]/50',
      badge: '1080p Temporal',
    },
    {
      id: 'ai-council' as NavigationTab,
      title: 'AI Council',
      category: 'CONSENSUS PROTOCOL',
      description: 'Convene 3 specialized AI agents (Researcher, Creative, Critic) to debate and synthesize decisions.',
      icon: Users2,
      accent: 'from-[#b69df8]/30 to-[#6750a4]/30',
      borderAccent: 'hover:border-[#b69df8]/50',
      badge: 'Multi-Agent',
    },
  ];

  return (
    <div id="dashboard-view" className="max-w-6xl mx-auto p-4 sm:p-8 space-y-8">
      {/* Hero Greeting Section with Dynamic Time Awareness */}
      <div className="relative rounded-3xl glass-panel glass-card-edge bg-[#0e0c14]/85 p-6 sm:p-10 overflow-hidden border border-white/10 shadow-2xl">
        {/* Dynamic Glow Effects adapted to time of day */}
        <div className={`absolute -top-32 -right-32 w-80 h-80 bg-gradient-to-br ${greeting.gradient} rounded-full blur-3xl pointer-events-none opacity-60`} />
        <div className="absolute -bottom-32 -left-32 w-80 h-80 bg-[#cfbcff]/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="max-w-3xl">
            {/* Top Badges & Logo */}
            <div className="flex flex-wrap items-center gap-2.5 mb-3">
              <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#14111d] border border-[#cfbcff]/30 text-[#cfbcff]">
                <FullstopLogo size="xs" animated={true} withGlow={false} />
                <span className="text-[11px] font-mono uppercase font-bold tracking-wider">
                  FULLSTOP AI // NEXUS OS
                </span>
              </div>

              {/* Dynamic Time Cycle Indicator */}
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-zinc-300 font-mono">
                {renderGreetingIcon()}
                <span>{greeting.cycleBadge}</span>
                <span className="text-zinc-500">•</span>
                <span className="text-[#cfbcff] font-semibold">{greeting.formattedTime}</span>
              </div>
            </div>

            {/* Dynamic Greeting Headline: Good morning / Good afternoon / Good night */}
            <h1 className="text-3xl sm:text-4xl font-extrabold font-sora tracking-tight text-white mb-2 flex items-center gap-3 flex-wrap">
              <span>
                {greeting.greetingText}, {firstName}
              </span>
              <span className="inline-flex items-center justify-center p-1.5 rounded-xl bg-white/5 border border-white/10 shadow-inner">
                {renderGreetingIcon()}
              </span>
            </h1>

            <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
              {greeting.subtext}
            </p>

            {/* Interactive Time Mode Preview Switcher */}
            <div className="flex items-center gap-1.5 mt-3 pt-1 text-xs font-mono">
              <span className="text-zinc-500 text-[10px] uppercase mr-1">Time Mode:</span>
              <button
                type="button"
                onClick={() => setOverrideHour(undefined)}
                className={`px-2 py-0.5 rounded-md text-[11px] transition-all ${
                  overrideHour === undefined
                    ? 'bg-[#cfbcff]/20 text-[#cfbcff] border border-[#cfbcff]/40 font-semibold'
                    : 'text-zinc-500 hover:text-zinc-300 bg-white/[0.02]'
                }`}
                title="Use your actual local clock time"
              >
                Auto Clock ⏱️
              </button>
              <button
                type="button"
                onClick={() => setOverrideHour(8)}
                className={`px-2 py-0.5 rounded-md text-[11px] transition-all ${
                  overrideHour === 8
                    ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40 font-semibold'
                    : 'text-zinc-500 hover:text-zinc-300 bg-white/[0.02]'
                }`}
              >
                🌅 Morning
              </button>
              <button
                type="button"
                onClick={() => setOverrideHour(14)}
                className={`px-2 py-0.5 rounded-md text-[11px] transition-all ${
                  overrideHour === 14
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-semibold'
                    : 'text-zinc-500 hover:text-zinc-300 bg-white/[0.02]'
                }`}
              >
                ☀️ Afternoon
              </button>
              <button
                type="button"
                onClick={() => setOverrideHour(22)}
                className={`px-2 py-0.5 rounded-md text-[11px] transition-all ${
                  overrideHour === 22
                    ? 'bg-[#6750a4]/30 text-[#cfbcff] border border-[#cfbcff]/40 font-semibold'
                    : 'text-zinc-500 hover:text-zinc-300 bg-white/[0.02]'
                }`}
              >
                🌙 Night
              </button>
            </div>

            {/* Integrated Prompt Bar with Mode Pills */}
            <div className="mt-5 pt-1">
              <div className="relative rounded-2xl glass-panel bg-[#14111d]/90 p-2 border border-white/15 focus-within:border-[#cfbcff]/60 transition-colors shadow-2xl">
                <div className="flex items-center gap-3 px-3 py-2">
                  <Search className="w-5 h-5 text-zinc-400 flex-shrink-0" />
                  <input
                    id="dashboard-prompt-input"
                    type="text"
                    value={quickPrompt}
                    onChange={(e) => setQuickPrompt(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleQuickSubmit('chat');
                    }}
                    placeholder="Ask a question, search daily news, or pose a challenge to the AI Council..."
                    className="w-full bg-transparent text-sm text-white placeholder-zinc-500 outline-none font-sans"
                  />
                </div>

                {/* Action Pills */}
                <div className="flex flex-wrap items-center justify-between gap-2 px-2 pt-2 border-t border-white/5">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[10px] font-mono text-zinc-500 mr-1 uppercase">Dispatch to:</span>
                    <button
                      id="pill-dispatch-news"
                      onClick={() => handleQuickSubmit('daily-news')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <Newspaper className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Daily News</span>
                    </button>

                    <button
                      id="pill-dispatch-chat"
                      onClick={() => handleQuickSubmit('chat')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Chat</span>
                    </button>

                    <button
                      id="pill-dispatch-goal"
                      onClick={() => handleQuickSubmit('goal-mode')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <Target className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Goal</span>
                    </button>

                    <button
                      id="pill-dispatch-study"
                      onClick={() => handleQuickSubmit('study-mode')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <GraduationCap className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Study</span>
                    </button>

                    <button
                      id="pill-dispatch-image"
                      onClick={() => handleQuickSubmit('image-studio')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Image</span>
                    </button>

                    <button
                      id="pill-dispatch-video"
                      onClick={() => handleQuickSubmit('video-lab')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <Video className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>Video</span>
                    </button>

                    <button
                      id="pill-dispatch-council"
                      onClick={() => handleQuickSubmit('ai-council')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-white bg-white/5 hover:bg-[#cfbcff]/20 border border-white/10 hover:border-[#cfbcff]/30 transition-all font-sora"
                    >
                      <Users2 className="w-3.5 h-3.5 text-[#cfbcff]" />
                      <span>AI Council</span>
                    </button>

                    <button
                      id="pill-dispatch-chefly"
                      onClick={() => handleQuickSubmit('chefly-ai')}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium text-[#ffb4a2] bg-[#ffb4a2]/10 hover:bg-[#ffb4a2]/25 border border-[#ffb4a2]/30 hover:border-[#ffb4a2]/50 transition-all font-sora"
                    >
                      <ChefHat className="w-3.5 h-3.5 text-[#ffb4a2]" />
                      <span>AI Chefly</span>
                    </button>
                  </div>

                  <div className="text-[11px] font-mono text-zinc-400 flex items-center gap-1">
                    <Zap className="w-3 h-3 text-amber-400" />
                    <span>{isPro ? 'Unlimited Pro' : `${dailyLimit - dailyUsage} free queries left`}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Emblem Illustration */}
          <div className="hidden lg:flex flex-col items-center justify-center p-6 rounded-2xl bg-white/[0.02] border border-white/10 text-center flex-shrink-0 w-52">
            <FullstopLogo size="xl" animated={true} withGlow={true} className="mb-3" />
            <span className="text-xs font-mono text-[#cfbcff] font-semibold tracking-wider">
              FULLSTOP AI
            </span>
            <span className="text-[10px] font-mono text-zinc-500 mt-0.5">
              Nexus Singularity Core
            </span>
          </div>
        </div>
      </div>

      {/* DAILY UPDATE NEWS PULSE SECTION ON DASHBOARD */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#cfbcff]/15 border border-[#cfbcff]/30 flex items-center justify-center text-[#cfbcff]">
              <Newspaper className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-sora text-white tracking-tight flex items-center gap-2">
                <span>Daily Update News & Intelligence Pulse</span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  LIVE TODAY
                </span>
              </h2>
            </div>
          </div>

          <button
            onClick={() => onSelectTab('daily-news')}
            className="text-xs font-mono text-[#cfbcff] hover:text-white flex items-center gap-1 hover:underline transition-colors"
          >
            <span>View All Stories</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Top 3 Breaking Stories for Today */}
        <div className="grid md:grid-cols-3 gap-4">
          {SAMPLE_DAILY_NEWS.slice(0, 3).map((story) => (
            <div
              key={story.id}
              onClick={() => onSelectTab('daily-news')}
              className="p-4 rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 border border-white/10 hover:border-[#cfbcff]/40 transition-all cursor-pointer flex flex-col justify-between group overflow-hidden"
            >
              <div>
                <div className="flex items-center justify-between mb-2.5">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#cfbcff]/10 text-[#cfbcff] border border-[#cfbcff]/20">
                    {story.category}
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {story.publishedAt}
                  </span>
                </div>

                <h3 className="text-sm font-bold font-sora text-white group-hover:text-[#cfbcff] transition-colors line-clamp-2 mb-2">
                  {story.title}
                </h3>

                <p className="text-xs text-zinc-400 line-clamp-3 leading-relaxed font-sans mb-3">
                  {story.summary}
                </p>
              </div>

              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-zinc-400">
                <span className="truncate max-w-[140px] text-zinc-500">{story.source}</span>
                <span className="text-[#cfbcff] group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5 font-semibold">
                  Read Report <ArrowUpRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Feature Studios Grid */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold font-sora text-white tracking-tight flex items-center gap-2">
            <span>Core Intelligence Studios</span>
          </h2>
          <span className="text-xs font-mono text-zinc-400">SELECT TO LAUNCH</span>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {workspaceCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                id={`card-workspace-${card.id}`}
                onClick={() => onSelectTab(card.id)}
                className={`relative rounded-2xl glass-panel glass-card-edge bg-[#0e0c14]/90 p-5 cursor-pointer border border-white/10 transition-all duration-300 hover-lift ${card.borderAccent} group overflow-hidden flex flex-col justify-between`}
              >
                {/* Top Corner Glow */}
                <div
                  className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl ${card.accent} rounded-full blur-2xl pointer-events-none opacity-40 group-hover:opacity-80 transition-opacity`}
                />

                <div>
                  <div className="relative z-10 flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-center text-[#cfbcff] group-hover:scale-110 group-hover:border-[#cfbcff]/40 transition-all shadow-lg">
                      <Icon className="w-5 h-5" />
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-white/5 text-zinc-300 border border-white/10">
                        {card.badge}
                      </span>
                      <div className="w-7 h-7 rounded-full bg-white/5 flex items-center justify-center text-zinc-400 group-hover:text-white group-hover:bg-[#cfbcff]/20 transition-colors">
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </div>
                    </div>
                  </div>

                  <div className="relative z-10">
                    <span className="text-[10px] font-mono tracking-widest text-[#cfbcff] uppercase font-semibold">
                      {card.category}
                    </span>
                    <h3 className="text-lg font-bold font-sora text-white mb-1.5 group-hover:text-[#cfbcff] transition-colors">
                      {card.title}
                    </h3>
                    <p className="text-xs text-zinc-400 leading-relaxed line-clamp-3">
                      {card.description}
                    </p>
                  </div>
                </div>

                <div className="pt-3 mt-3 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-zinc-500">
                  <span>Enter Workspace</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-[#cfbcff]" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Telemetry & Quota Status Bar */}
      <div className="grid sm:grid-cols-3 gap-4">
        {/* Quota Card */}
        <div className="p-5 rounded-2xl glass-panel bg-[#0e0c14]/70 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase text-zinc-400">Daily Free Allocation</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mb-3">
            <div className="text-2xl font-bold font-sora text-white">
              {isPro ? 'Unlimited' : `${dailyLimit - dailyUsage} Queries`}
            </div>
            <p className="text-xs text-zinc-400">
              {isPro ? 'Pro license active' : `${dailyUsage} of ${dailyLimit} requests utilized today`}
            </p>
          </div>
          {!isPro ? (
            <button
              onClick={onOpenUpgrade}
              className="text-xs text-[#cfbcff] hover:text-white font-sora font-semibold flex items-center gap-1.5 group"
            >
              <span>Upgrade to Unlimited Pro</span>
              <Crown className="w-3.5 h-3.5 group-hover:scale-110 transition-transform" />
            </button>
          ) : (
            <span className="text-xs text-emerald-400 font-mono">Status: Optimum</span>
          )}
        </div>

        {/* Engine Specs */}
        <div className="p-5 rounded-2xl glass-panel bg-[#0e0c14]/70 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase text-zinc-400">Active Engine</span>
            <Cpu className="w-4 h-4 text-[#cfbcff]" />
          </div>
          <div className="mb-3">
            <div className="text-2xl font-bold font-sora text-white">Fullstop Resilient Core</div>
            <p className="text-xs text-zinc-400">Gemini 3.8 / 3.1 Flash with Zero-Downtime Fallback</p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>Telemetry: Nominal • Low Latency</span>
          </div>
        </div>

        {/* Council Consensus */}
        <div
          onClick={() => onSelectTab('ai-council')}
          className="p-5 rounded-2xl glass-panel bg-[#0e0c14]/70 border border-white/10 flex flex-col justify-between cursor-pointer hover:border-[#cfbcff]/40 transition-colors group"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono uppercase text-zinc-400">Deliberation Protocol</span>
            <Layers className="w-4 h-4 text-[#b69df8]" />
          </div>
          <div className="mb-3">
            <div className="text-2xl font-bold font-sora text-white group-hover:text-[#cfbcff] transition-colors">
              3 AI Agents
            </div>
            <p className="text-xs text-zinc-400">Researcher • Creative • Critic</p>
          </div>
          <div className="text-xs text-[#cfbcff] font-sora flex items-center gap-1">
            <span>Convene AI Council</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </div>
        </div>
      </div>
    </div>
  );
};
