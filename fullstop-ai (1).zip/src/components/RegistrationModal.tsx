import React, { useState } from 'react';
import { UserProfile } from '../types';
import { FullstopLogo } from './FullstopLogo';
import { Shield, User, Mail, Phone, ArrowRight, CheckCircle2 } from 'lucide-react';

interface RegistrationModalProps {
  isOpen: boolean;
  onComplete: (profile: UserProfile) => void;
  initialProfile?: UserProfile | null;
  canDismiss?: boolean;
  onDismiss?: () => void;
}

const COUNTRY_CODES = [
  { code: '+1', country: 'US / CA' },
  { code: '+44', country: 'UK' },
  { code: '+91', country: 'India' },
  { code: '+49', country: 'Germany' },
  { code: '+33', country: 'France' },
  { code: '+81', country: 'Japan' },
  { code: '+61', country: 'Australia' },
  { code: '+65', country: 'Singapore' },
  { code: '+971', country: 'UAE' },
];

export const RegistrationModal: React.FC<RegistrationModalProps> = ({
  isOpen,
  onComplete,
  initialProfile,
  canDismiss = false,
  onDismiss,
}) => {
  const [fullName, setFullName] = useState(initialProfile?.fullName || '');
  const [email, setEmail] = useState(initialProfile?.email || '');
  const [countryCode, setCountryCode] = useState(initialProfile?.countryCode || '+1');
  const [phone, setPhone] = useState(initialProfile?.phone || '');
  const [agreeTerms, setAgreeTerms] = useState(true);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  if (!isOpen) return null;

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (!fullName.trim()) {
      newErrors.fullName = 'Please enter your full name';
    }
    if (!email.trim()) {
      newErrors.email = 'Please enter your email address';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!phone.trim()) {
      newErrors.phone = 'Please enter your phone number';
    } else if (phone.replace(/\D/g, '').length < 7) {
      newErrors.phone = 'Please enter a valid phone number (at least 7 digits)';
    }
    if (!agreeTerms) {
      newErrors.terms = 'You must agree to the Terms of Service to proceed';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const profile: UserProfile = {
      fullName: fullName.trim(),
      email: email.trim(),
      phone: phone.trim(),
      countryCode,
      registeredAt: initialProfile?.registeredAt || new Date().toISOString(),
      isPro: initialProfile?.isPro || false,
    };

    localStorage.setItem('fullstop_user_profile', JSON.stringify(profile));
    onComplete(profile);
  };

  return (
    <div
      id="registration-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto"
    >
      <div
        id="registration-card"
        className="relative w-full max-w-lg rounded-2xl glass-panel glass-card-edge bg-[#0e0c13]/95 p-6 sm:p-8 shadow-2xl border border-white/10 text-white my-8"
      >
        {/* Glow ambient highlight */}
        <div className="absolute -top-20 -left-20 w-48 h-48 bg-[#6750a4]/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-48 h-48 bg-[#cfbcff]/20 rounded-full blur-3xl pointer-events-none" />

        {/* Step Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2.5">
            <FullstopLogo size="sm" animated={true} />
            <div>
              <span className="text-xs font-mono tracking-widest text-[#cfbcff] uppercase font-semibold">
                FULLSTOP AI // PROTOCOL
              </span>
              <p className="text-[11px] text-zinc-400">Step 1 of 3: Identity Setup</p>
            </div>
          </div>
          {canDismiss && onDismiss && (
            <button
              id="dismiss-registration-btn"
              onClick={onDismiss}
              className="text-xs text-zinc-400 hover:text-white px-2 py-1 rounded border border-white/10 hover:border-white/20 transition-colors"
            >
              Close
            </button>
          )}
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1 bg-white/10 rounded-full mb-6 overflow-hidden">
          <div className="w-1/3 h-full bg-gradient-to-r from-[#6750a4] to-[#cfbcff] rounded-full" />
        </div>

        {/* Title */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold font-sora tracking-tight text-white mb-1.5">
            {initialProfile ? 'Update Your Profile' : 'Welcome to Fullstop AI'}
          </h2>
          <p className="text-sm text-zinc-300">
            Initialize your cognitive AI workspace and claim your daily complimentary neural tokens.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
              Full Name
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                <User className="w-4 h-4" />
              </div>
              <input
                id="input-fullname"
                type="text"
                placeholder="e.g. Elena Vance"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className={`w-full bg-[#17141f] border ${
                  errors.fullName ? 'border-red-500/80 focus:border-red-500' : 'border-white/10 focus:border-[#cfbcff]'
                } rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-zinc-500 outline-none transition-all`}
              />
            </div>
            {errors.fullName && <p className="text-xs text-red-400 mt-1">{errors.fullName}</p>}
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
              Email Address
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                id="input-email"
                type="email"
                placeholder="elena@nexuscore.ai"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`w-full bg-[#17141f] border ${
                  errors.email ? 'border-red-500/80 focus:border-red-500' : 'border-white/10 focus:border-[#cfbcff]'
                } rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-zinc-500 outline-none transition-all`}
              />
            </div>
            {errors.email && <p className="text-xs text-red-400 mt-1">{errors.email}</p>}
          </div>

          {/* Phone Number with Country Code */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 uppercase tracking-wider mb-1.5">
              Phone Number
            </label>
            <div className="flex gap-2">
              <select
                id="select-country-code"
                value={countryCode}
                onChange={(e) => setCountryCode(e.target.value)}
                className="bg-[#17141f] border border-white/10 focus:border-[#cfbcff] rounded-xl px-3 py-3 text-xs text-zinc-200 outline-none transition-all font-mono"
              >
                {COUNTRY_CODES.map((item) => (
                  <option key={item.code + item.country} value={item.code} className="bg-[#17141f] text-white">
                    {item.code} ({item.country})
                  </option>
                ))}
              </select>
              <div className="relative flex-1">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-zinc-400">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  id="input-phone"
                  type="tel"
                  placeholder="555-0199"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className={`w-full bg-[#17141f] border ${
                    errors.phone ? 'border-red-500/80 focus:border-red-500' : 'border-white/10 focus:border-[#cfbcff]'
                  } rounded-xl pl-10 pr-4 py-3 text-sm text-white placeholder-zinc-500 outline-none transition-all`}
                />
              </div>
            </div>
            {errors.phone && <p className="text-xs text-red-400 mt-1">{errors.phone}</p>}
          </div>

          {/* Terms & Consent */}
          <div className="pt-2">
            <label className="flex items-start gap-2.5 cursor-pointer select-none">
              <input
                id="checkbox-agree-terms"
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="mt-1 rounded bg-zinc-800 border-white/20 text-[#cfbcff] focus:ring-[#cfbcff] focus:ring-offset-0"
              />
              <span className="text-xs text-zinc-400 leading-relaxed">
                I agree to the Fullstop AI Neural Terms of Service and acknowledge the daily free tier allocation of 20 AI queries.
              </span>
            </label>
            {errors.terms && <p className="text-xs text-red-400 mt-1">{errors.terms}</p>}
          </div>

          {/* Badge perks */}
          <div className="grid grid-cols-2 gap-2 pt-2">
            <div className="flex items-center gap-2 p-2 rounded-lg bg-white/[0.02] border border-white/5 text-xs text-zinc-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#cfbcff]" />
              <span>Gemini 3.8 Flash Core</span>
            </div>
            <div className="flex items-center gap-2 p-2 rounded-lg bg-white/[0.02] border border-white/5 text-xs text-zinc-300">
              <Shield className="w-3.5 h-3.5 text-[#cfbcff]" />
              <span>Private & Encrypted</span>
            </div>
          </div>

          {/* Submit Button */}
          <button
            id="btn-complete-registration"
            type="submit"
            className="w-full mt-4 py-3.5 px-6 rounded-xl font-sora font-semibold text-sm bg-gradient-to-r from-[#cfbcff] via-[#b69df8] to-[#9a7dec] text-[#1c0f38] hover:shadow-[0_0_25px_rgba(207,188,255,0.45)] transition-all flex items-center justify-center gap-2 glow-button"
          >
            <span>{initialProfile ? 'Save Changes' : 'Initialize Workspace'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
