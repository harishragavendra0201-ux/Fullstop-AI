import React from 'react';
import { NavigationTab, UserProfile } from '../types';
import { FullstopLogo } from './FullstopLogo';
import {
  LayoutDashboard,
  Newspaper,
  MessageSquare,
  Sparkles,
  Video,
  Users2,
  Target,
  GraduationCap,
  Crown,
  Zap,
  Settings,
  ShieldCheck,
  FileText,
  HelpCircle,
  BookOpenCheck,
  Terminal,
  Mic,
  Users,
  FolderGit2,
  Briefcase,
  ChefHat,
} from 'lucide-react';

interface SidebarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  userProfile: UserProfile | null;
  dailyUsage: number;
  dailyLimit: number;
  onOpenUpgrade: () => void;
  onOpenProfile: () => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  userProfile,
  dailyUsage,
  dailyLimit,
  onOpenUpgrade,
  onOpenProfile,
  isOpenMobile = false,
  onCloseMobile,
}) => {
  const isPro = Boolean(userProfile?.isPro);
  const percentUsed = Math.min(100, Math.round((dailyUsage / dailyLimit) * 100));

  const navSections = [
    {
      title: 'Command Center',
      items: [
        {
          id: 'dashboard' as NavigationTab,
          label: 'Dashboard',
          icon: LayoutDashboard,
          badge: undefined,
        },
        {
          id: 'daily-news' as NavigationTab,
          label: 'Daily News',
          icon: Newspaper,
          badge: 'Today',
        },
        {
          id: 'chat' as NavigationTab,
          label: 'AI Chat',
          icon: MessageSquare,
          badge: 'Gemini',
        },
        {
          id: 'goal-mode' as NavigationTab,
          label: 'Goal Mode',
          icon: Target,
          badge: 'Execute',
        },
        {
          id: 'chefly-ai' as NavigationTab,
          label: 'AI Chefly',
          icon: ChefHat,
          badge: 'Mothers',
        },
      ],
    },
    {
      title: 'Academic & Learning',
      items: [
        {
          id: 'study-mode' as NavigationTab,
          label: 'AI Study Assistant',
          icon: GraduationCap,
          badge: 'Feynman',
        },
        {
          id: 'notes-ai' as NavigationTab,
          label: 'Notes AI',
          icon: FileText,
          badge: 'Cornell',
        },
        {
          id: 'quiz-generator' as NavigationTab,
          label: 'AI Quiz Generator',
          icon: HelpCircle,
          badge: 'Adaptive',
        },
        {
          id: 'exam-prep' as NavigationTab,
          label: 'Exam Prep Mode',
          icon: BookOpenCheck,
          badge: 'Sprint',
        },
        {
          id: 'project-helper' as NavigationTab,
          label: 'Project & Thesis',
          icon: FolderGit2,
          badge: 'Helper',
        },
      ],
    },
    {
      title: 'Skills & Professional Labs',
      items: [
        {
          id: 'coding-lab' as NavigationTab,
          label: 'AI Coding Lab',
          icon: Terminal,
          badge: 'IDE',
        },
        {
          id: 'english-learn' as NavigationTab,
          label: 'English Speaking',
          icon: Mic,
          badge: 'Voice',
        },
        {
          id: 'group-discussion' as NavigationTab,
          label: 'AI Group Discussion',
          icon: Users,
          badge: 'Arena',
        },
        {
          id: 'career-ai' as NavigationTab,
          label: 'Career AI Advisor',
          icon: Briefcase,
          badge: 'ATS',
        },
      ],
    },
    {
      title: 'Generative Studio',
      items: [
        {
          id: 'image-studio' as NavigationTab,
          label: 'Image Studio',
          icon: Sparkles,
          badge: 'Gen-3',
        },
        {
          id: 'video-lab' as NavigationTab,
          label: 'Video Lab',
          icon: Video,
          badge: '1080p',
        },
        {
          id: 'ai-council' as NavigationTab,
          label: 'AI Council',
          icon: Users2,
          badge: 'Council',
        },
      ],
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpenMobile && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm md:hidden"
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed md:sticky top-0 left-0 z-40 h-screen w-64 bg-[#09080e]/95 border-r border-white/10 flex flex-col justify-between transition-transform duration-300 md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        } backdrop-blur-xl`}
      >
        {/* Top Branding */}
        <div className="flex flex-col min-h-0 flex-1">
          <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between flex-shrink-0">
            <div
              onClick={() => onSelectTab('dashboard')}
              className="flex items-center gap-2.5 cursor-pointer group"
            >
              <div className="group-hover:scale-105 transition-transform">
                <FullstopLogo size="md" animated={true} />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="font-sora font-bold text-base tracking-tight text-white group-hover:text-[#cfbcff] transition-colors">
                    Fullstop AI
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </div>
                <span className="text-[10px] font-mono text-zinc-400 tracking-wider uppercase block">
                  NEXUS CORE OS
                </span>
              </div>
            </div>
          </div>

          {/* Nav Items Scroll Area */}
          <nav className="p-3 space-y-4 overflow-y-auto flex-1 custom-scrollbar">
            {navSections.map((section) => (
              <div key={section.title} className="space-y-1">
                <div className="px-3 py-1 text-[10px] font-mono uppercase tracking-widest text-zinc-500 font-bold">
                  {section.title}
                </div>
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      id={`nav-${item.id}`}
                      onClick={() => {
                        onSelectTab(item.id);
                        if (onCloseMobile) onCloseMobile();
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all group ${
                        isActive
                          ? 'bg-gradient-to-r from-[#cfbcff]/20 to-[#6750a4]/10 text-white border border-[#cfbcff]/30 shadow-[inset_0_0_12px_rgba(207,188,255,0.1)]'
                          : 'text-zinc-400 hover:text-white hover:bg-white/[0.04] border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <Icon
                          className={`w-4 h-4 flex-shrink-0 transition-colors ${
                            isActive ? 'text-[#cfbcff]' : 'text-zinc-400 group-hover:text-zinc-200'
                          }`}
                        />
                        <span className="font-sora truncate">{item.label}</span>
                      </div>
                      {item.badge && (
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-mono border flex-shrink-0 ${
                            isActive
                              ? 'bg-[#cfbcff]/20 text-[#cfbcff] border-[#cfbcff]/40'
                              : 'bg-white/5 text-zinc-400 border-white/10'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            ))}
          </nav>
        </div>

        {/* Bottom Section: Quota & Profile */}
        <div className="p-3 space-y-2.5 border-t border-white/10 flex-shrink-0 bg-[#09080e]">
          {/* Usage Quota Card */}
          <div className="p-2.5 rounded-xl bg-white/[0.02] border border-white/10 relative overflow-hidden">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5 text-xs text-zinc-300">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-medium text-[11px]">Daily Quota</span>
              </div>
              <span className="text-[10px] font-mono text-zinc-400">
                {isPro ? 'UNLIMITED' : `${dailyUsage}/${dailyLimit}`}
              </span>
            </div>

            {!isPro ? (
              <>
                <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden mb-2">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      percentUsed >= 100
                        ? 'bg-rose-500'
                        : percentUsed > 75
                        ? 'bg-amber-400'
                        : 'bg-gradient-to-r from-[#6750a4] to-[#cfbcff]'
                    }`}
                    style={{ width: `${percentUsed}%` }}
                  />
                </div>
                <button
                  id="btn-sidebar-upgrade"
                  onClick={onOpenUpgrade}
                  className="w-full py-1.5 px-2 rounded-lg bg-[#cfbcff]/15 hover:bg-[#cfbcff]/25 border border-[#cfbcff]/30 text-[#cfbcff] text-[11px] font-sora font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Crown className="w-3 h-3" />
                  <span>Upgrade to Pro</span>
                </button>
              </>
            ) : (
              <div className="flex items-center gap-1.5 pt-0.5 text-[10px] text-emerald-300">
                <ShieldCheck className="w-3 h-3" />
                <span>Pro Member (Active)</span>
              </div>
            )}
          </div>

          {/* User Profile Footer */}
          <div
            id="user-profile-widget"
            onClick={onOpenProfile}
            className="flex items-center justify-between p-2 rounded-xl hover:bg-white/[0.04] cursor-pointer transition-colors border border-transparent hover:border-white/10"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-[#6750a4] to-[#cfbcff] text-[#1c0f38] flex items-center justify-center font-sora font-bold text-[11px] flex-shrink-0">
                {userProfile?.fullName
                  ? userProfile.fullName
                      .split(' ')
                      .map((n) => n[0])
                      .join('')
                      .toUpperCase()
                      .slice(0, 2)
                  : 'AI'}
              </div>
              <div className="truncate">
                <p className="text-xs font-semibold text-white truncate">
                  {userProfile?.fullName || 'Fullstop Guest'}
                </p>
                <p className="text-[10px] text-zinc-400 font-mono truncate">
                  {userProfile?.email || 'Configure profile'}
                </p>
              </div>
            </div>
            <Settings className="w-3.5 h-3.5 text-zinc-400 hover:text-white flex-shrink-0 ml-1" />
          </div>
        </div>
      </aside>
    </>
  );
};
